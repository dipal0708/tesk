// Angular
import { Component,ChangeDetectorRef } from '@angular/core';
// Metronic
import { OffcanvasOptions } from '../../../../core/_base/metronic';
import { UserService } from '../../../../core/services/users.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataService } from '../../../data.service';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
	selector: 'kt-quick-panel',
	templateUrl: './quick-panel.component.html',
	styleUrls: ['./quick-panel.component.scss']
})
export class QuickPanelComponent {
	// Public properties
	allcompaniesList:any=[];

	message:string;
	companies:any=[];
	offcanvasOptions: OffcanvasOptions = {
		overlay: true,
		baseClass: 'kt-quick-panel',
		closeBy: 'kt_quick_panel_close_btn',
		toggleBy: 'kt_quick_panel_toggler_btn'
	};
	private unsubscribe: Subject<any>;
	constructor(private cdr: ChangeDetectorRef,private data: DataService,private toastr:ToastrService,private service:UserService,private router: Router) {
			
	}

	ngOnInit() {
		this.getAllrecords();
		this.data.currentMessage.subscribe(message => this.message = message)
		
	}
	getAllrecords(){
		
		var localdata = localStorage.getItem('userDetail');
		var localdata2 = JSON.parse(localdata);
		
		debugger
	// 	this.service.getuserByemail(localdata2.email)
    //   .subscribe(
    //     (data: any[]) =>  {
	// 	  debugger
	// 	}, 
    //     (error: any)   => console.log(error),
    //     ()             => console.log('all data gets')
	//   );
	  
		this.service.getuserByemail(localdata2.email).subscribe((data:any)=>{
			
			var dataByemail = data.data;
			localStorage.setItem('userDetail2',JSON.stringify(dataByemail));

			this.service.getcompaniesOnly(dataByemail.pk_id).subscribe((data:any)=>{
				
				this.allcompaniesList = data.data;
				localStorage.setItem('userCompany',JSON.stringify(this.allcompaniesList));

			   var obj = { dealerid: this.allcompaniesList[0].dealerid }
			   this.service.getDiamondDashboard(obj).subscribe((data:any)=>{
				   debugger
				   this.data.changeMessageDashboard(data);
			   });
			  });
		  });


		
	  }
	  onAddcompany(){
		  
		  this.router.navigate(['/default/companiesuserslist']);
	  }
	  companyChange(companyName) {
		  
		  this.data.changeMessage(companyName);
		  this.router.navigate(['/default/dashboard']);
	}
	ngAfterViewInit(){
		
	}
}
