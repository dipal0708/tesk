// Angular
import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
// RxJS
import { Subscription } from 'rxjs';
// Layout
import { SubheaderService } from '../../../../../core/_base/layout';
import { Breadcrumb } from '../../../../../core/_base/layout/services/subheader.service';
import { UserService } from '../../../../../core/services/users.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataService } from '../../../../data.service';

@Component({
	selector: 'kt-subheader1',
	templateUrl: './subheader1.component.html',
	styleUrls: ['./subheader1.component.scss']
})
export class Subheader1Component implements OnInit, OnDestroy, AfterViewInit {
	// Public properties
	today: number = Date.now();
	title: string = '';
	selectedValue: string;
	desc: string = '';
	breadcrumbs: Breadcrumb[] = [];
	// Private properties
	allcompaniesList:any=[];

	private subscriptions: Subscription[] = [];
	message:string;
	/**
	 * Component constructor
	 *
	 * @param subheaderService: SubheaderService
	 */
	constructor(private data: DataService,public subheaderService: SubheaderService,private toastr:ToastrService,private service:UserService,private router: Router) {
	}

	/**
	 * @ Lifecycle sequences => https://angular.io/guide/lifecycle-hooks
	 */

	/**
	 * On init
	 */
	ngOnInit() {
		this.data.currentMessage.subscribe(message => this.message = message)
		this.getAllrecords();
	}
	getAllrecords(){
		// this.service.getAllcompanies().subscribe((data:any)=>{
		//   
		//   var localdata = localStorage.getItem('userDetail');
		//   var localdata2 = JSON.parse(localdata);
		  
		//    var datanew = data.data;
		//    this.allcompaniesList = datanew.filter(x => x.created_by == localdata2.pk_id);
		// });
	  }
	  onAddcompany(){
		 
		  this.router.navigate(['/default/companiesuserslist']);
	  }
	  companyChange(companyName) {
		 
		  this.data.changeMessage(companyName.value.company_name);
	}

	/** 	
	 * After view init
	 */
	ngAfterViewInit(): void {
		this.subscriptions.push(this.subheaderService.title$.subscribe(bt => {
			// breadcrumbs title sometimes can be undefined
			if (bt) {
				Promise.resolve(null).then(() => {
					this.title = bt.title;
					this.desc = bt.desc;
				});
			}
		}));

		this.subscriptions.push(this.subheaderService.breadcrumbs$.subscribe(bc => {
			Promise.resolve(null).then(() => {
				this.breadcrumbs = bc;
			});
		}));
	}

	/**
	 * On destroy
	 */
	ngOnDestroy(): void {
		this.subscriptions.forEach(sb => sb.unsubscribe());
	}
}
