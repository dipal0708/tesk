import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class DataRoutingService {

  private messageSource = new BehaviorSubject('');
  currentMessage = this.messageSource.asObservable();

  private mappingchnage = new BehaviorSubject('');
  mappingmenuchnage = this.mappingchnage.asObservable();

  constructor() { }

  changeMessage(message: string) {
    this.messageSource.next(message)
  }
  mappingchnageonclick(message: string) {
    this.mappingchnage.next(message)
  }
}