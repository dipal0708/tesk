import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class DataService {

  private messageSource = new BehaviorSubject('');
  private messageSourceDashboard = new BehaviorSubject('');
  currentMessage = this.messageSource.asObservable();
  currentMessageDashboard = this.messageSourceDashboard.asObservable();
  constructor() { }

  changeMessage(message: string) {
      debugger
    this.messageSource.next(message);
  }
  changeMessageDashboard(message) {
    debugger
  this.messageSourceDashboard.next(message);
  }
}