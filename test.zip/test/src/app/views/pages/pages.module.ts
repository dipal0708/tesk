// Angular
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
// NgBootstrap
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// Partials
import { PartialsModule } from '../partials/partials.module';
import { CoreModule } from '../../core/core.module';
import { PopupCommonModule } from '../pages/diamond/common-component/common.module';
import { ExcelService } from '../excel.service';
import { MenuConfigService, SubheaderService, MenuHorizontalService, MenuAsideService } from '../../core/_base/layout';
import { jewelryCommonModule } from './jewellery/common-component/jewelrycommon.module';
//import { DialogDataExampleDialog } from './jewellery/products/jewelry-data-mapping/jewelry-data-mapping.component';
// import { MyretailerComponent } from './retailers/myretailer/myretailer.component';
import { AgmCoreModule } from '@agm/core';
@NgModule({
	declarations: [//DialogDataExampleDialog
	],
	exports: [PopupCommonModule,jewelryCommonModule],
	imports: [
		CommonModule,
		HttpClientModule,
		FormsModule,
		NgbModule,
		CoreModule,
		PartialsModule,
		AgmCoreModule

	],	
	providers: [ExcelService,MenuConfigService,SubheaderService,
		MenuHorizontalService,
		MenuAsideService]
})
export class PagesModule {
}
