// Angular
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
// Lodash
import { shuffle } from 'lodash';
// Services
import { LayoutConfigService } from '../../../core/_base/layout';
// Widgets model
import { SparklineChartOptions } from '../../../core/_base/metronic';

import { ApiService } from '../../../core/services/api.service';
import { map } from 'rxjs/operators';
import { UserService } from '../../../core/services/users.service';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { TranslateService } from '@ngx-translate/core';
import { DataService } from '../../data.service';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
	selector: 'kt-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
	chartOptions1: SparklineChartOptions;
	chartOptions2: SparklineChartOptions;
	chartOptions3: SparklineChartOptions;
	chartOptions4: SparklineChartOptions;
	message:string;
	LineChart=[];
	BarChart=[];
	PieChart=[];
	title: string = 'My first AGM project';
	lat: number = 39.007504;
	lng: number = -94.529625;
	zoom: number = 5;
	companies:any;
	totalDiamonds;
	lastUpdatedDate:any;
	connectRetailers:any;
	markerArray = [{lat:47.751076,lng:-120.740135},
		{lat:39.007504,lng:-94.529625},
		{lat:40.273502,lng:-86.126976},
		{lat:40.730610,lng:-73.935242},
		{lat:35.481918,lng:-97.508469}
	];
	styles: any[] = [
		{elementType: 'geometry', stylers: [{color: '#8b9c8a'}]},
		{elementType: 'labels.text', stylers: [{color: '#F1FFFF'}]},
		{elementType: 'labels.text.stroke', stylers: [{color: '#000000'}]},
		{elementType: 'labels.text.fill', stylers: [{color: '#F1FFFF'}]},
		{featureType: 'water', stylers: [{color: '#00137f'}]},
		{featureType: 'administrative.land_parcel', stylers: [{color: '#f7a900'}]},
		{featureType: 'poi.park', stylers: [{color: '#157200'}]},
		{featureType: 'transit.line', stylers: [{color: '#f4d800'}]},
		{featureType: 'poi.business', stylers: [{color: '#92fcfc'}]},
		{featureType: 'poi.place_of_worship', stylers: [{color: '#ff7777'}]},
		{featureType: 'transit', stylers: [{color: '#ff7777'}]}
	  ];
	  private unsubscribe: Subject<any>;
	constructor(private cdr: ChangeDetectorRef,private service:UserService,private data: DataService,private layoutConfigService: LayoutConfigService, private usersService: UserService,private translate: TranslateService) {		
		this.unsubscribe = new Subject();
	}
	tags: Array<string> = [];
	tagsLoaded = false;
	ngOnInit(): void {
		// var localdata = JSON.parse(localStorage.getItem('userDetail'));
		// this.service.getcompaniesOnly(localdata.pk_id).subscribe((data:any)=>{
		// 		debugger
		// 	var allcompaniesList = data.data;
		// 	localStorage.setItem('userCompany',JSON.stringify(allcompaniesList));
		//   });
	}
	ngAfterViewInit(){
		debugger
		this.companies = JSON.parse(localStorage.getItem('userCompany'));
		debugger
	   var obj = { dealerid: this.companies[0].dealerid }
	   this.service.getDiamondDashboard(obj).pipe(
			   tap(usr => {         
				   debugger
				   if (usr.status==200) {
					   let num :number = Number(usr.totalDiamond[0].count);
			 this.totalDiamonds = num;
			 this.lastUpdatedDate = usr.LastUpdates;
			 let num2 :number = Number( usr.connectedRetailers.rows[0].count);
			 this.connectRetailers =num2;
				   } else {
			 this.totalDiamonds = 0;
				   }
			   }),
			   takeUntil(this.unsubscribe),
			   finalize(() => {
			
				   this.cdr.detectChanges(); 
			   })
		   ).subscribe();
		   this.data.currentMessageDashboard.subscribe(message =>{
			   this.message = message
	   } );
	}
}
