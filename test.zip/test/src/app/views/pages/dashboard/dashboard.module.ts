// Angular
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
// NgBootstrap
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// Core Module
import { CoreModule } from '../../../core/core.module';
import { PartialsModule } from '../../partials/partials.module';
import { DashboardComponent } from './dashboard.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { AgmCoreModule } from '@agm/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule,MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule } from '@angular/material';
import { MatPaginatorModule,MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";

@NgModule({
	imports: [MatTableModule,MatAutocompleteModule,MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule,FormsModule, ReactiveFormsModule,
        MatButtonModule,MatTabsModule,MatCardModule,MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		AgmCoreModule,
		RouterModule.forChild([
			{
				path: '',
				component: DashboardComponent
			},
		]),
		DragDropModule
	],
	providers: [],
	declarations: [
		DashboardComponent,
	]
})
export class DashboardModule {
}
