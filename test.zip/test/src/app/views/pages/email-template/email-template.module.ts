// Angular
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
// NgBootstrap
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// Core Module
import { CoreModule } from '../../../core/core.module';
import { PartialsModule } from '../../partials/partials.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule,MatButtonModule,MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule } from '@angular/material';
import { TranslateModule } from '@ngx-translate/core'; 
import { EmailTemplateComponent } from './email-template.component';
import { TranslateService } from '@ngx-translate/core';
import { MatPaginatorModule } from '@angular/material';
import { MatSortModule } from '@angular/material/sort';
import { RichTextEditorModule } from '@syncfusion/ej2-angular-richtexteditor';
@NgModule({
	imports: [
		TranslateModule,MatTableModule ,
		MatButtonModule,MatTabsModule,MatCardModule,MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
		FormsModule, ReactiveFormsModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		MatSortModule,
		RichTextEditorModule,
		MatPaginatorModule,
		RouterModule.forChild([
			{
				path: '',
				component: EmailTemplateComponent
			},
		]),
		
	],
	providers: [],
	declarations: [
		EmailTemplateComponent,		
	],
	exports: [FormsModule, ReactiveFormsModule,MatTableModule,MatPaginatorModule ],
})
export class emailTemplateModule {
}
