// Angular
import { ChangeDetectorRef, Component, ViewChild, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// RxJS
import { Observable, Subject } from 'rxjs';
import { finalize, takeUntil, tap } from 'rxjs/operators';
// Translate
import { TranslateService } from '@ngx-translate/core';
// Store
import { Store } from '@ngrx/store';
import { AppState } from '../../../core/reducers';
// Auth
import { AuthNoticeService, AuthService, Login } from '../../../core/auth';
import { CognitoCallback, LoggedInCallback } from '../../../core/services/cognito.service';
import { environment } from '../../../../environments/environment';
import { User } from '../../../core/auth/_models/user.model';
import { TranslationService } from '../../../core/_base/metronic';
import { UserService } from '../../../core/services/users.service';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { ConfirmPopupboxComponent } from '../../pages/diamond/common-component/confirm-popupbox/confirm-popupbox.component';
import { ToolbarService, LinkService, ImageService, HtmlEditorService, QuickToolbarService } from '@syncfusion/ej2-angular-richtexteditor';
import { FormControl, FormGroupDirective, NgForm } from '@angular/forms';
const USER = {
	EMAIL: '',
	PASSWORD: ''
};

@Component({
	selector: 'kt-email-template',
	templateUrl: './email-template.component.html',
	styleUrls: ['./email-template.component.scss'],
	providers: [ToolbarService, LinkService, ImageService, HtmlEditorService, QuickToolbarService]
})
export class EmailTemplateComponent implements OnInit {
	isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
		const isSubmitted = form && form.submitted;
		return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
	}

	public value: string;
	public tools: object = {
		items: ['Undo', 'Redo', '|', 'Bold', 'Italic', 'Underline', 'StrikeThrough', '|', 'FontName', 'FontSize', 'FontColor', 'BackgroundColor', '|', 'SubScript', 'SuperScript', '|',
			'LowerCase', 'UpperCase', '|',
			'Formats', 'Alignments', '|', 'OrderedList', 'UnorderedList', '|',
			'Indent', 'Outdent', '|', 'CreateLink', 'CreateTable',
			'Image', '|', 'ClearFormat', 'Print', 'SourceCode', '|', 'FullScreen']
	};
	public quickTools: object = {
		image: [
			'Replace', 'Align', 'Caption', 'Remove', 'InsertLink', '-', 'Display', 'AltText', 'Dimension']
	};

	@ViewChild(MatPaginator) paginator: MatPaginator;
	@ViewChild(MatSort) sort: MatSort;
	dataSource: MatTableDataSource<any>;
	defaultRTE: any;
	searchbox1: string;
	selected = 'English';
	// Public params
	selectedIndex: number = 0;
	emailTemplateform: FormGroup;
	loading = false;
	isLoggedIn$: Observable<boolean>;
	errors: any = [];
	email: string;
	password: string;
	errorMessage: string;
	mfaStep = false;
	emailvalidate: any = true;
	emailtemplateAlldata: any = [];
	updatebyPk: any = [];
	btnHideshow: boolean = false;
	mfaData = {
		destination: '',
		callback: null
	};
	displayedColumns: string[] = ['email_type', 'email_subject', 'action'];
	userDetail: any = [];
	//   dataSource:any = [];
	resultsLength = 0;

	private unsubscribe: Subject<any>;

	/**
	 * Component constructor
	 *
	 * @param router: Router
	 * @param auth: AuthService
	 * @param authNoticeService: AuthNoticeService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 * @param fb: FormBuilder
	 * @param cdr
	 */
	constructor(
		private dialog: MatDialog,
		private router: Router,
		private auth: AuthService,
		private authNoticeService: AuthNoticeService,
		private translate: TranslateService,
		private store: Store<AppState>,
		private fb: FormBuilder,
		private cdr: ChangeDetectorRef,
		private translationService: TranslationService,
		private service: UserService,
		private toastr: ToastrService
	) {
		this.unsubscribe = new Subject();
		// this.matdatasource = new MatTableDataSource([]);
		this.dataSource = new MatTableDataSource<any>([]);
		this.dataSource.paginator = this.paginator;
		this.dataSource.sort = this.sort;
	}

	ngOnInit() {
		this.userDetail = JSON.parse(localStorage.getItem('userDetail2'));
		this.getAllemailtemplate();
		this.initLoginForm();


	}
	getAllemailtemplate() {
		// this.service.getallEmailTemplate().subscribe((data:any)=>{
		// 	
		// 	this.emailtemplateAlldata = data.data;
		// 	this.dataSource = this.emailtemplateAlldata;
		// });
		this.service.getallEmailTemplate(this.userDetail.pk_id).subscribe((data: any) => {
			
			this.emailtemplateAlldata = data.data;
			this.dataSource.data = this.emailtemplateAlldata;
			this.dataSource.paginator = this.paginator;
			this.dataSource.sort = this.sort;
		});
	}

	ngOnDestroy(): void {
		this.authNoticeService.setNotice(null);
		this.unsubscribe.next();
		this.unsubscribe.complete();
		this.loading = false;
	}

	initLoginForm() {
		this.emailTemplateform = this.fb.group({
			emailtype: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
			emailbody: [''],
			emailsubject: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
			emaillanguage: ['', [Validators.required]],
		});
	}

	/**
	 * Form Submit
	 */
	submit() {
		

		if (this.emailTemplateform.invalid) {
			this.toastr.error(this.translate.instant('Invalid Entry'), 'Error');
			return
		}
		if (this.value == undefined || this.value == "") {
			this.toastr.error('Please Design Email Template');
			return
		}
		if (this.selectedIndex != 1) {
			this.selectedIndex = this.selectedIndex + 1;
		}

		
		var obj = {
			email_type: this.emailTemplateform.value.emailtype,
			email_subject: this.emailTemplateform.value.emailsubject,
			email_body: this.value,
			created_by: this.userDetail.pk_id,
			created_date: "2019-04-11",
			deleted_by: "delketeby",
			en_english: this.emailTemplateform.value.emaillanguage === 'English' ? "Yes" : "No",
			es_spenish: this.emailTemplateform.value.emaillanguage !== 'English' ? "Yes" : "No",
			updated_by: this.userDetail.pk_id,
			updated_date: "2019-04-11"

		};
		this.service.postEmailtemplate(obj).subscribe((data: any) => {
			
			this.getAllemailtemplate();
			this.emailTemplateform.reset();
			this.value = "";
		});
	}
	onEditclick(data) {
		
		if (this.selectedIndex != 0) {
			this.selectedIndex = this.selectedIndex - 1;
		}
		this.service.getemailtemplatebyId(data.pk_id).subscribe((data: any) => {
			
			var emailTempInfo = data.data[0];
			var language = emailTempInfo.en_english == 'Yes' ? "English" : "Spanish";
			this.updatebyPk = data.data[0].pk_id;
			this.emailTemplateform.controls['emailtype'].setValue(emailTempInfo.email_type);
			this.emailTemplateform.controls['emailsubject'].setValue(emailTempInfo.email_subject);
			this.value = emailTempInfo.email_body;
			// this.emailTemplateform.controls['emailbody'].setValue(emailTempInfo.email_body);
			this.emailTemplateform.controls['emaillanguage'].setValue(language);
		});
		this.btnHideshow = true;
	};
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.emailTemplateform.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}
	onDeleteClick(data) {
		const dialogRef = this.dialog.open(ConfirmPopupboxComponent, {
			data: {
				msg: " Are You Sure Want To Delete ?",
				button: "Delete"
			}
		});
		dialogRef.afterClosed().subscribe(result => {
			
			if (!result) {
				return
			}
			if (result == "Yes") {
				
				this.service.deleteEmailTemplate(data.pk_id).subscribe((data: any) => {
					
					this.getAllemailtemplate();
					this.toastr.success('Delete Template Successfully..');
				});
			}
		});
	}
	onUpdateclick() {
		if (this.emailTemplateform.invalid) {
			this.toastr.error(this.translate.instant('Invalid Entry'), 'Error');
			return
		}
		
		if (this.selectedIndex != 1) {
			this.selectedIndex = this.selectedIndex + 1;
		}
		var obj = {
			pk_id: this.updatebyPk,
			email_type: this.emailTemplateform.value.emailtype,
			email_subject: this.emailTemplateform.value.emailsubject,
			email_body: this.value,
			created_by: this.userDetail.pk_id,
			created_date: "2019-04-11",
			deleted_by: "delketeby",
			en_english: "englishtext",
			es_spenish: "spaneis",
			updated_by: this.userDetail.pk_id,
			updated_date: "2019-04-11"
		};
		this.service.updateEmailtemplate(obj).subscribe((data: any) => {
			
			this.getAllemailtemplate();
			this.emailTemplateform.reset();
			this.value = "";
			this.btnHideshow = false;

		});

	}
	onclickAddnew() {
		
		this.emailTemplateform.reset();
		this.btnHideshow = false;
		this.updatebyPk = null;
		this.value = "";
		if (this.selectedIndex != 0) {
			this.selectedIndex = this.selectedIndex - 1;
		}

	}
	yourFn($event) {
		
		if ($event.index == 0) {
			this.selectedIndex = 0;
		}
		if ($event.index == 1) {
			this.selectedIndex = 1;
		}
	}
	applyFilter(filterValue: string) {
		filterValue = filterValue.trim(); // Remove whitespace
		filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
		this.dataSource.filter = filterValue;
	}
}
