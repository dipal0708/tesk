import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatenewcompanyPopupboxComponent } from './createnewcompany-popupbox.component';

describe('CreatenewcompanyPopupboxComponent', () => {
  let component: CreatenewcompanyPopupboxComponent;
  let fixture: ComponentFixture<CreatenewcompanyPopupboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatenewcompanyPopupboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatenewcompanyPopupboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
