import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'kt-confirm-dialogbox',
  templateUrl: './confirm-dialogbox.component.html',
  styleUrls: ['./confirm-dialogbox.component.scss']
})

export class ConfirmDialogboxComponent implements OnInit {
  // @Inject(MAT_DIALOG_DATA) public data: DialogData)
  oldPassword:any;
  newPassword:any;
  htmlContent: string;
  requiredmsg:boolean=true;
  requiredlengthmsg:boolean=false;
  requiredlengthmsgsame:boolean=false;
  constructor(  @Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<ConfirmDialogboxComponent>) { 

  };
 
  ngOnInit() {
    
    console.log(this.data)
    this.oldPassword = this.data.Password;
  }
  onNoClick(): void {
    
    this.dialogRef.close("No");
  }
  onSearchChange(value){
    
    this.requiredmsg = true;
    this.requiredlengthmsg = false;
    if(value != ""){
      this.requiredmsg = false;
      this.requiredlengthmsg = true;
      this.requiredlengthmsgsame = false;
      if(value.length >= 8){
        this.requiredlengthmsg = false;
      }
      if(this.oldPassword == this.newPassword){
        this.requiredlengthmsgsame = true
        return
      }
    }
  }
  onYesClick():void{
    if(this.newPassword && this.requiredlengthmsg == false && this.requiredlengthmsgsame == false){
      if(this.requiredlengthmsg == false){
        this.dialogRef.close(this.newPassword);
      }
    }
  }

}
