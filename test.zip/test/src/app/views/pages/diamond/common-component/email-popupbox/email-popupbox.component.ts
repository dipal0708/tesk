import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { SafeHtml } from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { MyErrorStateMatcher } from '../../../auth/MyErrorStateMatcher';

@Component({
  selector: 'kt-email-popupbox',
  templateUrl: './email-popupbox.component.html',
  styleUrls: ['./email-popupbox.component.scss']
})
export class EmailPopupboxComponent implements OnInit {
  emailpopupForm: FormGroup;
  itemName:string;
  constructor(private fb: FormBuilder, @Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<EmailPopupboxComponent>) { }
  matcher = new MyErrorStateMatcher();
  ngOnInit() {
    console.log(this.data)
   
    this.itemName = this.data.msg;

    this.initLoginForm();
  }
  isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.emailpopupForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}
  initLoginForm() {
		this.emailpopupForm = this.fb.group({
      name: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			email: ['', Validators.compose([
        Validators.required,
        Validators.email,
			])
      ],
      markup: ['', Validators.compose([
				Validators.required,
				Validators.minLength(1),
				Validators.maxLength(4)
			])
			],
			message: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(200)
			])
      ],
    });
  }
  closeClick(){
    this.dialogRef.close();
  }
  sendClick(){
    if(this.emailpopupForm.invalid){
      return
    }
    this.dialogRef.close(this.emailpopupForm.value);
  }

}

