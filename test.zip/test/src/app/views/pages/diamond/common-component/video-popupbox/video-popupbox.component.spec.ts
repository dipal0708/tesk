import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VideoPopupboxComponent } from './video-popupbox.component';

describe('VideoPopupboxComponent', () => {
  let component: VideoPopupboxComponent;
  let fixture: ComponentFixture<VideoPopupboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VideoPopupboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VideoPopupboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
