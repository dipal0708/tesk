import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { DomSanitizer } from "@angular/platform-browser";

@Component({
  selector: 'kt-video-popupbox',
  templateUrl: './video-popupbox.component.html',
  styleUrls: ['./video-popupbox.component.scss']
})
export class VideoPopupboxComponent implements OnInit {
  itemName:any;
  filename:any;
  constructor( @Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<VideoPopupboxComponent>,private sanitizer: DomSanitizer)  {  }

  ngOnInit() {
    console.log(this.data)
   debugger
    this.itemName = this.data.msg;
    this.filename = this.sanitizer.bypassSecurityTrustResourceUrl(this.data.filename); //'https://player.vimeo.com/video/91011121' ;//this.data.filename;
  }
  close(){
    this.dialogRef.close();
  }
  photoURL(){
    debugger
    return this.filename;
  }

}
