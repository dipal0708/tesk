import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversationPopupComponent } from './conversation-popup.component';

describe('ConversationPopupComponent', () => {
  let component: ConversationPopupComponent;
  let fixture: ComponentFixture<ConversationPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConversationPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConversationPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
