import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmPopupboxComponent } from './confirm-popupbox.component';

describe('ConfirmPopupboxComponent', () => {
  let component: ConfirmPopupboxComponent;
  let fixture: ComponentFixture<ConfirmPopupboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmPopupboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmPopupboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
