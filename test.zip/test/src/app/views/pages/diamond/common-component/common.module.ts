import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VideoPopupboxComponent } from '../common-component/video-popupbox/video-popupbox.component';
import { EmailPopupboxComponent } from './email-popupbox/email-popupbox.component';
import { ConfirmPopupboxComponent } from '../common-component/confirm-popupbox/confirm-popupbox.component';
import { CreatenewcompanyPopupboxComponent } from './createnewcompany-popupbox/createnewcompany-popupbox.component';
// import { FiltersComponent } from '../common-component/filters/filters.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule, MatDividerModule, MatRadioModule, MatSliderModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";
import { CommonModule } from '@angular/common';
import { Ng5SliderModule } from 'ng5-slider';
import { ConfirmDialogboxComponent } from './confirm-dialogbox/confirm-dialogbox.component';
import { FancyDiamondFilterComponent } from './fancy-diamond-filter/fancy-diamond-filter.component';
import { InviteRetailerPopupboxComponent } from './invite-retailer-popupbox/invite-retailer-popupbox.component';
import { RichTextEditorModule } from '@syncfusion/ej2-angular-richtexteditor';
import { ConversationPopupComponent } from './conversation-popup/conversation-popup.component';

const PopupCommonRoutes: Routes = [
//   {
//     path: '',
//     component: DiamondSearchComponent

//   }, {
//     path: 'createuser',
//     component: CreateUserComponent
//   }, {
//     path: 'diamondImport',
//     component: DiamondFileUploadComponent
//   },{
//     path: 'diamondMapping',
//     component: DiamondMappingComponent
//   }
];
@NgModule({
  declarations: [VideoPopupboxComponent,EmailPopupboxComponent,ConfirmPopupboxComponent,CreatenewcompanyPopupboxComponent,ConfirmDialogboxComponent, FancyDiamondFilterComponent, InviteRetailerPopupboxComponent, ConversationPopupComponent],
  imports: [RichTextEditorModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
    CommonModule,MatDividerModule,
		Ng5SliderModule,
		MatRadioModule,
		MatSliderModule,
  ],
  exports:[InviteRetailerPopupboxComponent,FancyDiamondFilterComponent,EmailPopupboxComponent,VideoPopupboxComponent,ConfirmPopupboxComponent,CreatenewcompanyPopupboxComponent,ConversationPopupComponent],
  entryComponents:[InviteRetailerPopupboxComponent,FancyDiamondFilterComponent,EmailPopupboxComponent,VideoPopupboxComponent,ConfirmPopupboxComponent,CreatenewcompanyPopupboxComponent,ConversationPopupComponent]
})
export class PopupCommonModule { }
 