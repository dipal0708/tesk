import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FancyDiamondFilterComponent } from './fancy-diamond-filter.component';

describe('FancyDiamondFilterComponent', () => {
  let component: FancyDiamondFilterComponent;
  let fixture: ComponentFixture<FancyDiamondFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FancyDiamondFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FancyDiamondFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
