import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InviteRetailerPopupboxComponent } from './invite-retailer-popupbox.component';

describe('InviteRetailerPopupboxComponent', () => {
  let component: InviteRetailerPopupboxComponent;
  let fixture: ComponentFixture<InviteRetailerPopupboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InviteRetailerPopupboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InviteRetailerPopupboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
