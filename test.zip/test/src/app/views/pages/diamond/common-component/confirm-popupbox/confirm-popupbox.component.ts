import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { SafeHtml } from '@angular/platform-browser';
import {  ViewChild, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { createElement, KeyboardEventArgs , addClass, removeClass, Browser } from '@syncfusion/ej2-base';


@Component({
  selector: 'kt-confirm-popupbox',
  templateUrl: './confirm-popupbox.component.html',
  styleUrls: ['./confirm-popupbox.component.scss']
})
export class ConfirmPopupboxComponent implements OnInit {
  itemName:any;
  newPassword:any;
  buttonName:any;
  htmlContent: string;
  public tools: object = {
    items: ['Bold', 'Italic', 'StrikeThrough', '|',
    'Formats', 'OrderedList', 'UnorderedList', '|',
    'CreateLink', '|', 'Undo', 'Redo']
};
  constructor(  @Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<ConfirmPopupboxComponent>)  { 


  }

  ngOnInit() {
    console.log(this.data)
   
    this.itemName = this.data.msg;
    this.buttonName = this.data.button;
  }
  onNoClick(): void {
   
    this.dialogRef.close("No");

  }
  onYesClick():void{
   
    this.dialogRef.close('Yes');
    // this.data = "Yes";
  }

}
