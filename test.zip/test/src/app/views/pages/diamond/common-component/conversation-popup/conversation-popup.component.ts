import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { SafeHtml } from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { MyErrorStateMatcher } from '../../../auth/MyErrorStateMatcher';

@Component({
  selector: 'kt-conversation-popup',
  templateUrl: './conversation-popup.component.html',
  styleUrls: ['./conversation-popup.component.scss']
})
export class ConversationPopupComponent implements OnInit {
  message;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<ConversationPopupComponent>) { }

  ngOnInit() {
  }
  SendConversation(){
    debugger
    this.dialogRef.close(this.message);
  }

}
