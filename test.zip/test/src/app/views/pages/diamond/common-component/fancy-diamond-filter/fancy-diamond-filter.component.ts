import { Component, OnInit,Inject, ViewEncapsulation } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { Options } from 'ng5-slider';
import { UserService } from '../../../../../core';
import { FormBuilder, FormGroup,FormControl , Validators } from '@angular/forms';

@Component({
  selector: 'kt-fancy-diamond-filter',
  templateUrl: './fancy-diamond-filter.component.html',
  styleUrls: ['./fancy-diamond-filter.component.scss']
})
export class FancyDiamondFilterComponent implements OnInit {
  filterDiamondForm: FormGroup;
  filter;
  shapestring:any;
  diamondculet:any=[];
	diamondclarity:any=[];
	diamondshape:any=[];
	diamondpolish:any=[];
	diamondsymmetry:any=[];
	diamondfluorescence:any=[];
	diamondculetcondition:any=[];
	diamondgirdle:any=[];
	diamondcutgrade:any=[];
	diamondfancycolor:any=[];
  diamondintensity:any=[];
  diamond_certificate:any=[];
  Video;
  companies:any=[];
  showSlider:boolean= false ;
  minValue1: number = 0;
  maxValue1: number = 20;
  minValue2: number = 0;
  maxValue2: number = 100000;
  minValue3: number = 0;
  maxValue3: number = 100000;
  minValue4: number = 0;
  maxValue4: number = 10;
  options: Options = {
    floor: 0,
    ceil: 20,
     step: 0.1
  };
  options2: Options = {
    floor: 0,
    ceil: 100000,
     step: 20
  };
  options3: Options = {
    floor: 0,
    ceil: 100000,
     step: 100
  };
  options4: Options = {
    floor: 0,
    ceil: 10,
     step: 0.1
  };
  itemName:any;
  newPassword:any;
  htmlContent: string;
  ShowMoreFilter:boolean=false;
  shapeArray:any=[];
  status: boolean = false;
  dropdownArray = [{dealers:'Dealer 0', certificate:'Certificate 0'},
  {dealers:'Dealer 1', certificate:'Certificate 1'},
  {dealers:'Dealer 2', certificate:'Certificate 2'},
  {dealers:'Dealer 3', certificate:'Certificate 3'},
  {dealers:'Dealer 4', certificate:'Certificate 4'},
  {dealers:'Dealer 5', certificate:'Certificate 5'}];
  colorArray = ['D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
  numericArray = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15'];
  cutradeArray = ['Ideal','Excellent','Very Good','Good','Fair'];
  MatchedPairsArray = ['Search All Stones','Search Single Stone','Search Match Pair'];
  imageArray=[{id:1,imageUrl:"../../assets/media/diamondImages/Asscher_65x65.jpg",shape:'Asscher',status:false},
  {id:2,imageUrl:'../../assets/media/diamondImages/Cushion_65x65.jpg',shape:'Cushion',status:false},
  {id:3,imageUrl:'../../assets/media/diamondImages/Emerald_65x65.jpg',shape:'Emerald',status:false},
  {id:4,imageUrl:'../../assets/media/diamondImages/Heart_65x65.jpg',shape:'Heart',status:false},
  {id:5,imageUrl:'../../assets/media/diamondImages/Marquise_65x65.jpg',shape:'Marquise',status:false},
  {id:6,imageUrl:'../../assets/media/diamondImages/Oval_65x65.jpg',shape:'Oval',status:false},
  {id:7,imageUrl:'../../assets/media/diamondImages/Pear_65x65.jpg',shape:'Pear',status:false},
  {id:8,imageUrl:'../../assets/media/diamondImages/Princess_65x65.jpg',shape:'Princess',status:false},
  {id:8,imageUrl:'../../assets/media/diamondImages/Radiant_65x65.jpg',shape:'Radiant',status:false},
  {id:8,imageUrl:'../../assets/media/diamondImages/Round_65x65.jpg',shape:'Round',status:false}];

  colorimageArray=[{id:1,imageUrl:"../../assets/media/diamondImages/Blue.png",shape:'Blue',status:false},
  {id:2,imageUrl:'../../assets/media/diamondImages/Pink.png',shape:'Pink',status:false},
  {id:3,imageUrl:'../../assets/media/diamondImages/Yellow.png',shape:'Yellow',status:false},
  {id:4,imageUrl:'../../assets/media/diamondImages/Champagne.png',shape:'Brown',status:false},
  {id:5,imageUrl:'../../assets/media/diamondImages/Green.png',shape:'Green',status:false},
  {id:6,imageUrl:'../../assets/media/diamondImages/Gray.png',shape:'Gray',status:false},
  {id:7,imageUrl:'../../assets/media/diamondImages/Black.png',shape:'Black',status:false},
  {id:8,imageUrl:'../../assets/media/diamondImages/Red.png',shape:'Red',status:false},
  {id:9,imageUrl:'../../assets/media/diamondImages/Purple.png',shape:'Purple',status:false},
  {id:10,imageUrl:'../../assets/media/diamondImages/Chameleon.png',shape:'Chameleon',status:false},
  {id:11,imageUrl:'../../assets/media/diamondImages/Violet.png',shape:'Violet',status:false}];
  Permission:any=['Private','Public'];
  InclusionRange:any=['Light','Medium','Heavy'];
  Eyeclean:any=['Yes','Border Line','No']
  constructor(private fb: FormBuilder,private service:UserService, @Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<FancyDiamondFilterComponent>)  { 

   }
  ngOnInit() {
    debugger
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this.initLoginForm();
    this.getAlldropdownValue();
  }
  initLoginForm() {
		this.filterDiamondForm = this.fb.group({
      shape:[''],
			dealers:[''],
      certificate: [''],
      cutStart: [''],
      cutEnd: [''],
      caretStart: [''],
      caretEnd: [''],
      priceStart: [''],
      priceEnd: [''],
      priceCaretStart: [''],
      priceCaretEnd: [''],
      clarityStart: [''],
      clarityEnd: [''],
      colorStart: [''],
      colorEnd: [''],
      depthStart: [''],
      depthEnd: [''],
      tableStart: [''],
      tableEnd: [''],
      polishStart: [''],
      polishEnd: [''],
      lengthStart: [''],
      lengthEnd: [''],
      widthStart: [''],
      widthEnd: [''],
      heightStart: [''],
      heightEnd: [''],
      symmetryStart: [''],
      symmetryEnd: [''],
      gridelStart: [''],
      gridelEnd: [''],
      crownangleStart: [''],
      crownangleEnd: [''],
      pavillionangleStart: [''],
      pavillionangleEnd: [''],
      culetStart: [''],
      culetEnd: [''],
      culetConditionStart: [''],
      culetConditionEnd: [''],
      fluorescenceStart: [''],
      fluorescenceEnd: [''],
			matchedPairs: [''],
			hasvideo: ['']
		});
	}
  cencelClick(){
    this.dialogRef.close()
  }
  onNoClick(): void {
   
    this.dialogRef.close("No");
  }
  showLessClick(){
    this.ShowMoreFilter = false;
  }
  showMoreClick(){
    this.ShowMoreFilter = true;
  }
  applyFilterclick(){
    debugger
    this.Video;
    var stringifyData =  JSON.stringify(this.shapeArray);
    var getstringifyDataLength = stringifyData.length;
    var compresdLength = getstringifyDataLength - 4;
    var dsads = stringifyData.substr(2,compresdLength);
    var postTring = dsads.replace(/"/g, "'");
    this.filterDiamondForm.value.shape = postTring;
    this.filterDiamondForm.value.caretStart =  this.minValue1==0?0:this.minValue1;
    this.filterDiamondForm.value.caretEnd = this.maxValue1==20?20:this.maxValue1;
    this.filterDiamondForm.value.priceStart = this.minValue2==0?0:this.minValue2;
    this.filterDiamondForm.value.priceEnd = this.maxValue2==100000?100000:this.maxValue2;
    this.filterDiamondForm.value.priceCaretStart =  this.minValue3==0?0:this.minValue3;
    this.filterDiamondForm.value.priceCaretEnd = this.maxValue3==100000?100000:this.maxValue3;
    this.filterDiamondForm.value.dialerid =this.companies[0].dealerid;// 720; 
    debugger
    var datastring = JSON.stringify(this.filterDiamondForm.value).replace(/null/g, '""');
    var filterData = JSON.parse(datastring);
    this.dialogRef.close(filterData);
    localStorage.setItem('FilterValues',JSON.stringify(datastring));
  }
  getAlldropdownValue(){
    setTimeout(() => {
    this.service.getalldropdownItems().subscribe((data:any)=>{
			this.diamondculet = data.diamondculet;
			this.diamondclarity = data.diamondclarity;
			this.diamondshape = data.diamondshape;
			this.diamondpolish = data.diamondpolish;
			this.diamondsymmetry = data.diamondsymmetry;
			this.diamondfluorescence = data.diamondfluorescence;
			this.diamondculetcondition = data.diamondculetcondition;
			this.diamondgirdle = data.diamondgirdle;
			this.diamondcutgrade = data.diamondcutgrade;
			this.diamondfancycolor = data.diamondfancycolor;
      this.diamondintensity = data.diamondintensity;
      this.diamond_certificate = data.diamond_certificate;
      
    });
    this.showSlider = true;
  },400);
    debugger
    var filterDataString = localStorage.getItem('FilterValues');
    var filterData0 = JSON.parse(filterDataString);
    var filterData = JSON.parse(filterData0);
    if(filterData){
      this.filterDiamondForm.controls['certificate'].setValue(filterData.certificate);

      this.filterDiamondForm.controls['cutStart'].setValue(filterData.cutStart);
      this.filterDiamondForm.controls['cutEnd'].setValue(filterData.cutEnd);
  
      this.minValue1 = filterData.caretStart;
      this.maxValue1 = filterData.caretEnd;
  
      this.minValue2 = filterData.priceStart;
      this.maxValue2 = filterData.priceEnd;
  
      this.minValue3 = filterData.priceCaretStart;
      this.maxValue3 = filterData.priceCaretEnd;
  
      this.filterDiamondForm.controls['clarityStart'].setValue(filterData.clarityStart);
      this.filterDiamondForm.controls['clarityEnd'].setValue(filterData.clarityEnd);
  
      this.filterDiamondForm.controls['colorStart'].setValue(filterData.colorStart);
      this.filterDiamondForm.controls['colorEnd'].setValue(filterData.colorEnd);
  
      this.filterDiamondForm.controls['depthStart'].setValue(filterData.depthStart);
      this.filterDiamondForm.controls['depthEnd'].setValue(filterData.depthEnd);
  
      this.filterDiamondForm.controls['tableStart'].setValue(filterData.tableStart);
      this.filterDiamondForm.controls['tableEnd'].setValue(filterData.tableEnd);
  
      this.filterDiamondForm.controls['polishStart'].setValue(filterData.polishStart);
      this.filterDiamondForm.controls['polishEnd'].setValue(filterData.polishEnd);
  
      this.filterDiamondForm.controls['lengthStart'].setValue(filterData.lengthStart);
      this.filterDiamondForm.controls['lengthEnd'].setValue(filterData.lengthEnd);
  
      this.filterDiamondForm.controls['widthStart'].setValue(filterData.widthStart);
      this.filterDiamondForm.controls['widthEnd'].setValue(filterData.widthEnd);
  
      this.filterDiamondForm.controls['heightStart'].setValue(filterData.heightStart);
      this.filterDiamondForm.controls['heightEnd'].setValue(filterData.heightEnd);
  
      this.filterDiamondForm.controls['symmetryStart'].setValue(filterData.symmetryStart);
      this.filterDiamondForm.controls['symmetryEnd'].setValue(filterData.symmetryEnd);
  
      this.filterDiamondForm.controls['gridelStart'].setValue(filterData.gridelStart);
      this.filterDiamondForm.controls['gridelEnd'].setValue(filterData.gridelEnd);
  
      this.filterDiamondForm.controls['crownangleStart'].setValue(filterData.crownangleStart);
      this.filterDiamondForm.controls['crownangleEnd'].setValue(filterData.crownangleEnd);
  
      this.filterDiamondForm.controls['pavillionangleStart'].setValue(filterData.pavillionangleStart);
      this.filterDiamondForm.controls['pavillionangleEnd'].setValue(filterData.pavillionangleEnd);
  
      this.filterDiamondForm.controls['culetStart'].setValue(filterData.culetStart);
      this.filterDiamondForm.controls['culetEnd'].setValue(filterData.culetEnd);
  
      this.filterDiamondForm.controls['culetConditionStart'].setValue(filterData.culetConditionStart);
      this.filterDiamondForm.controls['culetConditionEnd'].setValue(filterData.culetConditionEnd);
  
      this.filterDiamondForm.controls['fluorescenceStart'].setValue(filterData.fluorescenceStart);
      this.filterDiamondForm.controls['fluorescenceEnd'].setValue(filterData.fluorescenceEnd);
  
      this.filterDiamondForm.controls['matchedPairs'].setValue(filterData.matchedPairs);
    this.filterDiamondForm.controls['hasvideo'].setValue(filterData.hasvideo);
  
    }
    
  }
  imageClick(img){
     
     img.status == true? img.status = false : img.status = true;
    var exist = this.shapeArray.filter(x=>x == img.shape);
    if(exist.length != 0){
      const index: number = this.shapeArray.indexOf(img.shape);
      if (index !== -1) {
          this.shapeArray.splice(index, 1);
      }
    }
    else{
      this.shapeArray.push(img.shape);
      this.shapestring = this.shapestring + img.shape;
    }
  }
  resetClick(){
    this.filterDiamondForm.reset();
    localStorage.removeItem('FilterValues');
    this.minValue1 = 0;
    this.maxValue1 = 20;
    this.minValue2 = 0;
    this.maxValue2 = 100000;
    this.minValue3 = 0;
    this.maxValue3 = 100000;
  }

  onKeyPress(event: any) {
		//alert(this.companyeditform1.value.size);
		var charCode = (event.which) ? event.which : event.keyCode;
		// if(!(charCode > 31 && (charCode < 48 || charCode > 57) ))
		//   return false;
		// else
		//   return false;
		if (charCode == 46)
			return true;
		else
			return !(charCode > 31 && (charCode < 48 || charCode > 57));
	}
}
