import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondPurchaseorderComponent } from './diamond-purchaseorder.component';

describe('DiamondPurchaseorderComponent', () => {
  let component: DiamondPurchaseorderComponent;
  let fixture: ComponentFixture<DiamondPurchaseorderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondPurchaseorderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondPurchaseorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
