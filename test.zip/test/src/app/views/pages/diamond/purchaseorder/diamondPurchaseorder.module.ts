import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule,MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule } from '@angular/material';
import { MatExpansionModule,MatDividerModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule ,MatRadioModule} from "@angular/material";
import { DiamondPurchaseorderComponent } from './diamond-purchaseorder/diamond-purchaseorder.component';
import { DiamondPurchaseorderHistoryComponent } from './diamond-purchaseorder-history/diamond-purchaseorder-history.component';



const diamondRoutes: Routes = [
    {
        path :'diamondpurchaseorder',
        component:DiamondPurchaseorderComponent
      },
      {
        path :'diamondpurchaseorderhistory',
        component:DiamondPurchaseorderHistoryComponent
      }
];

@NgModule({
  declarations: [DiamondPurchaseorderComponent, DiamondPurchaseorderHistoryComponent],
  imports: [MatDatepickerModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,MatRadioModule,
    CommonModule,MatDividerModule,
    RouterModule.forChild(diamondRoutes),
    ],

})
export class DiamondPurchaseOrderModule { }
