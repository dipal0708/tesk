import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-diamond-purchaseorder-history',
  templateUrl: './diamond-purchaseorder-history.component.html',
  styleUrls: ['./diamond-purchaseorder-history.component.scss']
})
export class DiamondPurchaseorderHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
