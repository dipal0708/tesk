import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-diamond-purchaseorder',
  templateUrl: './diamond-purchaseorder.component.html',
  styleUrls: ['./diamond-purchaseorder.component.scss']
})
export class DiamondPurchaseorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
