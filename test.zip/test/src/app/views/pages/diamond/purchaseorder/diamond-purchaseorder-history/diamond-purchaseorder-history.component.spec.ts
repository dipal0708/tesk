import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondPurchaseorderHistoryComponent } from './diamond-purchaseorder-history.component';

describe('DiamondPurchaseorderHistoryComponent', () => {
  let component: DiamondPurchaseorderHistoryComponent;
  let fixture: ComponentFixture<DiamondPurchaseorderHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondPurchaseorderHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondPurchaseorderHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
