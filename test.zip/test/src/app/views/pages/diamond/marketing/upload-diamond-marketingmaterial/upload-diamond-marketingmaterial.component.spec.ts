import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadDiamondMarketingmaterialComponent } from './upload-diamond-marketingmaterial.component';

describe('UploadDiamondMarketingmaterialComponent', () => {
  let component: UploadDiamondMarketingmaterialComponent;
  let fixture: ComponentFixture<UploadDiamondMarketingmaterialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadDiamondMarketingmaterialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadDiamondMarketingmaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
