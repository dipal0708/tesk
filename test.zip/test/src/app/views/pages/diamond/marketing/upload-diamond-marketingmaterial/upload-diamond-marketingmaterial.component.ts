import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../../../../../../environments/environment';
import { UserService } from '../../../../../core/services/users.service';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';
@Component({
  selector: 'kt-upload-diamond-marketingmaterial',
  templateUrl: './upload-diamond-marketingmaterial.component.html',
  styleUrls: ['./upload-diamond-marketingmaterial.component.scss']
})
export class UploadDiamondMarketingmaterialComponent implements OnInit {
  uploadedFilename:any;
  uploadedFiles: Array < File > ;
  companies:any=[];
  foldername='';
  private unsubscribe: Subject<any>;
  constructor(private cdr: ChangeDetectorRef,public http:HttpClient,private toastr: ToastrService,private service:UserService) {
    this.unsubscribe = new Subject();
   }

  ngOnInit() {
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
  }
fileChange(element) {
  this.uploadedFiles = element.target.files;
  this.uploadedFilename = this.uploadedFiles[0].name;
}
upload() {  
  debugger
  let formData = new FormData();
  for (var i = 0; i <= this.uploadedFiles.length - 1; i++) {
    formData.append("uploads[]", this.uploadedFiles[i], this.uploadedFiles[i].name);
    formData.append("dealerid[]",this.companies[0].dealerid);
    formData.append("foldername[]",this.foldername);
  }
  this.service.UploadFile(formData).pipe(
    tap((data:any) => {
      if (data.status==200) {
        this.toastr.success('File Upload successfully..'); 
     console.log('response received is ', data.data);
      }
      if (data.status==400) {
        this.toastr.error('Alredy Exist..'); 
     console.log('response received is ', data.data);
      }
    }),
    takeUntil(this.unsubscribe),
    finalize(() => {
      this.cdr.detectChanges();
    })
  ).subscribe();
  // this.service.UploadFile(formData).subscribe((response:any) => {
  //   debugger
  //   this.toastr.success('File Upload successfully..'); 
  //    console.log('response received is ', response);
  // });
}
}
