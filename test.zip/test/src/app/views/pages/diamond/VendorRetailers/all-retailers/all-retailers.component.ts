import { Component, OnInit,ViewChild, ChangeDetectorRef } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import { ToastrService } from 'ngx-toastr';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import { ConfirmPopupboxComponent } from '../../common-component/confirm-popupbox/confirm-popupbox.component';
import { InviteRetailerPopupboxComponent } from '../../common-component/invite-retailer-popupbox/invite-retailer-popupbox.component';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'kt-all-retailers',
  templateUrl: './all-retailers.component.html',
  styleUrls: ['./all-retailers.component.scss']
})
export class AllRetailersComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  private unsubscribe: Subject<any>;
   dataSource: MatTableDataSource<any>;
   public eventCalls: Array<string> = [];
   displayedColumns: string[] = ['StoreName','RetailerType','City','State','Invite'];
   constructor(private cdr: ChangeDetectorRef,private service: UserService,private sanitizer:DomSanitizer,private dialog: MatDialog,private toastr: ToastrService) {
    this.unsubscribe = new Subject();
    this.dataSource = new MatTableDataSource<any>([]);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
 
   ngOnInit() {
     this.getRetailerList();
     this.dataSource.sort = this.sort;
   };
   getRetailerList ()
   {
     var obj={dealerid:720}
     this.service.getAllRetailer(obj).pipe(
      tap((data:any) => {
        console.log(data.data);
        debugger
        this.dataSource.data = data.data;
        this.dataSource.paginator = this.paginator;
      }),
      takeUntil(this.unsubscribe),
      finalize(() => {
        this.cdr.detectChanges();
      })
    ).subscribe();
    //  this.service.getAllRetailer(obj).subscribe((data:any)=>{
    //    });
   }

   onclickChangeAccess(event,element,itemName)
   {
     //debugger
     var obj = {
       id : element.id,
       type : itemName,
       status : event.checked == true ? 1 : 0 
     };
     this.service.changeRetailerAccess(obj).subscribe((data:any)=>{
       this.toastr.success("Access Changed Successfully..")
     });
   }
   onclickInvite(item){
     //debugger
     const dialogRef = this.dialog.open(InviteRetailerPopupboxComponent, {
       data: item,
       width: '600px',
     });
     dialogRef.afterClosed().subscribe(result => {
       debugger
       if (!result) {
         return
       }
       result.Subject = 'Invitation Retailer';
       result.pk_id = item.pk_id
       if (result) {

        this.service.inviteretailerEmail(result).pipe(
          tap((data:any) => {
            this.toastr.success("Invite Successfully..");
          }),
          takeUntil(this.unsubscribe),
          finalize(() => {
            this.getRetailerList();
            this.cdr.detectChanges();
          })
        ).subscribe();

        //   this.service.inviteretailerEmail(result).subscribe((data:any)=>{
        //     debugger
          
           

        //  });
       }
     });
   }
   getItemCssClassByStatus(status: number): string {
     console.log(status);
     switch (status) {
       case 1:
         return 'success';
       case 0:
         return 'metal';
     }
     return '';
   }
   getItemStatusString(status: number) {
     console.log(status);
     switch (status) {
       case 0:
         return 'Pending';
       case 1:
         return 'Connected';
     }
     return '';
   }
 }
 