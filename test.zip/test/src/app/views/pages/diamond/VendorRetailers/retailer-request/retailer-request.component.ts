import { Component, OnInit,ViewChild } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import { FormControl, NgModel } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ConfirmPopupboxComponent } from '../../common-component/confirm-popupbox/confirm-popupbox.component';

@Component({
  selector: 'kt-retailer-request',
  templateUrl: './retailer-request.component.html',
  styleUrls: ['./retailer-request.component.scss']
})

export class RetailerRequestComponent implements OnInit {
   @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;
  dataSource: MatTableDataSource<any>;
  displayedColumns: string[] = ['Retailer','CompanyName','Country','Status','RequestedDate','action'];
  constructor(
    private dialog: MatDialog,
    private toastr: ToastrService,
    private service: UserService,
    private sanitizer:DomSanitizer) {
    this.dataSource = new MatTableDataSource<any>([]);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
   }
  ngOnInit() {
    this.getRetailerList();
    this.dataSource.sort = this.sort;
  };
  getRetailerList ()
  {
    var obj={dealerid:720}
    this.service.getRetailerPendingRequest(obj).subscribe((data:any)=>{
//      console.log(data.data);
//      debugger
      this.dataSource.data = data.data;
      this.dataSource.paginator = this.paginator;
			//this.dataSource.sort = this.sort;
      });
  }
  approveClick(detail){
    //debugger
    const dialogRef = this.dialog.open(ConfirmPopupboxComponent, {
      data: {
        msg: " Are You Sure Want To Approve ?",
        button: "Approve"
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (!result) {
        return
      }
      if (result == "Yes") {
        this.service.approveRetailerds(detail).subscribe((data:any)=>{
          //debugger
          this.getRetailerList();
          this.toastr.success("Approve Successfully..");
        });
      }
    });
  }
  declineClick(detail){
    //debugger
    const dialogRef = this.dialog.open(ConfirmPopupboxComponent, {
      data: {
        msg: " Are You Sure Want To Remove ?",
        button: "Remove"
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (!result) {
        return
      }
      if (result == "Yes") {
        this.service.rejectRetailerds(detail).subscribe((data:any)=>{
          //debugger
          this.getRetailerList();
          this.toastr.success("Removed Successfully..")
        });
      }
    });
  }
  getItemCssClassByStatus(status: number = 0): string {
		switch (status) {
			case 1:
				return 'success';
			case 0:
				return 'metal';
		}
		return '';
  }
  getItemStatusString(status: number = 0): string {
		switch (status) {
			case 0:
				return 'Pending';
			case 1:
				return 'Connected';
		}
		return '';
	}
}
