import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatDividerModule, MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { DragDropModule } from '@angular/cdk/drag-drop';
 import { FileUploadModule } from 'ng2-file-upload';
import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

import { MyRetailersComponent } from './my-retailers/my-retailers.component';
import { RetailerRequestComponent } from './retailer-request/retailer-request.component';
import { AllRetailersComponent } from './all-retailers/all-retailers.component';
import { ConversationComponent } from './conversation/conversation.component';
import { ConversationDetailComponent } from './conversation/conversation-detail/conversation-detail.component';

const diamondRoutes: Routes = [
  {
    path: 'myRetailer',
    component: MyRetailersComponent

  },
  {
    path: 'retailerRequest',
    component: RetailerRequestComponent

  },
  {
    path: 'allRetailers',
    component: AllRetailersComponent

  },
  {
    path: 'conversation',
    component: ConversationComponent

  },
  {
    path: 'conversationDetail',
    component: ConversationDetailComponent

  }

  
  
];
@NgModule({
  declarations: [MyRetailersComponent, RetailerRequestComponent, AllRetailersComponent, ConversationComponent, ConversationDetailComponent],
  imports: [MatDividerModule,DragDropModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
    MatSlideToggleModule,CommonModule,InfiniteScrollModule,
    RouterModule.forChild(diamondRoutes),
    FileUploadModule,TranslateModule.forRoot(),
  ],

})
export class DiamondRetailerModule { }
