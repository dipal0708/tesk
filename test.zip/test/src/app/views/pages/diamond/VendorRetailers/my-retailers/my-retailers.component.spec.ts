import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyRetailersComponent } from './my-retailers.component';

describe('MyRetailersComponent', () => {
  let component: MyRetailersComponent;
  let fixture: ComponentFixture<MyRetailersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyRetailersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyRetailersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
