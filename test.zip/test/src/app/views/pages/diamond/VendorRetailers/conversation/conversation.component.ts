import { Component, OnInit, ChangeDetectorRef,ViewChild } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CreatenewcompanyPopupboxComponent } from '../../common-component/createnewcompany-popupbox/createnewcompany-popupbox.component';
import { ConversationPopupComponent } from '../../common-component/conversation-popup/conversation-popup.component';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import { Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { ConfirmPopupboxComponent } from '../../../diamond/common-component/confirm-popupbox/confirm-popupbox.component';
import { RouterModule, Routes, Router } from '@angular/router';
@Component({
  selector: 'kt-conversation',
  templateUrl: './conversation.component.html',
  styleUrls: ['./conversation.component.scss']
})
export class ConversationComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  ConversationList:any;
  private unsubscribe: Subject<any>;
  dataSource: MatTableDataSource<any>;
  companies:any=[];
  displayedColumns: string[] = ['date','time','status','type','from','to','message','action'];
  constructor(private router: Router,private service: UserService,private dialog: MatDialog,private cdr: ChangeDetectorRef,private toastr: ToastrService) {
    this.unsubscribe = new Subject();
   }
  displayArray:any  =[
  {date:'26/8/2019',detail:{time:'3:18 AM',name:'Steven M Mammone'}},
  {date:'25/8/2019',detail:{time:'3:18 AM',name:'Steven M Mammone1'}},
  {date:'24/8/2019',detail:{time:'4:18 AM',name:'Steven M Mammone2'}},
  {date:'23/8/2019',detail:{time:'5:18 AM',name:'Steven M Mammone3'}},
  {date:'22/8/2019',detail:{time:'6:18 AM',name:'Steven M Mammone4'}},
  {date:'21/8/2019',detail:{time:'7:18 AM',name:'Steven M Mammone5'}},
  {date:'20/8/2019',detail:{time:'8:18 AM',name:'Steven M Mammone6'}}];
  
  ngOnInit() {
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this.dataSource = new MatTableDataSource<any>([]);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;

    this.getconversation();
    // this.service.getconversation(obj).subscribe((data:any)=>{
    //   debugger
    //   this.dataSource = data.data;
    // });
  }
  getconversation(){
    
    var obj ={
      dealerid: this.companies[0].dealerid
    }
    this.service.getconversation(obj).pipe(
      tap((data:any) => {
        debugger
        this.dataSource = data.data;
        this.dataSource.paginator = this.paginator;
      }),
      takeUntil(this.unsubscribe),
      finalize(() => {
        this.cdr.detectChanges();
      })
    ).subscribe();
  }

  sendConversation(item){
    debugger
    this.router.navigate(['./default/diamondRetailer/conversationDetail'], { queryParams: { id: item.conversationid} });
    // const dialogRef = this.dialog.open(ConversationPopupComponent, {

    // });
    // dialogRef.afterClosed().subscribe(result => {    
    //   debugger  
    //   if (!result) {
    //     return
    //   }
    //   else {
    //     debugger
    //     var obj ={
    //       EmailFormate : result,
    //       EmailId:item.receiveremail,
    //       Subject:'Conversataion'
    //     }
    //     this.service.inviteretailerEmail(obj).pipe(

    //       tap((data:any) => {
    //        this.toastr.success("Conversation sent successfully..")
    //       }),
    //       takeUntil(this.unsubscribe),
    //       finalize(() => {
    //         this.cdr.detectChanges();
    //       })
    //     ).subscribe();
    //   }
    // });
  }
  deleteConversation(item){
    debugger
    const dialogRef = this.dialog.open(ConfirmPopupboxComponent, {
      data: {
        msg: " Are you sure want to remove ?",
        button: "Remove"
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (!result) {
        return
      }
      if (result == "Yes") {
        var obj = {
          coversationId : item.conversationid
        };
        this.service.deleteconversation(obj).subscribe((data:any)=>{
          debugger
          this.getconversation();
          this.toastr.success("Removed Successfully..")
        });
      }
    });

  }
}
