import { Component, OnInit,ViewChild } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import { ToastrService } from 'ngx-toastr';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import { ConfirmPopupboxComponent } from '../../common-component/confirm-popupbox/confirm-popupbox.component';
@Component({
  selector: 'kt-my-retailers',
  templateUrl: './my-retailers.component.html',
  styleUrls: ['./my-retailers.component.scss']
})
export class MyRetailersComponent implements OnInit {
 @ViewChild(MatPaginator) paginator: MatPaginator;
 @ViewChild(MatSort) sort: MatSort;
  
  dataSource: MatTableDataSource<any>;
  public eventCalls: Array<string> = [];
  displayedColumns: string[] = ['Retailer','CompanyName','Country','Status','RequestedDate','ApprovedDate','Diamond', 'FancyColorDiamond','LabGrownDiamond','action'];
  constructor(private service: UserService,private sanitizer:DomSanitizer,private dialog: MatDialog,private toastr: ToastrService) {
    this.dataSource = new MatTableDataSource<any>([]);
     this.dataSource.paginator = this.paginator;
     this.dataSource.sort = this.sort;
   }

  ngOnInit() {
    this.getRetailerList();
    this.dataSource.sort = this.sort;
  };
  getRetailerList ()
  {
    var obj={dealerid:720}
    this.service.getConnectedRetailer(obj).subscribe((data:any)=>{
      console.log(data.data);
      //debugger
      this.dataSource.data = data.data;
      this.dataSource.paginator = this.paginator;
			
      });
  }
  onclickChangeAccess(event,element,itemName)
  {
    //debugger
    var obj = {
      id : element.id,
      type : itemName,
      status : event.checked == true ? 1 : 0 
    };
    this.service.changeRetailerAccess(obj).subscribe((data:any)=>{
      //debugger
      this.toastr.success("Access Changed Successfully..")
    });
  }
  declineClick(detail){
    //debugger
    const dialogRef = this.dialog.open(ConfirmPopupboxComponent, {
      data: {
        msg: " Are You Sure Want To Remove ?",
        button: "Remove"
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (!result) {
        return
      }
      if (result == "Yes") {
        this.service.rejectRetailerds(detail).subscribe((data:any)=>{
          //debugger
          this.getRetailerList();
          this.toastr.success("Removed Successfully..")
        });
      }
    });
  }
  getItemCssClassByStatus(status: number): string {
    console.log(status);
		switch (status) {
			case 1:
				return 'success';
			case 0:
				return 'metal';
		}
		return '';
  }
  getItemStatusString(status: number) {
    console.log(status);
		switch (status) {
			case 0:
				return 'Pending';
			case 1:
				return 'Connected';
		}
		return '';
	}
}
