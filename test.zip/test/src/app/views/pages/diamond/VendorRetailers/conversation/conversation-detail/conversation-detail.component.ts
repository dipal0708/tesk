import { Component, OnInit, ChangeDetectorRef, ViewChild, ElementRef} from '@angular/core';
import { RouterModule,ActivatedRoute, Routes, Router } from '@angular/router';
import { UserService } from '../../../../../../core/services/users.service';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { Location } from '@angular/common';

@Component({
  selector: 'kt-conversation-detail',
  templateUrl: './conversation-detail.component.html',
  styleUrls: ['./conversation-detail.component.scss']
})
export class ConversationDetailComponent implements OnInit {
  @ViewChild('myList') targetEl: ElementRef;

  private unsubscribe: Subject<any>;
  conversationDetail:any;
  message;
  companies:any;
  ConversationArray:any=[];

  constructor(public location:Location,public toastr:ToastrService,private cdr: ChangeDetectorRef,private activatedRoute: ActivatedRoute,private service: UserService) {
    this.unsubscribe = new Subject();
   }

  ngOnInit() {
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this.getDatabyId();
  }
  getDatabyId(){
    debugger
    let param1 = this.activatedRoute.snapshot.queryParams["id"];
    var obj ={
      conversationId : param1
    }
    this.service.getconversationDetail(obj).pipe(
      tap((data:any) => {
        debugger
        this.conversationDetail = data.conversationDetail[0];
        this.ConversationArray = data.Conversation;
        this.ConversationArray.sort((a, b) => {
          return <any>new Date(a.modifieddate) - <any>new Date(b.modifieddate);
        });
        console.log(this.ConversationArray);
      }),
      takeUntil(this.unsubscribe),
      finalize(() => {
        this.cdr.detectChanges();
      })
    ).subscribe();
    
  }
  onClicksendMessage(){
    debugger
    var obj ={
            EmailFormate : this.message,
            EmailId:this.conversationDetail.receiveremail,
            Subject:'Conversataion',
            conversationid: this.conversationDetail.conversationid,
            dealerid: this.companies[0].dealerid
          }
    this.service.insertConversation(obj).pipe(
     tap((data:any) => {
      this.toastr.success("Conversation sent successfully..");
      this.message = '';
     }),
     takeUntil(this.unsubscribe),
     finalize(() => {
      this.getDatabyId();
       this.cdr.detectChanges();
     })
   ).subscribe()
  }
  onClickBack(){
    this.location.back();
  }
}
