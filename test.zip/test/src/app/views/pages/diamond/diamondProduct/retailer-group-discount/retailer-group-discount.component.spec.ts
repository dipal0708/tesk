import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailerGroupDiscountComponent } from './retailer-group-discount.component';

describe('RetailerGroupDiscountComponent', () => {
  let component: RetailerGroupDiscountComponent;
  let fixture: ComponentFixture<RetailerGroupDiscountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetailerGroupDiscountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetailerGroupDiscountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
