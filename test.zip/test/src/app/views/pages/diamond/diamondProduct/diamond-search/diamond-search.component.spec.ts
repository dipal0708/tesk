import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondSearchComponent } from './diamond-search.component';

describe('DiamondSearchComponent', () => {
  let component: DiamondSearchComponent;
  let fixture: ComponentFixture<DiamondSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
