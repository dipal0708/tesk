import { Component, OnInit,ViewChild, ChangeDetectorRef } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'kt-retailer-group',
  templateUrl: './retailer-group.component.html',
  styleUrls: ['./retailer-group.component.scss']
})
export class RetailerGroupComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
   dataSource: MatTableDataSource<any>;
  retailergroupdiscountForm: FormGroup;
  fileUrl;
  viewLoader:boolean=false;
  displayedColumns: string[] = ['companyname','groupname','action'];
  companies:any;
  updatebutton:boolean = false;
  private unsubscribe: Subject<any>;
  pkId:any;
  datasourceArray:any=[{comapnyName:'ZZ.GemFind Leo Schachter',groupName:'Tire 1'},
  {comapnyName:'TRICE JEWELERS (BruceChase)',groupName:'Tire 2'},
  {comapnyName:'European Jewellery (EricSutkiewicz)',groupName:'Tire 3'},
  {comapnyName:'DIAMOND CELLAR HOLDINGS LLC (GabeTruxall)',groupName:'Tire 4'},
  {comapnyName:'The Diamond Cellar (GabeTruxall)',groupName:'Tire 5'}];
  constructor(private cdr: ChangeDetectorRef,private service:UserService,private fb: FormBuilder,) { 
    this.unsubscribe = new Subject();
  }

  ngOnInit() {
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this.initLoginForm();
    this.getdata();
  }
  getdata(){
    var obj ={
      dealerid:this.companies[0].dealerid
    }
    debugger
    this.service.getAllRetailerGroupDiscount(obj).pipe(
      tap((data:any) => {
        if (data.status==200) {
          this.dataSource= data.data;
        }
      }),
      takeUntil(this.unsubscribe),
      finalize(() => {
        this.cdr.detectChanges();
      })
    ).subscribe();
  }

  initLoginForm() {
    this.retailergroupdiscountForm = this.fb.group({
      name: ['', Validators.compose([Validators.required])],
      value: ['', Validators.required],
    });
  }

  onclickAdd(){
    debugger
    if(this.retailergroupdiscountForm.invalid){
      return;
    }
    var obj ={
      dealerid:this.companies[0].dealerid,
      name:this.retailergroupdiscountForm.value.name,
      value:this.retailergroupdiscountForm.value.value
    }
    this.service.insertRetailerGroupDiscount(obj).pipe(
      tap((data:any) => {
        if (data.status==200) {
          this.retailergroupdiscountForm.reset();
          this.getdata();
        }
      }),
      takeUntil(this.unsubscribe),
      finalize(() => {
        this.cdr.detectChanges();
      })
    ).subscribe();
   
  }
  onclickEdit(item){
    debugger
    this.pkId = item.pk_id;
    this.retailergroupdiscountForm.controls['name'].setValue(item.groupdiscountname);
    this.retailergroupdiscountForm.controls['value'].setValue(item.discountvalue);
    this.updatebutton = true;
  }
  onclickUpdate(){
    if(this.retailergroupdiscountForm.invalid){
      return;
    }
    var obj ={
      pkId:this.pkId,
      dealerid:this.companies[0].dealerid,
      name:this.retailergroupdiscountForm.value.name,
      value:this.retailergroupdiscountForm.value.value
    }
    this.service.insertRetailerGroupDiscount(obj).pipe(
      tap((data:any) => {
        if (data.status==200) {
          this.retailergroupdiscountForm.reset();
          this.getdata();
        }
      }),
      takeUntil(this.unsubscribe),
      finalize(() => {
        this.updatebutton = false;
        this.cdr.detectChanges();
      })
    ).subscribe();
  }

}