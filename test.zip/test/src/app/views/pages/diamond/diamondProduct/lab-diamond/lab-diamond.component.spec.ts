import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LabDiamondComponent } from './lab-diamond.component';

describe('LabDiamondComponent', () => {
  let component: LabDiamondComponent;
  let fixture: ComponentFixture<LabDiamondComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LabDiamondComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabDiamondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
