// import { Component, Input, OnInit, ViewChild, Output, EventEmitter, ElementRef, ChangeDetectorRef, ViewContainerRef } from '@angular/core';
// import { UserService } from '../../../../core/services/users.service';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { MatPaginator, MatSort, MatTableDataSource, PageEvent } from '@angular/material';
// import { ToastrService } from 'ngx-toastr';
// import { TranslateService } from '@ngx-translate/core';
// import { Observable, of } from 'rxjs';
// import { Router, ActivatedRoute, Params } from '@angular/router';
// import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
// import { DomSanitizer } from '@angular/platform-browser';
// import { animate, state, style, transition, trigger } from '@angular/animations';
// import { LoadingBarService } from '@ngx-loading-bar/core';
// import { FiltersComponent } from '../../common-component/filters/filters.component';
// import { ConfirmPopupboxComponent } from '../../common-component/confirm-popupbox/confirm-popupbox.component';
// import * as XLSX from 'xlsx';
// import { ExcelService } from '../../../../views/excel.service';
// import { CreatenewcompanyPopupboxComponent } from '../../common-component/createnewcompany-popupbox/createnewcompany-popupbox.component';
// import { EmailPopupboxComponent } from '../../common-component/email-popupbox/email-popupbox.component';
// import { VideoPopupboxComponent } from '../../common-component/video-popupbox/video-popupbox.component';
import { Component, Input, OnInit, ViewChild, Output, EventEmitter, ElementRef, ChangeDetectorRef, ViewContainerRef } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource, PageEvent } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { FiltersComponent } from '../../common-component/filters/filters.component';
import { ConfirmPopupboxComponent } from '../../common-component/confirm-popupbox/confirm-popupbox.component';
import * as XLSX from 'xlsx';
import { ExcelService } from '../../../../excel.service';
import { CreatenewcompanyPopupboxComponent } from '../../common-component/createnewcompany-popupbox/createnewcompany-popupbox.component';
import { EmailPopupboxComponent } from '../../common-component/email-popupbox/email-popupbox.component';
import { VideoPopupboxComponent } from '../../common-component/video-popupbox/video-popupbox.component';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'kt-alldiamond-search',
  templateUrl: './alldiamond-search.component.html',
  styleUrls: ['./alldiamond-search.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class AlldiamondSearchComponent implements OnInit {
  // @ViewChild('TABLE',{ read: ElementRef }) table: ElementRef;
  @ViewChild(AlldiamondSearchComponent) private surveyComponent: AlldiamondSearchComponent;
  @ViewChild('TABLE') table: ElementRef;
  @Output() onPageSwitch = new EventEmitter();
  diamondSearachdataSource: MatTableDataSource<any>;
  allrecords: any = [];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator1: MatPaginator;
  expandedElement: AlldiamondSearchComponent;
  totalItems: any = 0;
  dataarry: any = [];
  userDetail: any = [];
  dataforView: any = [];
  filteredOptions: Observable<string[]>;
  resultsLength: any = [];
  expandedDetail: boolean;
  colaps: boolean = false;
  isLoadingResults: boolean = false;
  filterdata: any;
  colapsId: string = "";
  filterValue:string="";
  filterValueLength:number = 15;
  searchbox1;
  selectedItems: any = [];
  NoOfPages = [10, 20, 50, 100];
  displayedColumns: string[] = ['EnableDisable', 'colaps', 'stock', 'shape', 'size', 'cut', 'color', 'clearity', 'off', 'cost', 'fluor', 'Dep', 'table', 'measure', 'cert', 'polish', 'sym', 'dealer', 'video'];
  displayedColumns1: string[] = ['EnableDisable', 'lotnumber', 'girdlepercentage', 'polish', 'culet', 'price1', 'price2'];
  daata = 0;
  viewLoader:boolean=false;
  objFilter:any;  
  selectedItemsArray:any=[];
  allrecordArray:any=[];   
  private unsubscribe: Subject<any>;
  companies:any=[];
  constructor(vcr: ViewContainerRef, private cdr: ChangeDetectorRef, private router: Router, public excelService: ExcelService, public loader: LoadingBarService, private dom: DomSanitizer, private dialog: MatDialog, private activatedRoute: ActivatedRoute, private service: UserService, private fb: FormBuilder, private translate: TranslateService, private toastr: ToastrService) {
    this.diamondSearachdataSource = new MatTableDataSource<any>([]);
    this.diamondSearachdataSource.paginator = this.paginator1;
    this.diamondSearachdataSource.sort = this.sort;
    this.unsubscribe = new Subject();
  }
  ngOnInit() {
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this.currentPage = 1;
    this.itemsPerPage = this.NoOfPages[0];
    this.onScrollDown();
    
    //this.getAllrecords();
  }

  deleteRecordsClick() {
    if (this.selectedItems.length == 0) { 
      this.toastr.error('Please Select Atleast One Diamond.');
      return
    }
    const dialogRef = this.dialog.open(ConfirmPopupboxComponent, {
      data: {
        msg: " Are you sure want to delete ?",
        button: "Delete"
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (!result) {
        return
      }
      if (result == "Yes") {
        this.service.deletediamond(this.selectedItems).pipe(
          tap((data:any) => {
            
            if (data.status==200) { 
              this.toastr.success('Diamond Deleted Successfully.');
              this.searchbox1 = "";
              this.selectedItems.length = 0;  
            } else {
              this.toastr.error('Somthing Wrong ..');
            }
          }),
          takeUntil(this.unsubscribe),
          finalize(() => {      
            setTimeout(() => {
              this.onScrollDown(); 
            }, 500);    
                        
          })
        ).subscribe();

        // this.service.deletediamond(this.selectedItems).subscribe((data: any) => {
        //   this.toastr.success('Diamond Deleted Successfully.');
        //   this.onScrollDown();
        //   this.searchbox1 = "";
        //   this.selectedItems.length = 0;
        // });
      }
    });
  }

  ExportTOExcel() {
    if(this.selectedItems.length == 0){
      debugger
      
      
     
      // this.excelService.exportAsExcelFile(this.diamondSearachdataSource.data, 'sample');
    }
    else{
      this.excelService.exportAsExcelFile(this.selectedItemsArray, 'sample');
    }
  }

  showFilterClick() { 
    this.filterValue = "";
    this.filterValueLength = 0
    const dialogRef = this.dialog.open(FiltersComponent, {
    });
    dialogRef.afterClosed().subscribe(result => {         
      if (!result) { 
        return
      }
      else { 
        //var filterValue = filterValue.trim().toUpperCase();
          this.objFilter = result;
          this.currentPage=1;
          this.searchbox1 = "";
          this.onScrollDown();
        // this.service.getfiltredDiamond(result).subscribe((data: any) => {
        //   this.dataSource.data = data.data; 
        //   console.log(data.data);
        //   this.viewLoader= false;
        // });
      }
    });
  }
  onChangecompany(event, data) {     
    if (event.checked == true) {      
      var checkValid =  this.selectedItemsArray.filter(x=>x.dinventoryid == data.dinventoryid);
      if(checkValid.length == 0){
        this.selectedItems.push(data.dinventoryid);
        data.is_enable = true;
        this.selectedItemsArray.push(data);
      }
    }
    if (event.checked == false) {
      const index: number = this.selectedItems.indexOf(data.dinventoryid);
      if (index !== -1) {
        this.selectedItems.splice(index, 1);
        data.is_enable = false;
        this.selectedItemsArray.splice(index, 1);

        if (this.selectedItemsArray.length == 0) {
          this.diamondSearachdataSource.data = this.allrecords;
          this.resultsLength = this.totalItems;
        }
      }

    }
  }
  addrecoredClick() {
    const dialogRef = this.dialog.open(CreatenewcompanyPopupboxComponent, {
    });
    dialogRef.afterClosed().subscribe(result => {      
      if (!result) {
        return
      }
      else {        
        this.viewLoader= true;
        this.service.addnewdiamond(result).pipe(
          tap((data:any) => {
            if (data.status==200) { 
              this.totalItems =  data.data2[0].count;
              this.toastr.success('Add Successfully..');
              this.viewLoader= false;      

            } else {
              this.toastr.error('Somthing Wrong..');
            }
          }),
          takeUntil(this.unsubscribe),
          finalize(() => {
            this.cdr.detectChanges();
            //this.onScrollDown();
          })
        ).subscribe();

        // this.service.addnewdiamond(result).subscribe((data: any) => {          
        //   this.totalItems =  data.data2[0].count;
        //   this.toastr.success('Add Successfully..');
        //   this.viewLoader= false;
        // });
      }
    });
  }
  opencolapsClick(d) {

    this.colapsId = d.dinventoryid;
    this.colaps = true;
  }
  closecolapsClick() {
    this.colaps = false;
    this.colapsId = "";
  }
  applyFilter(filterValue: string) {
    filterValue = this.searchbox1;
    var filterValue = filterValue.trim().toUpperCase();
    this.filterValue = filterValue;
    this.filterValueLength = filterValue.length;
    this.objFilter = {
      searchvalue: filterValue,
      dealerid: this.companies[0].dealerid
      //dealerid: 720
    }
    setTimeout(() => {
      this.onScrollDown(); 
    }, 500);  
      ///this.onScrollDown();  
    
    
    // this.service.getsearchValues(obj).subscribe((data: any) => {
    //   this.dataSource.data = data.data;    
    // });
  }
  viewrecordeClick() {
    
    if (this.selectedItems.length == 0) {

      this.toastr.error('Please Select Atleast One Diamond.');
      return
    }
    this.dataforView = [];
    // for (var i = 0; i < this.selectedItems.length; i++) {

    //   var data2 = this.allrecords.filter(x => x.dinventoryid == this.selectedItems[i]);
    //   this.dataforView.push(data2[0]);
    // }
    this.diamondSearachdataSource.data = this.selectedItemsArray;
    this.resultsLength = this.selectedItemsArray.length;
  }
  printrecordClick() {
    this.viewrecordeClick();

    setTimeout(function() {
      window.print();
      }, 1000);
  }
  sendrecordClick() {
    if (this.selectedItems.length == 0) {
      this.toastr.error('Please Select Atleast One Diamond.');
      return
    }

    const dialogRef = this.dialog.open(EmailPopupboxComponent, {
      data: {
        msg: this.selectedItems.length
      }
    });
    dialogRef.afterClosed().subscribe(result => {

      if (!result) {
        return
      }
      else {
        this.selectedItemsArray;
        var obj = {
          EmailDiamond: this.selectedItemsArray,
          email:result.email,
          markup:result.markup,
          message:result.message,
          name:result.name,
        }
        this.service.sendDiamond(obj).subscribe((data: any) => {
          this.toastr.success("Email Sent Successfully.")
        });
      }
    });
  }
  certificateClick(datas) {

    this.router.navigateByUrl(datas);
  }
  oncetrificateClcik(datas) {
    debugger
    window.open(datas);
  }
  playVideoClick() {
    const dialogRef = this.dialog.open(VideoPopupboxComponent, {
      data: {
        msg: this.selectedItems.length
      }
    });
    dialogRef.afterClosed().subscribe(result => {

      if (!result) {
        return
      }
      else {

      }
    });
  }
  switchPage(event: PageEvent) {

  }
  onScrollDown() {    
    debugger
    // if(!this.objFilter){
    //   this.objFilter = {
    //     dealerid: 720
    //   }};          
    this.viewLoader = true;
    var diamondType = 'allNaturalDiamond';
    ///
    console.log(this.objFilter);
    this.service.getAlldiamondalluser(this.currentPage-1, this.itemsPerPage,this.objFilter,diamondType)
    .pipe(
      tap((data: any) => {        
        if (data.status==200) {           
          this.diamondSearachdataSource.data = data.data;
          this.allrecords = data.data;
          this.totalItems = data.data2[0].count;
          this.resultsLength = this.totalItems;
          this.totalPages = Math.round(this.totalItems / this.itemsPerPage);
        } else {          
        }
      }),
      takeUntil(this.unsubscribe),
      finalize(() => {
        this.viewLoader = false;
        this.cdr.detectChanges();
      })
    ).subscribe();
  }

  onScrollUp() {
    console.log('scrolled up!!');
  }
  pagedItems = [];
  ret = [];
  itemsPerPage: number = 0;
  currentPage: number = 1;
  totalPages: number = 0;
  groupToPages() {
    for (var i = 0; i < this.allrecords.length; i++) {
      if (i % this.allrecords.itemsPerPage === 0) {
        this.pagedItems[Math.floor(i / this.itemsPerPage)] = [this.allrecords[i]];
      } else {
        this.pagedItems[Math.floor(i / this.itemsPerPage)].push(this.allrecords[i]);
      }
    }
  };
  range(start, end) {
    this.ret = [];
    if (!end) {
      end = start;
      start = 0;
    }
    for (var i = start; i < end; i++) {
      this.ret.push(i);
    }
    return this.ret;
  };

  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.onScrollDown();
    }
  };
  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.onScrollDown();
    }
  };
  lastPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage = this.totalPages-1;
      this.onScrollDown();
    }
  };
  firstPage() {
    if (this.currentPage > 1) {
      this.currentPage = 1;
      this.onScrollDown();
    }
  };
  setPage(n) {
    this.currentPage = n + 1;
    this.onScrollDown();
  };

  public handlePage(e: any) {
    this.currentPage = e.pageIndex;
    this.itemsPerPage = e.pageSize;
    this.onScrollDown();
  }

}