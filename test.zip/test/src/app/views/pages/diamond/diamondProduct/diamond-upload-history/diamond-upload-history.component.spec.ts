import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondUploadHistoryComponent } from './diamond-upload-history.component';

describe('DiamondUploadHistoryComponent', () => {
  let component: DiamondUploadHistoryComponent;
  let fixture: ComponentFixture<DiamondUploadHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondUploadHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondUploadHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
