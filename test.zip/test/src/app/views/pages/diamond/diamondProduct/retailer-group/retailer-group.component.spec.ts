import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailerGroupComponent } from './retailer-group.component';

describe('RetailerGroupComponent', () => {
  let component: RetailerGroupComponent;
  let fixture: ComponentFixture<RetailerGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetailerGroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetailerGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
