import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllColorDiamondComponent } from './all-color-diamond.component';

describe('AllColorDiamondComponent', () => {
  let component: AllColorDiamondComponent;
  let fixture: ComponentFixture<AllColorDiamondComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllColorDiamondComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllColorDiamondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
