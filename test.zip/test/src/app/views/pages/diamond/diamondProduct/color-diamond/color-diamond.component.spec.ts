import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColorDiamondComponent } from './color-diamond.component';

describe('ColorDiamondComponent', () => {
  let component: ColorDiamondComponent;
  let fixture: ComponentFixture<ColorDiamondComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColorDiamondComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColorDiamondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
