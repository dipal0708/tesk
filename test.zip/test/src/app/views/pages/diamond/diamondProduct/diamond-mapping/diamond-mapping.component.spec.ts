import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondMappingComponent } from './diamond-mapping.component';

describe('DiamondMappingComponent', () => {
  let component: DiamondMappingComponent;
  let fixture: ComponentFixture<DiamondMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
