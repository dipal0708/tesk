import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondAddComponent } from './diamond-add.component';

describe('DiamondAddComponent', () => {
  let component: DiamondAddComponent;
  let fixture: ComponentFixture<DiamondAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
