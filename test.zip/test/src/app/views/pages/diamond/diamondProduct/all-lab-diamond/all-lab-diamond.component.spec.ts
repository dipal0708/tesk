import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllLabDiamondComponent } from './all-lab-diamond.component';

describe('AllLabDiamondComponent', () => {
  let component: AllLabDiamondComponent;
  let fixture: ComponentFixture<AllLabDiamondComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllLabDiamondComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllLabDiamondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
