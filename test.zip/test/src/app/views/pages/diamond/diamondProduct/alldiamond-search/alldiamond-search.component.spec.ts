import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlldiamondSearchComponent } from './alldiamond-search.component';

describe('AlldiamondSearchComponent', () => {
  let component: AlldiamondSearchComponent;
  let fixture: ComponentFixture<AlldiamondSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlldiamondSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlldiamondSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
