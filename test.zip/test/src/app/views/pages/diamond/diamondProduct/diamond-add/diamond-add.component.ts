import { Component, OnInit, Inject ,ChangeDetectorRef} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SafeHtml } from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { UserService } from '../../../../../core/services/users.service';
import { ToastrService } from 'ngx-toastr';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'kt-diamond-add',
  templateUrl: './diamond-add.component.html',
  styleUrls: ['./diamond-add.component.scss']
})
export class DiamondAddComponent implements OnInit {

  companyeditform1: FormGroup;
  // --------------------Bind Data----------------
  diamondculet: any = [];
  diamondclarity: any = [];
  diamondshape: any = [];
  diamondpolish: any = [];
  diamondsymmetry: any = [];
  diamondfluorescence: any = [];
  diamondculetcondition: any = [];
  diamondgirdle: any = [];
  diamondcutgrade: any = [];
  diamondfancycolor: any = [];
  diamondintensity: any = [];
  diamond_certificate: any = [];

  //--------------bind data arrray end
  colorArray = ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
  SeperableArray = ['Yes', 'No'];
  foods = [
    { value: 'steak-0', viewValue: 'Steak' },
    { value: 'pizza-1', viewValue: 'Pizza' },
    { value: 'tacos-2', viewValue: 'Tacos' }
  ];
  private unsubscribe: Subject<any>;
  companies:any;
  constructor(private cdr: ChangeDetectorRef,private fb: FormBuilder, private service: UserService, private toastr: ToastrService) {
    this.unsubscribe = new Subject();
  };

  ngOnInit() {
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this.getAlldropdownValue();
    this.initLoginForm();
  }

  initLoginForm() {
    this.companyeditform1 = this.fb.group({
      clarity: ['', Validators.compose([Validators.required])],
      invntory: ['', Validators.required],
      matchedstock: [''],
      stones: [''],
      seperable: ['', Validators.compose([Validators.required])],
      polish: ['', Validators.compose([Validators.required])],
      symmetry: ['', Validators.compose([Validators.required])],
      storelocaion: [''],
      size: ['', Validators.required],
      costcarat: ['', Validators.compose([Validators.required])],
      shape: ['', Validators.compose([Validators.required])],
      girdle: [''],
      employeename: [''],
      color: ['', Validators.compose([Validators.required])],
      fancycode: [''],
      fancynames: [''],
      others: [''],
      culet: [''],
      culetcondition: [''],
      employeeid: [''],
      cutgrade: ['', Validators.compose([Validators.required])],
      certificate: [''],
      certificateid: [''],
      crownangle: [''],
      pavillionangle: [''],
      seebyothersdealer: [''],
      outonmemo: [''],
      depth: ['', Validators.compose([Validators.required])],
      table: ['', Validators.compose([Validators.required])],
      mesurments: [''],
      comments: [''],
      addvideo: [''],
      selectedvideo: [''],
      Fluorescence: ['', Validators.compose([Validators.required])],
      fancycolorbody: [''],
      fancycoloroverton: [''],
      fancycolorintensity: [''],
      selectedimage:[''],
      islabcreated:false,
    });
  }
  isControlHasError(controlName: string, validationType: string): boolean {
    const control = this.companyeditform1.controls[controlName];
    if (!control) {
      return false;
    }
    const result = control.hasError(validationType) && (control.dirty || control.touched);
    return result;
  }
  submit() {
    const controls = this.companyeditform1.controls;
    if (this.companyeditform1.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );
      this.toastr.error("Plase Insert Required Fields.")
      return
    }
    var obj = {
			additionalimage: "",
			blackinclusion: "",
			centralinclusion: "",
			certificate: this.companyeditform1.value.certificate,
			certificateimage: "http://gemfacts.com/Cert/certsearch.aspx?certNo=282910365",
			certificateno: this.companyeditform1.value.certificateid,
			city: "",
			clarity: this.companyeditform1.value.clarity,
			clarityid: 6,
			color: this.companyeditform1.value.color,
			comments: this.companyeditform1.value.comments,
			costpercarat: this.companyeditform1.value.costcarat,
			country: "",
			crown: "",
			crownheight: "",
			crownpercentage: "",
			culet: this.companyeditform1.value.culet,
			culetcondition: this.companyeditform1.value.culetcondition,
			customfield1: "",
			customfield1name: "",
			customfield2: "",
			customfield2name: "",
			customfield3: "",
			customfield3name: "",
			customfield4: "",
			customfield4name: "",
			customfield5: "",
			customfield5name: "",
			cut: this.companyeditform1.value.shape,
			cutgrade: this.companyeditform1.value.cutgrade,
			dealerid:  this.companies[0].dealerid,
			dealerinventoryno: this.companyeditform1.value.invntory,
			depth: this.companyeditform1.value.depth,
			dinventoryid: "",
			enhancements: "",
			eyecleaninclusion: "",
			fancycolorintensity: this.companyeditform1.value.fancycolorintensity ? this.companyeditform1.value.fancycolorintensity : '',
			fancycolormainbody: this.companyeditform1.value.fancycolorbody ? this.companyeditform1.value.fancycolorbody:'',
			fancycolorovertone: this.companyeditform1.value.fancycoloroverton? this.companyeditform1.value.fancycoloroverton:'',
			flourescence: this.companyeditform1.value.Fluorescence,
			flourescencecolor: "",
			girdle: this.companyeditform1.value.girdle,
			girdlepercentage: "",
			girdlethickest: "",
			imagefilename:this.companyeditform1.value.selectedimage,
			inventoryregion: "",
			isactive: 1,
			keytosymbol: "",
			laserincription: "",
			lotnumber: this.companyeditform1.value.invntory,
			measurements: this.companyeditform1.value.mesurments,
			measurementsheight: "",
			measurementslength: "",
			measurementswidth: "",
			milkyinclusion: "",
			modified: new Date(),
			offrapaport: "",
			origin: "",
			outonmemo: "",
			pairseparable: "",
			pairstocknumber: "",
			pavillion: "",
			pavillionheight: "",
			pavillionpercentage: "",
			polish: this.companyeditform1.value.polish,
			price1: 0,
			price2: 0,
			ratio: "",
			shade: "",
			size: this.companyeditform1.value.size,
			state: "",
			stones: 1,
			symmetry: this.companyeditform1.value.symmetry,
			tablemeasure: this.companyeditform1.value.table,
			thirdpartysellername: "",
			totalprice: this.companyeditform1.value.size * this.companyeditform1.value.costcarat,
      treatment: "",
      videofilename:this.companyeditform1.value.selectedvideo,
      islabcreated : this.companyeditform1.value.islabcreated == true ? 'y' : ''
		}
      debugger
    this.service.addnewdiamond(obj).pipe(
      tap((data:any) => {
        if (data.status==200) { 
          this.toastr.success('Add Successfully..');
          this.companyeditform1.reset();
        } else {
          this.toastr.error('Somthing Wrong..');
        }
      }),
      takeUntil(this.unsubscribe),
      finalize(() => {
        this.cdr.detectChanges();
      })
    ).subscribe();

  }

  getAlldropdownValue() {
    this.service.getalldropdownItems().subscribe((data: any) => {
      this.diamondculet = data.diamondculet;
      this.diamondclarity = data.diamondclarity;
      this.diamondshape = data.diamondshape;
      this.diamondpolish = data.diamondpolish;
      this.diamondsymmetry = data.diamondsymmetry;
      this.diamondfluorescence = data.diamondfluorescence;
      this.diamondculetcondition = data.diamondculetcondition;
      this.diamondgirdle = data.diamondgirdle;
      this.diamondcutgrade = data.diamondcutgrade;
      this.diamondfancycolor = data.diamondfancycolor;
      this.diamondintensity = data.diamondintensity;
      this.diamond_certificate = data.diamond_certificate;
    });
  }
  onCencelClick() {
    this.companyeditform1.reset();
  }
  onKeyPress(event: any) {
    //alert(this.companyeditform1.value.size);
    var charCode = (event.which) ? event.which : event.keyCode;
    // if(!(charCode > 31 && (charCode < 48 || charCode > 57) ))
    //   return false;
    // else
    //   return false;
   
    if (charCode == 46)
      return true;
    else
      return !(charCode > 31 && (charCode < 48 || charCode > 57));
  }
  onChangeLabDiamond(value){
		debugger
		if(value.checked == true){
			this.companyeditform1.controls['fancycoloroverton'].setValue('');
			this.companyeditform1.controls['fancycolorintensity'].setValue('');
			this.companyeditform1.controls['fancycolorbody'].setValue('');

			this.companyeditform1.controls['fancycoloroverton'].disable();
			this.companyeditform1.controls['fancycolorintensity'].disable();
			this.companyeditform1.controls['fancycolorbody'].disable();
		}
		if(value.checked == false){
			this.companyeditform1.controls['fancycoloroverton'].enable();
			this.companyeditform1.controls['fancycolorintensity'].enable();
			this.companyeditform1.controls['fancycolorbody'].enable();
		}
	}
}