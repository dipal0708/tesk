import { Component, OnInit, ViewChild, ElementRef,ChangeDetectorRef } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort, MatDialog } from '@angular/material';
import { UserService } from '../../../../../core/services/users.service';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Router } from '@angular/router';
// import { int } from 'aws-sdk/clients/datapipeline';
// import { integer } from 'aws-sdk/clients/lightsail';
import { ToastrService } from 'ngx-toastr';
import * as XLSX from 'xlsx';
import { ConfirmPopupboxComponent } from '../../common-component/confirm-popupbox/confirm-popupbox.component';
// import { FileUploader } from 'ng2-file-upload';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';


@Component({
  selector: 'kt-diamond-mapping',
  templateUrl: './diamond-mapping.component.html',
  styleUrls: ['./diamond-mapping.component.scss']
})
export class DiamondMappingComponent implements OnInit {
  private unsubscribe: Subject<any>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('TABLE') table: ElementRef;
  dataSource: MatTableDataSource<any>;
  FinalArray: any = "";
  selectImage: number;
  dropData: any = [];
  file: File;
  MappedArray: any = [];
  viewLoader:boolean=false;
  displayedColumns: string[] = ['columnname', 'columntype', 'description'];
  FinalArray2: any = [];
  companies:any;
  viewFileupload:boolean=false;
  constructor(
    private cdr: ChangeDetectorRef,
    private dialog: MatDialog,
    private service: UserService,
    private toastr: ToastrService,
    private router: Router) {
    this.dataSource = new MatTableDataSource<any>();
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.unsubscribe = new Subject();
    debugger
  }
  ngOnInit() {    
    debugger
    this.dataSource = new MatTableDataSource<any>();
    // this.dataSource.paginator = this.paginator;
    // this.dataSource.sort = this.sort;
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    //this.getDealerMappedData();
    this.getDiamondDealerColumn();
    this.getDiamondmapptingData();

  };
  getDiamondmapptingData() {
    var obj = { dealerid: this.companies[0].dealerid };
    this.service.getDiamondmapping(obj).pipe(
			tap((data:any) => {         
				if (data.status==200) {           
          this.FinalArray = data.data;
          this.viewFileupload= true;
				} else {	
          this.toastr.error("Something Wrong.")
				}
			}),
			takeUntil(this.unsubscribe),
			finalize(() => {
				this.cdr.detectChanges(); 
			})
    ).subscribe();
    
    // this.service.getDiamondmapping(obj).subscribe((data: any) => {
    //   this.FinalArray = [];

      // this.FinalArray = 0;
      // for (var i = 0; i < data.data.length; i++) {        
      //   for (var j = 0; j < this.MappedArray.length; j++) {
      //     if (data.data[i].id == this.MappedArray[j].jewelcloudcolumnid) {
      //       data.data[i].Mapptingvalue = this.MappedArray[j].columnname;
      //       data.data[i].MapptingvaluePk_Id = this.MappedArray[j].id;
      //       data.data[i].dealerid = this.MappedArray[j].dealerid;
      //       data.data[i].columnid = this.MappedArray[j].columnid;
      //       break;
      //     }
      //   }
      // }
      //this.FinalArray = data.data;
      
      ///this.viewFileupload= true;
      //this.dataSource.data = data.data;
    // });
  }
  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
    }
  }
  selectRow(i) {
    this.selectImage = i;
  }
  SelectData(nonmap) {
    debugger
    if (Object.keys(this.FinalArray).includes('Mapptingvalue') || this.FinalArray[this.selectImage].Mapptingvalue) {
      this.toastr.error("This row Already Mapped.")
      return
    }
    this.FinalArray[this.selectImage].MapptingvaluePk_Id = nonmap.id;
    this.FinalArray[this.selectImage].Mapptingvalue = nonmap.columnname;
    this.FinalArray[this.selectImage].dealerid = nonmap.dealerid;
    this.FinalArray[this.selectImage].columnid = nonmap.id;

    const index: number = this.FinalArray2.indexOf(nonmap);
    if (index !== -1) {
        this.FinalArray2.splice(index, 1);
    }  

    // this.FinalArray2[this.selectImage].id = ""
    // this.FinalArray2[this.selectImage].columnname = ""
    // this.FinalArray2[this.selectImage].id = ""
    // this.FinalArray2[this.selectImage].id = ""


    var dataMapped = {id: this.FinalArray[this.selectImage].id,Mapptingvalue : nonmap.columnname,dealerid : nonmap.dealerid,columnid : nonmap.id };
    this.service.savemappedData(dataMapped).pipe(
      tap((data:any) => {         
        if (data.status==200) {           
          this.toastr.success("Save Successfully..")
        } else {	
          this.toastr.error("Something Wrong.")
        }
      }),
      takeUntil(this.unsubscribe),
      finalize(() => {
        this.getDealerMappedData();
        //this.cdr.detectChanges(); 
      })
    ).subscribe();

    // this.service.savemappedData(dataMapped).subscribe((data: any) => {
    //   this.toastr.success("Save Successfully..")
    //   this.getDealerMappedData();
      
    // });
   // this.getDiamondDealerColumn();
  }
  onclickRemove(value, ind) {
    const dialogRef = this.dialog.open(ConfirmPopupboxComponent, {
      data: {
        msg: " Are You Sure Want To Remove ?",
        button: "Remove"
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (!result) {
        return
      }
      if (result == "Yes") {
        debugger
        this.viewLoader=true;
        var obj = {
          id: value.MapptingvaluePk_Id,
          columnname: value.Mapptingvalue,
          dealerid: value.dealerid,
          columnid: value.columnid,          
        }
        this.FinalArray[this.selectImage].MapptingvaluePk_Id = '';
        this.FinalArray[this.selectImage].Mapptingvalue = '';
        this.FinalArray[this.selectImage].dealerid = '';
        delete this.FinalArray[ind].Mapptingvalue;
        delete this.FinalArray[ind].MapptingvaluePk_Id;
        delete this.FinalArray[ind].dealerid;
        this.FinalArray = this.FinalArray;
        this.FinalArray2.push(obj);
        this.viewLoader=false;

        this.service.removeMapping(obj).pipe(
          tap((data:any) => {
            if (data.status==200) {
            this.toastr.success("Remove Successfully.."); 
            let element: HTMLElement = document.getElementById(value.columnid) as HTMLElement;
            element.click();  
            } else {	
              this.toastr.error("Something Wrong.")
            }
          }),
          takeUntil(this.unsubscribe),
          finalize(() => {
            this.cdr.detectChanges(); 
          })
        ).subscribe();

        // this.service.removeMapping(obj).subscribe((data: any) => {
        //   //this.FinalArray2.push(obj);
        //   this.toastr.success("Remove Successfully.."); 
        //   let element: HTMLElement = document.getElementById(value.columnid) as HTMLElement;
        // element.click();    
        // });       
      }
    });
  }
  onFileChange(evt: any) {
    const excelName: DataTransfer = <DataTransfer>(evt.target);
    // this.excelfileName = excelName.files[0].name;
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];
      /* save data */
      // window.localStorage.addItem(this.newData);

    };
    reader.readAsBinaryString(target.files[0]);
    evt.srcElement.value = "";
  }

  fileUpload(files: FileList) {
    debugger
    const file: File = files.item(0);
    const reader: FileReader = new FileReader();
    reader.readAsText(file);
    reader.onload = (e) => {
      const res = reader.result as string; // This variable contains your file as text
      const lines = res.split('\n'); // Splits you file into lines
      const Value = lines[0].split(',');
      const ids = [];
      for (let i = 0; i <= Value.length - 1; i++) {
        if(Value[i] != ""){
          ids.push(Value[i]); // Get first item of line
        }
      }
      var obj = { columnList: ids, dealerid: this.companies[0].dealerid };
      debugger
      this.service.DealerUploadedDiamondColumns(obj).pipe(
        tap((data:any) => {         
          if (data.status==200) {         
            this.getDiamondDealerColumn();  
            // this.MappedArray = data.data;
          } else {	
            this.toastr.error("Something Wrong.")
          }
        }),
        takeUntil(this.unsubscribe),
        finalize(() => {
          
          this.toastr.success('Upload Successfully..');
        })
      ).subscribe();

      // this.service.DealerUploadedDiamondColumns(obj).subscribe((data: any) => {
       
      // });
    };
  }

  getDiamondDealerColumn() {
    this.FinalArray2 = [];
    // this.FinalArray2 = 0;
    var obj = { dealerid: this.companies[0].dealerid };
    this.service.getDealerUploadDiamondColumn(obj).pipe(
			tap((data:any) => {         
				if (data.status==200) {           
          this.FinalArray2 =data.data;
				} else {	
          this.toastr.error("Something Wrong.")
				}
			}),
			takeUntil(this.unsubscribe),
			finalize(() => {
				this.cdr.detectChanges(); 
			})
    ).subscribe();

    // this.service.getDealerUploadDiamondColumn(obj).subscribe((data: any) => {
    //   this.FinalArray2 =data.data;
    // });
  }
  
  getDealerMappedData() {
    var obj = { dealerid: this.companies[0].dealerid };
    this.service.getDealerMappedColumn(obj).pipe(
			tap((data:any) => {         
				if (data.status==200) {           
          this.MappedArray = data.data;
				} else {	
          this.toastr.error("Something Wrong.")
				}
			}),
			takeUntil(this.unsubscribe),
			finalize(() => {
        this.getDiamondmapptingData();
				//this.cdr.detectChanges(); 
			})
    ).subscribe();

    // this.service.getDealerMappedColumn(obj).subscribe((data: any) => {
    //   this.MappedArray = data.data;
    //   this.getDiamondmapptingData(); 
    // });
  }
}
