import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondFileUploadComponent } from './diamond-file-upload.component';

describe('DiamondFileUploadComponent', () => {
  let component: DiamondFileUploadComponent;
  let fixture: ComponentFixture<DiamondFileUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondFileUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
