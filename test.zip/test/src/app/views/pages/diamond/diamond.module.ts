import { NgModule,ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DiamondSearchComponent } from './diamondProduct/diamond-search/diamond-search.component';
import { CreateUserComponent } from './diamondProduct/create-user/create-user.component';
import { AlldiamondSearchComponent } from './diamondProduct/alldiamond-search/alldiamond-search.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule } from '@angular/material';
import { MatExpansionModule,MatDividerModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule ,MatRadioModule} from "@angular/material";
import { DiamondFileUploadComponent } from './diamondProduct/diamond-file-upload/diamond-file-upload.component';

import { DiamondMappingComponent } from './diamondProduct/diamond-mapping/diamond-mapping.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { FileUploadModule } from 'ng2-file-upload';
import { DiamondAddComponent } from './diamondProduct/diamond-add/diamond-add.component';
import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { LabDiamondComponent } from '../diamond/diamondProduct/lab-diamond/lab-diamond.component';
import { ColorDiamondComponent } from '../diamond/diamondProduct/color-diamond/color-diamond.component';
import { AllColorDiamondComponent } from './diamondProduct/all-color-diamond/all-color-diamond.component';
import { AllLabDiamondComponent } from './diamondProduct/all-lab-diamond/all-lab-diamond.component';
import { DiamondUploadHistoryComponent } from './diamondProduct/diamond-upload-history/diamond-upload-history.component';
import { InterceptService } from '../../../core/_base/crud/';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { UserService } from '../../../core/services/users.service';
import { AuthGuard } from '../../../core/auth';
import { RetailerGroupDiscountComponent } from './diamondProduct/retailer-group-discount/retailer-group-discount.component';
import { RetailerGroupComponent } from './diamondProduct/retailer-group/retailer-group.component';
import { FiltersComponent } from './common-component/filters/filters.component';
import { Ng5SliderModule } from 'ng5-slider';
AuthGuard
const diamondRoutes: Routes = [
  {
    path: 'diamondsearchComp',
    component: DiamondSearchComponent

  }, {
    path: 'createuser',
    component: CreateUserComponent
  }, {
    path: 'diamondImport',
    component: DiamondFileUploadComponent
  },{
    path: 'diamondMapping',
    component: DiamondMappingComponent
  },{
    path: 'addDiamond',
    component: DiamondAddComponent
  },
  {
    path: 'alldiamondSearch',
    component: AlldiamondSearchComponent
  },
  {
    path :'landingPage',
    component:LandingPageComponent
  },
  {
    path :'labDiamond',
    component:LabDiamondComponent
  },
  {
    path :'colorDiamond',
    component:ColorDiamondComponent
  },
  {
    path :'allcolorDiamond',
    component:AllColorDiamondComponent
  },
  {
    path :'alllabDiamond',
    component:AllLabDiamondComponent
  },
  {
    path :'diamonduploadhistory',
    component:DiamondUploadHistoryComponent
  },
  {
    path :'retailergroupdiscount',
    component:RetailerGroupDiscountComponent
  },
  {
    path :'retailergroup',
    component:RetailerGroupComponent
  }
];
@NgModule({
  declarations: [FiltersComponent,DiamondSearchComponent,LandingPageComponent, CreateUserComponent, DiamondFileUploadComponent,DiamondMappingComponent,DiamondAddComponent,AlldiamondSearchComponent, LabDiamondComponent, ColorDiamondComponent, AllColorDiamondComponent, AllLabDiamondComponent,DiamondUploadHistoryComponent, RetailerGroupDiscountComponent, RetailerGroupComponent],
  imports: [DragDropModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,MatRadioModule,
    CommonModule,InfiniteScrollModule,MatDividerModule,
    RouterModule.forChild(diamondRoutes),
    FileUploadModule,TranslateModule.forRoot(),
    Ng5SliderModule
  ],
  providers:[InterceptService,
    {
      provide: HTTP_INTERCEPTORS,
        useClass: InterceptService,
      multi: true
    },]

})
export class DiamondModule {
  static forRoot(): ModuleWithProviders {
    return {
        ngModule: DiamondModule,
        providers: [
    UserService,
    AuthGuard
        ]
    };
}
 }
