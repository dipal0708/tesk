import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondcutgradeReportComponent } from './diamondcutgrade-report.component';

describe('DiamondcutgradeReportComponent', () => {
  let component: DiamondcutgradeReportComponent;
  let fixture: ComponentFixture<DiamondcutgradeReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondcutgradeReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondcutgradeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
