import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExtendeddiamondReportComponent } from './extendeddiamond-report.component';

describe('ExtendeddiamondReportComponent', () => {
  let component: ExtendeddiamondReportComponent;
  let fixture: ComponentFixture<ExtendeddiamondReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExtendeddiamondReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExtendeddiamondReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
