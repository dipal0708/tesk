import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailersearchReportComponent } from './retailersearch-report.component';

describe('RetailersearchReportComponent', () => {
  let component: RetailersearchReportComponent;
  let fixture: ComponentFixture<RetailersearchReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetailersearchReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetailersearchReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
