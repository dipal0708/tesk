import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondshapeReportComponent } from './diamondshape-report.component';

describe('DiamondshapeReportComponent', () => {
  let component: DiamondshapeReportComponent;
  let fixture: ComponentFixture<DiamondshapeReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondshapeReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondshapeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
