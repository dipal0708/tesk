import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule,MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule } from '@angular/material';
import { MatExpansionModule,MatDividerModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule ,MatRadioModule} from "@angular/material";
import { DiamondReportComponent } from './diamond-report/diamond-report.component';
import { RetailersearchReportComponent } from './retailersearch-report/retailersearch-report.component';
import { ExtendeddiamondReportComponent } from './extendeddiamond-report/extendeddiamond-report.component';
import { DiamondclarityReportComponent } from './diamondclarity-report/diamondclarity-report.component';
import { DiamondcolorReportComponent } from './diamondcolor-report/diamondcolor-report.component';
import { DiamondcutgradeReportComponent } from './diamondcutgrade-report/diamondcutgrade-report.component';
import { DiamondcertificateReportComponent } from './diamondcertificate-report/diamondcertificate-report.component';
import { DiamondshapeReportComponent } from './diamondshape-report/diamondshape-report.component';
import { DiamondsizeReportComponent } from './diamondsize-report/diamondsize-report.component';

const diamondRoutes: Routes = [
  {
        path :'diamondReport',
        component:DiamondReportComponent
  },
  {
    path :'diamondretailerReport',
    component:RetailersearchReportComponent
},
{
    path :'extendedDiamondReport',
    component:ExtendeddiamondReportComponent
},
{
    path :'diamondclarityReport',
    component:DiamondclarityReportComponent
},
{
    path :'diamondcolorReport',
    component:DiamondcolorReportComponent
},
{
    path :'diamondcutgradeReport',
    component:DiamondcutgradeReportComponent
},
{
    path :'diamondcertificateReport',
    component:DiamondcertificateReportComponent
},
{
    path :'diamondshapeReport',
    component:DiamondshapeReportComponent
} ,
{
    path :'diamondsizeReport',
    component:DiamondsizeReportComponent
} 
];

@NgModule({
  declarations: [DiamondReportComponent, RetailersearchReportComponent, ExtendeddiamondReportComponent, DiamondclarityReportComponent, DiamondcolorReportComponent, DiamondcutgradeReportComponent, DiamondcertificateReportComponent, DiamondshapeReportComponent, DiamondsizeReportComponent],
  imports: [MatDatepickerModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,MatRadioModule,
    CommonModule,MatDividerModule,
    RouterModule.forChild(diamondRoutes),
    ],

})
export class DiamondReportsModule { }
