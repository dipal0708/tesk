import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondcertificateReportComponent } from './diamondcertificate-report.component';

describe('DiamondcertificateReportComponent', () => {
  let component: DiamondcertificateReportComponent;
  let fixture: ComponentFixture<DiamondcertificateReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondcertificateReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondcertificateReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
