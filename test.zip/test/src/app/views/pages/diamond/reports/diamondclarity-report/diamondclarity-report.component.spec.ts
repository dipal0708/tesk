import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondclarityReportComponent } from './diamondclarity-report.component';

describe('DiamondclarityReportComponent', () => {
  let component: DiamondclarityReportComponent;
  let fixture: ComponentFixture<DiamondclarityReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondclarityReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondclarityReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
