import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondsizeReportComponent } from './diamondsize-report.component';

describe('DiamondsizeReportComponent', () => {
  let component: DiamondsizeReportComponent;
  let fixture: ComponentFixture<DiamondsizeReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondsizeReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondsizeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
