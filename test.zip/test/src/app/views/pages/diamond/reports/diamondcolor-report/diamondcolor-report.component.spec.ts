import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondcolorReportComponent } from './diamondcolor-report.component';

describe('DiamondcolorReportComponent', () => {
  let component: DiamondcolorReportComponent;
  let fixture: ComponentFixture<DiamondcolorReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondcolorReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondcolorReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
