import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiamondReportComponent } from './diamond-report.component';

describe('DiamondReportComponent', () => {
  let component: DiamondReportComponent;
  let fixture: ComponentFixture<DiamondReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiamondReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiamondReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
