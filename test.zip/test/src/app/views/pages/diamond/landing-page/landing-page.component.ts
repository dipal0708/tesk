import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { UserService } from '../../../../core/services/users.service';
import { DataRoutingService } from '../../../dataRouting.service';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'kt-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent implements OnInit {
  // totalItems:string;
  naturaltotalItems: any;
  labtotalItems:any;
  colortotalItems:any;

  message: string;
  companies:any=[];
  private unsubscribe: Subject<any>;
  constructor(private router: Router,private service: UserService, private datarouteservice: DataRoutingService,private cdr: ChangeDetectorRef) {
    this.unsubscribe = new Subject();
   }

  ngOnInit() {
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    // this.datarouteservice.currentMessage.subscribe(message => this.message = message)
     debugger
    var obj = { dealerid: this.companies[0].dealerid }
    this.service.getTotalDiamonds(obj).pipe(
			tap(usr => {         
				if (usr.status==200) {           
					let num :number = Number(usr.data[0].totaldiamond);
          this.naturaltotalItems = num;
          this.labtotalItems =  Number(usr.labdiamond[0].totaldiamond);
          this.colortotalItems =  Number(usr.colordiamond[0].totaldiamond);
				} else {
          this.naturaltotalItems = 0;
          this.labtotalItems = 0;
          this.colortotalItems = 0;
				}
			}),
			takeUntil(this.unsubscribe),
			finalize(() => {
				this.cdr.detectChanges(); 
			})
		).subscribe();
    // var obj = { dealerid: 720 }
    // this.service.getTotalDiamonds(obj).subscribe((data: any) => {
    //   let num :number = Number(data.data[0].totaldiamond);
    //   //this.totalItems = num;
    //   document.getElementById("lblTotalDiamondCount").innerHTML = "Total Diamonds : " +  num.toLocaleString();//.join(".");
    // });
  }
  routeTo(routeString) {
    debugger
    this.router.navigateByUrl('/default/diamondsearch/'+ routeString);
    // this.datarouteservice.changeMessage(routeString);
  }
}
