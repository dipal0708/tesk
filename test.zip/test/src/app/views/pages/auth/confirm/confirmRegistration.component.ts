import {Component, OnDestroy, OnInit, ChangeDetectorRef} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
//rxjs
import { finalize, takeUntil, tap, timeInterval } from 'rxjs/operators';
import { LoggedInCallback } from '../../../../core/services/cognito.service';
import {  AuthService, AuthNoticeService, User } from '../../../../core/auth';
import { TranslateService } from "@ngx-translate/core";
import { Subject } from "rxjs";
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ToastrService } from "ngx-toastr";
import { UserService } from "../../../../core/services/users.service";

@Component({
    selector: 'awscognito-angular2-app',
    templateUrl: './confirmRegistration.html'
})
export class RegistrationConfirmationComponent implements OnInit, OnDestroy {
    confirmationCode: string;
    email: string;
    errorMessage: string;
    private sub: any;
	private unsubscribe: Subject<any>; 
	confirmRegForm: FormGroup;

	constructor(public regService: AuthService,
		private toastr: ToastrService,
		private auth: AuthService,
		private cdr: ChangeDetectorRef,
		private userservice:UserService,
		public authNoticeService: AuthNoticeService, private translate: TranslateService, public router: Router, public route: ActivatedRoute,private fb:FormBuilder) {
		this.unsubscribe = new Subject();
    }

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            this.email = params['username'];
        });
		this.errorMessage = null;
		this.initRegisterForm();
    }
	initRegisterForm() {
		this.confirmRegForm = this.fb.group({
			confirmCode: ['', Validators.compose([
				Validators.required,
				Validators.minLength(6),
				Validators.maxLength(6)
			])
			],
		})

	}
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
	onConfirmRegistration() {
		if (this.confirmRegForm.invalid) {
			if (this.confirmRegForm.value.confirmCode == "") { 
				this.toastr.error(this.translate.instant('Please Insert Code.'), '');	
			}
			else {
				this.toastr.error(this.translate.instant('Please Enter 6 Digit Code.'), '');
			}
			return;
		}
		this.errorMessage = null;
		var _user = JSON.parse(localStorage.getItem('userDetail'));
		_user.email= this.email;
		
	
		this.router.navigate(['/']);

		this.auth.confirmRegistration(_user,this.confirmRegForm.value.confirmCode).subscribe((data:any)=>{
			if(data.status==200){
				
				// this.userservice.postAdduser(_user).subscribe((data:any)=>{
					
				// });
					// this is for static data store ----------------------------------------------------------------------------------------
			this.toastr.success(this.translate.instant('Your account is verified successfully.'), '');
			this.router.navigate(['/']);		}
			else
			{this.toastr.error(this.translate.instant(data.data.message), '');}
		},(err)=>{
			var k = err;
			this.toastr.error(this.translate.instant(err.msg.message), '');
		});
		///this.registerEntry();
		//this.regService.confirmRegistration(this.email, this.confirmRegForm.value.confirmCode, this);
	}

    cognitoCallback(message: string, result: any) {
        if (message != null) { //error
            this.errorMessage = message;
			console.log("message: " + this.errorMessage);
			this.toastr.error(this.translate.instant(this.errorMessage), '');
        } else { //success
            //move to the next step			
			
            console.log("Moving to securehome");
            // this.configs.curUser = result.user;            
        }
	}

	registerEntry() {		
		var _user = JSON.parse(localStorage.getItem('userDetail'));
		this.auth.registerSubmit(_user).pipe(
			tap(user => {
				if (user) {
					//success
					this.toastr.success(this.translate.instant('Your account is verified successfully.'), '');
					this.router.navigate(['/']);
				} else {
					this.toastr.error(this.translate.instant('AUTH.VALIDATION.INVALID_LOGIN'), '');					
				}
			}),
			takeUntil(this.unsubscribe),
			finalize(() => {
				this.cdr.detectChanges();
			})
		).subscribe();
	}
	resendCode(){
		localStorage.setItem('registerEmail',this.email);
		this.router.navigate(['/auth/resendCode']);
	}
}





