// Angular
import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes,PreloadAllModules } from '@angular/router';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
// Material
import { MatCardModule ,MatButtonModule,MatAutocompleteModule,MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule } from '@angular/material';
// Translate
import { TranslateModule } from '@ngx-translate/core';
// NGRX
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
// CRUD
import { InterceptService } from '../../../core/_base/crud/';
// Module components
import { AuthComponent } from './auth.component';
// import { LoginComponent } from './login/login.component';
// import { RegisterComponent } from './register/register.component';
// import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';

import { AuthNoticeComponent } from './auth-notice/auth-notice.component';
// Auth
import { AuthService, authReducer, AuthGuard, AuthEffects  } from '../../../core/auth';
// import { RegistrationConfirmationComponent } from './confirm/confirmRegistration.component';
// import { ForgotPassword2Component } from './forgot-password/forgot-password2.component';
// import { ResendCodeComponent } from './resend-code/resendCode.component';
const routes: Routes = [
	{
		path: '',
		component: AuthComponent,
		children: [
			{
				path: '',
				redirectTo: 'login',
				pathMatch: 'full'
			},
			{
				path: 'login',
				loadChildren: './login/login.module#LoginModule'
			},
			
			{
				path: 'register',
				
				 loadChildren: './register/register.module#RegisterModule'
				//component: RegisterComponent
			},
			{
				path: 'forgot-password',
				
				loadChildren: './forgot-password/forgotpassword.module#ForgotPasswordModule'
				//component: ForgotPasswordComponent,
			},
			// {
			// 	path: 'forgotpassword/:email',
			// 	component: ForgotPassword2Component,
			// },
			{
				path: 'confirmRegistration/:username',
				
				loadChildren: './confirm/confirmregistration.module#ConfirmRegistrationModule'
				//component: RegistrationConfirmationComponent,
			},
			{
				path: 'resendCode',
			
				loadChildren: './resend-code/resendcode.module#ResendCodeModule'
				//component: ResendCodeComponent,
			},
			
		],
	}
];


@NgModule({
	imports: [
		
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatButtonModule,
		MatCardModule ,
		RouterModule.forChild(routes),
		MatInputModule,
		MatFormFieldModule,
		MatCheckboxModule,
		MatSelectModule,
		MatOptionModule,
		MatAutocompleteModule,
		MatIconModule,
		TranslateModule.forChild(),
		StoreModule.forFeature('auth', authReducer),
        EffectsModule.forFeature([AuthEffects])
	],
	providers: [
		InterceptService,
      	{
        	provide: HTTP_INTERCEPTORS,
       	 	useClass: InterceptService,
        	multi: true
      	},
	],
	exports: [AuthComponent],
	declarations: [
		AuthComponent,
		//LoginComponent,
		// RegisterComponent,
		// ForgotPasswordComponent,
		// ForgotPassword2Component,
		AuthNoticeComponent,
		// RegistrationConfirmationComponent,
		// ResendCodeComponent,
	]
})

export class AuthModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: AuthModule,
            providers: [
				AuthService,
				AuthGuard
            ]
        };
    }
}
