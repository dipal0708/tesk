// Angular
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// RxJS
import { finalize, takeUntil, tap, timeInterval } from 'rxjs/operators';
// Translate
import { TranslateService } from '@ngx-translate/core';
// NGRX
import { Store } from '@ngrx/store';
import { AppState } from '../../../../core/reducers';
// Auth
import { AuthNoticeService, AuthService, Register, User } from '../../../../core/auth/';
import { Subject } from 'rxjs';
import { ConfirmPasswordValidator } from './confirm-password.validator';
import { ApiService } from '../../../../core/services/api.service';
import { CognitoCallback } from '../../../../core/services/cognito.service';
import { UserService } from '../../../../core';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { registerLocaleData } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { commanUrl } from '../../../../../environments/commanUrl';

@Component({
	selector: 'kt-register',
	templateUrl: './register.component.html',
	encapsulation: ViewEncapsulation.None
})
export class RegisterComponent implements CognitoCallback {

	registerForm: FormGroup;
	signUp:any;
	loading = false;
	errors: any = [];
	countryList: any = [];
	emailvalidate: any=true;
	getCountrycode: any = ['+000'];
	
	// options = ['One', 'Two', 'Three'];
	filteredOptions: Observable<string[]>;

	
	private unsubscribe: Subject<any>; // Read more: => https://brianflove.com/2016/12/11/anguar-2-unsubscribe-observables/

	/**
	 * Component constructor
	 *
	 * @param authNoticeService: AuthNoticeService
	 * @param translate: TranslateService
	 * @param router: Router
	 * @param auth: AuthService
	 * @param store: Store<AppState>
	 * @param fb: FormBuilder
	 * @param cdr
	 */
	constructor(
		private authNoticeService: AuthNoticeService,
		private translate: TranslateService,
		private router: Router,
		private auth: AuthService,
		private store: Store<AppState>,
		private fb: FormBuilder,
		private cdr: ChangeDetectorRef,
		private apiService: ApiService,
		private toastr: ToastrService,
		private usersService: UserService
	) {
		this.unsubscribe = new Subject();
		this.router = router;
	}

	/*
	 * @ Lifecycle sequences => https://angular.io/guide/lifecycle-hooks
    */

	/**
	 * On init
	 */
	ngOnInit() {
		this.signUp = commanUrl.signUp;
		this.initRegisterForm();

		this.filteredOptions = this.registerForm.controls['country'].valueChanges.pipe(
			startWith(''),
			map(val => this.filter(val))
		  );

		this.usersService.getCountry().subscribe((data: any) => {
			var data1 = data.data;
			this.countryList  = data1.sort(function(a, b) {
				if(a.country_name < b.country_name) { return -1; }
				if(a.country_name > b.country_name) { return 1; }
				return 0;
				// Ascending: first age less than the previous
			});
		});
		this.registerForm.controls['countryCode'].disable();
	}

	/*
    * On destroy
    */
	ngOnDestroy(): void {

		this.unsubscribe.next();
		this.unsubscribe.complete();
		this.loading = false;
	}

	/**
	 * Form initalization
	 * Default params, validators
	 */
	initRegisterForm() {
		this.registerForm = this.fb.group({
			companyname: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			name: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			lastname: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			
			address: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			city: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			state: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			country: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			zipcode: ['', Validators.compose([
				Validators.required,
				Validators.minLength(5),
				Validators.maxLength(10)
			])
			],
			 
			accounttype: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			contactno: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(15),
				Validators.pattern("^[0-9]*$"),				
			])
			],
			//------------------------------------------------------------------------------------------------------------------------------------
		 
			email: ['', Validators.compose([
				Validators.required,
				Validators.email,
				Validators.minLength(3),
				// https://stackoverflow.com/questions/386294/what-is-the-maximum-length-of-a-valid-email-address
				Validators.maxLength(320)
			]),
			],
			username: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			]),
			],
			password: ['', Validators.compose([
				Validators.required,
				Validators.minLength(8),
				Validators.maxLength(15)
			])
			],
			confirmPassword: [''],
			countryCode:[''],
			agree: [false, Validators.compose([Validators.required])]
		}
			, {
				validator: ConfirmPasswordValidator.MatchPassword
			}
		);
	}

	/**
	 * Form Submit
	 */

	submit() {
		const controls = this.registerForm.controls;

		 
		// check form
		if (this.registerForm.invalid) {
			Object.keys(controls).forEach(controlname =>
				controls[controlname].markAsTouched()
			);
			return;
		}



		if (!controls['agree'].value) {
			// you must agree the terms and condition
			// checkbox cannot work inside mat-form-field https://github.com/angular/material2/issues/7891
			this.toastr.error('You must agree the terms and condition', '');
			//this.authNoticeService.setNotice('You must agree the terms and condition', 'danger');
			return;
		}
		this.loading = true;
		const _user: User = new User();

			_user.pk_id = "9577e330-5544-11e9-b898-e35cda8b606c",
			_user.accesstoken = 'access-token-' + Math.random();
			//_user.accesstoken = "dfdsfdsfdfd",
			_user.account_type = this.registerForm.value.accounttype;
			_user.address = this.registerForm.value.address;
			_user.city = this.registerForm.value.city;
			_user.company_name = this.registerForm.value.companyname;
			_user.contact_no = this.registerForm.value.contactno;
			var cntry = this.countryList.filter(x => x.country_name.toLowerCase() == this.registerForm.value.country.toLowerCase());
			_user.country =cntry[0].pk_id;
			_user.created_date = new Date().toJSON().slice(0, 10);//"2019-04-11",
			_user.currency = 'null',
			_user.email = this.registerForm.value.email,
			_user.language = 'null',
			_user.firstname = this.registerForm.value.name,
			_user.lastname = this.registerForm.value.lastname,
			_user.password = this.registerForm.value.password,
			_user.refreshtoken = 'null',
			_user.roles = "2",
			_user.state = this.registerForm.value.state,
			_user.updated_date = new Date().toJSON().slice(0, 10);// "2019-04-11",
			_user.user_name = this.registerForm.value.username,
			_user.zip_code = this.registerForm.value.zipcode,

			this.auth.registerSubmit(_user).subscribe((data:any)=>{
			if(data.status == 200){
				localStorage.setItem('userDetail', JSON.stringify(_user));
				this.toastr.success(this.translate.instant('Please check your Email for verification code.'), '');
				this.router.navigate(['/auth/confirmRegistration', data.data.user.username]);			}
				else
			{
				this.toastr.error(this.translate.instant(data.data.message), '');
			}
			},(err)=>{
				var k = err;
				this.toastr.error(this.translate.instant(err.msg.message), '');
			});
		
		
		// .subscribe((data:any)=>{
		// 	
		// 	localStorage.setItem('userDetail', JSON.stringify(_user));
		// 	this.router.navigate(['/auth/confirmRegistration', data.data.user.username]);		
		// },(err)=>{
		// 	
		// 	var k = err;
		// });
		this.loading = false;
	}

	/**
	 * Checking control validation
	 *
	 * @param controlName: string => Equals to formControlName
	 * @param validationType: string => Equals to valitors name
	 */
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.registerForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

	cognitoCallback(message: string, result: any) {

		if (message != null) { //error
			///this.errorMessage = message;
			 
			this.toastr.error(this.translate.instant(message, 'AUTH.REGISTER.SUCCESS'), '');
			//this.authNoticeService.setNotice(this.translate.instant(message, 'AUTH.REGISTER.SUCCESS'), 'danger');
		} else { //success
			//move to the next step			
			this.toastr.success(this.translate.instant('AUTH.REGISTER.SUCCESS'), '');
			//this.authNoticeService.setNotice(this.translate.instant('AUTH.REGISTER.SUCCESS'), 'success');
			console.log("redirecting");
			
			this.router.navigate(['/auth/confirmRegistration', result.user.username]);
			  
		}
	}

	getCountryCode() {
		
		var countryCode = this.countryList.filter(x => x.country_name.toLowerCase() == this.registerForm.value.country.toLowerCase());
		if(countryCode.length == 1){
      this.getCountrycode = countryCode[0].country_code;
		};
	}

	onEmailValidate(emailvalue) {
		var k = this.registerForm.value.email.includes('@')
		if (k == true) {
			this.emailvalidate = this.registerForm.value.email.includes('.')
			if (this.emailvalidate == true) {
			}
			else {
				this.registerForm.controls['email'].setErrors({ 'incorrect': true });
			}
		}

	}
	filter(val: string): string[] {
		//let opt = this.countryList.filter(option => option.country_name.toLowerCase().indexOf(val.toLowerCase()) === 0);		 
		///this.registerForm.controls['country'].setValue(opt);
		return this.countryList.filter(option => option.country_name.toLowerCase().indexOf(val.toLowerCase()) === 0);
	}
}
