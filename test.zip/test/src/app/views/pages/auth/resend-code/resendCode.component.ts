// Angular
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
// RxJS
import { finalize, takeUntil, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';
// Translate
import { TranslateService } from '@ngx-translate/core';
// Auth
import { AuthNoticeService, AuthService } from '../../../../core/auth';
import { CognitoCallback } from '../../../../core/services/cognito.service';
import { ToastrService } from 'ngx-toastr';
import { commanUrl } from '../../../../../environments/commanUrl';


@Component({
    selector: 'awscognito-angular2-app',
    templateUrl: './resendCode.component.html'
})
export class ResendCodeComponent implements CognitoCallback {
	loading = false;
    email: string;
    errorMessage: string;
	emailvalidate:any=true;
	registerdata:any=[];
	resendCodes:any;
    resendCodeForm: FormGroup;

	constructor(public router: Router, public route: ActivatedRoute,private toastr: ToastrService,
		public userService: AuthService, public authNoticeService: AuthNoticeService,private fb: FormBuilder,
		private translate: TranslateService) {

    }
    ngOnInit() {
		this.resendCodes = commanUrl.resendCodes;
		this.registerdata  = localStorage.getItem('registerEmail');
		this.initRegistrationForm();
	}
    resendCode() {			
        if(this.resendCodeForm.invalid){
			return
		}
		// if(this.resendCodeForm.value.email.trim() != this.registerdata){
		// 	this.toastr.error(this.translate.instant('This is not a valid Email'), '');
		// 	return
		// }
        //this.userService.resendCode(this.resendCodeForm.value.email, this);
			// this.userService.resendCode(this.email, this);      
		this.userService.resendCode(this.resendCodeForm.value.email.trim()).subscribe((data:any)=>{
			if(data.status==200){
			this.router.navigate(['/auth/confirmRegistration',this.registerdata]);		}
			else
			{this.toastr.error(this.translate.instant(data.data.message), '');}
		},(err)=>{
			var k = err;
			this.toastr.error(this.translate.instant(err.msg.message), '');
		});  
	
    }
    isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.resendCodeForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result =
			control.hasError(validationType) ;
		return result;
	}
    cognitoCallback(error: any, result: any) {
        if (error != null) {
            this.errorMessage = error; //"Something went wrong...please try again";
            this.toastr.error(this.translate.instant(this.errorMessage), '');
			//this.authNoticeService.setNotice(this.translate.instant(this.errorMessage), 'danger');
        } else {
            this.router.navigate(['/auth/confirmRegistration',this.registerdata]);
        }
    }
    initRegistrationForm() {
		this.resendCodeForm = this.fb.group({
			email: ['', Validators.compose([
				Validators.required,
				Validators.email,
				Validators.minLength(3),
				Validators.maxLength(320) // https://stackoverflow.com/questions/386294/what-is-the-maximum-length-of-a-valid-email-address
			])
			]
		});
    }
    OnSearchChange(emailvalue) {
		var k = this.resendCodeForm.value.email.includes('@')
		if (k == true) {
			this.emailvalidate = this.resendCodeForm.value.email.includes('.')
			if (this.emailvalidate == true) {
			}
			else {
				this.resendCodeForm.controls['email'].setErrors({ 'incorrect': true });
			}
		}
	}
	backTo(){ 
		this.router.navigate(['/auth/confirmRegistration', this.registerdata]);
	}

}
