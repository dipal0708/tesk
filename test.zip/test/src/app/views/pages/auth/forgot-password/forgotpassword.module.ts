// Angular
import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
// Material
import { MatCardModule ,MatButtonModule,MatAutocompleteModule,MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule } from '@angular/material';
// Translate
import { TranslateModule } from '@ngx-translate/core';
// NGRX
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
// CRUD
import { InterceptService } from '../../../../core/_base/crud/';
// Module components
import { AuthNoticeComponent } from './../auth-notice/auth-notice.component';
// Auth
import { AuthService, authReducer, AuthGuard, AuthEffects  } from '../../../../core/auth';

 import { ForgotPassword2Component } from './forgot-password2.component';
 import { ForgotPasswordComponent } from './forgot-password.component';

const routes: Routes = [
	{
		path: 'forgotpassword/:email',
		component: ForgotPassword2Component,
    },
    {
		path: '',
		component: ForgotPasswordComponent,
	}
];
@NgModule({
    declarations: [ForgotPassword2Component,ForgotPasswordComponent],//
    imports: [
		
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatButtonModule,
		MatCardModule ,
		RouterModule.forChild(routes),
		MatInputModule,
		MatFormFieldModule,
		MatCheckboxModule,
		MatSelectModule,
		MatOptionModule,
		MatAutocompleteModule,
		MatIconModule,
		TranslateModule.forChild(),
		StoreModule.forFeature('auth', authReducer),
        EffectsModule.forFeature([AuthEffects])
	],
  
  })
  export class ForgotPasswordModule { }