// Angular
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
// RxJS
import { finalize, takeUntil, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';
// Translate
import { TranslateService } from '@ngx-translate/core';
// Auth
import { AuthService } from '../../../../core/auth';
import { CognitoCallback } from '../../../../core/services/cognito.service';
import { ToastrService } from 'ngx-toastr';
import { User } from '../../../../core/auth/_models/user.model';
import { commanUrl } from '../../../../../environments/commanUrl';

@Component({
	selector: 'kt-forgot-password',
	templateUrl: './forgotPasswordStep2.component.html',
	encapsulation: ViewEncapsulation.None
})

export class ForgotPassword2Component implements CognitoCallback, OnInit, OnDestroy {
	
	verificationCode: string;
	email: string;
	password: string;
	errorMessage: string;
	private sub: any;
	private unsubscribe: Subject<any>; 

	constructor(public router: Router, public route: ActivatedRoute,private toastr: ToastrService,
		public userService: AuthService, private cdr: ChangeDetectorRef,
		private translate: TranslateService) {
		console.log("email from the url: " + this.email);
	}

	ngOnInit() {
		this.sub = this.route.params.subscribe(params => {
			this.email = params['email'];

		});
		this.errorMessage = null;
	}

	ngOnDestroy() {
		this.sub.unsubscribe();
	}

	onNext() {
		this.errorMessage = null;
		///this.userService.confirmNewPassword(this.email, this.verificationCode, this.password, this);
		this.userService.confirmNewPassword(this.email, this.verificationCode, this.password).subscribe((data:any)=>{
			//this.router.navigate(['/auth/confirmRegistration',this.registerdata]);		
			if(data.status==200){
				this.changePassword();
			}
			else
			{
				//'Password contain 8 char with lower/uppper & one numeric and symbol char.'
				this.toastr.error(data.data.message, '');
			}
		},(err)=>{
			var k = err;
			this.toastr.error(this.translate.instant(err.msg.message), '');
		});
		
	}

	cognitoCallback(message: string) {
		if (message != null) { //error			
			this.errorMessage = message;
			this.toastr.error(this.translate.instant('Invalid verification code provided, please try again.'), '');
			//this.authNoticeService.setNotice(this.translate.instant('Invalid verification code provided, please try again.'), 'danger');
			console.log("result: " + this.errorMessage);
		} else { //success
			this.changePassword()
			
		}
	}
	changePassword() {			
		const _user: User = new User();
		this.userService.getUserDetailbyEmail(this.email).subscribe((data: any) => {		
			_user.pk_id=data.data[0].pk_id;			
			_user.password=this.password;			
			_user.email=this.email;			
			this.userService.changePassword(_user).subscribe((data:any)=>{
				if(data.status == 200){
					this.toastr.success(this.translate.instant('Something wrong, Try again.'), '');
				}else{					
					this.toastr.success(this.translate.instant('Your password is reset successfully.'), '');
					this.router.navigate(['/auth/login']);
				}
				
			});
		});
	}
	backTo(){
		
		this.router.navigate(['/auth/forgot-password']);
	}
}
