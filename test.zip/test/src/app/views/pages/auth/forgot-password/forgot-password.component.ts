// Angular
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
// RxJS
import { finalize, takeUntil, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';
// Translate
import { TranslateService } from '@ngx-translate/core';
// Auth
import { AuthNoticeService, AuthService } from '../../../../core/auth';
import { CognitoCallback } from '../../../../core/services/cognito.service';
import { ToastrService } from 'ngx-toastr';
import { commanUrl } from '../../../../../environments/commanUrl';

@Component({
	selector: 'kt-forgot-password',
	templateUrl: './forgot-password.component.html',
	encapsulation: ViewEncapsulation.None
})
export class ForgotPasswordComponent implements CognitoCallback {
	// Public params
	forgotPasswordForm: FormGroup;
	loading = false;
	errors: any = [];
	email: string;
	errorMessage: string;
	emailvalidate:any=true;
	forgotPassword:any;

	private unsubscribe: Subject<any>; // Read more: => https://brianflove.com/2016/12/11/anguar-2-unsubscribe-observables/

	/**
	 * Component constructor
	 *
	 * @param authService
	 * @param authNoticeService
	 * @param translate
	 * @param router
	 * @param fb
	 * @param cdr
	 */
	constructor(
		private authService: AuthService,
		public authNoticeService: AuthNoticeService,
		private translate: TranslateService,
		private router: Router,
		private fb: FormBuilder,
		private toastr: ToastrService,
		private cdr: ChangeDetectorRef
	) {
		this.unsubscribe = new Subject();
	}

	/**
	 * @ Lifecycle sequences => https://angular.io/guide/lifecycle-hooks
	 */

	/**
	 * On init
	 */
	ngOnInit() {
		this.forgotPassword = commanUrl.forgotPassword;
		this.initRegistrationForm();
	}

	/**
	 * On destroy
	 */
	ngOnDestroy(): void {
		this.unsubscribe.next();
		this.unsubscribe.complete();
		this.loading = false;
	}

	/**
	 * Form initalization
	 * Default params, validators
	 */
	initRegistrationForm() {
		this.forgotPasswordForm = this.fb.group({
			email: ['', Validators.compose([
				Validators.required,
				Validators.email,
				Validators.minLength(3),
				Validators.maxLength(320) // https://stackoverflow.com/questions/386294/what-is-the-maximum-length-of-a-valid-email-address
			])
			]
		});
	}

	/**
	 * Form Submit
	 */
	submit() {
		debugger
		const controls = this.forgotPasswordForm.controls;
		/** check form */
		if (this.forgotPasswordForm.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);
			return;
		}

		this.loading = true;

		const email = controls['email'].value;
		///this.authService.requestPassword(email, this);
		
		this.authService.requestPassword(email.trim()).subscribe((data:any)=>{
			if(data.status==200)
			{this.router.navigate(['/auth/forgot-password/forgotpassword/', email]);}
			else
			{this.toastr.error(this.translate.instant(data.data.message), '');}
		},(err)=>{
			var k = err;
			this.toastr.error(this.translate.instant(err.msg.message), '');
		});  
		this.loading = false;
	}

	/**
	 * Checking control validation
	 *
	 * @param controlName: string => Equals to formControlName
	 * @param validationType: string => Equals to valitors name
	 */
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.forgotPasswordForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result =
			control.hasError(validationType) &&
			(control.dirty || control.touched);
		return result;
	}


	cognitoCallback(message: string, result: any) {		
		if (message == null && result == null) { 
			this.router.navigate(['/auth/forgotpassword/', this.forgotPasswordForm.controls.email.value]);

		} else { 
			this.toastr.error(this.translate.instant('AUTH.VALIDATION.NOT_FOUND', { name: this.translate.instant('AUTH.INPUT.EMAIL') }), '');			
		}
	}

	cencel() {
		if (this.forgotPasswordForm.value.email == "") {
			this.router.navigate(['/auth/login']);
		} else {
		}
	};
	onSearchChange(emailvalue) {
		var k = this.forgotPasswordForm.value.email.includes('@')
		if (k == true) {
			this.emailvalidate = this.forgotPasswordForm.value.email.includes('.')
			if (this.emailvalidate == true) {
			}
			else {
				this.forgotPasswordForm.controls['email'].setErrors({ 'incorrect': true });
			}
		}

	}
}

