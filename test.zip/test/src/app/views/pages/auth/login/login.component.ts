// Angular
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// RxJS
import { Observable, Subject } from 'rxjs';
import { finalize, takeUntil, tap } from 'rxjs/operators';
// Translate
import { TranslateService } from '@ngx-translate/core';
// Store
import { Store } from '@ngrx/store';
import { AppState } from '../../../../core/reducers';
// Auth
import { AuthNoticeService,  Login } from '../../../../core/auth'; //AuthService
import { environment } from '../../../../../environments/environment';
 import { ToastrService } from 'ngx-toastr';
import { User } from '../../../../core/auth/_models/user.model';
import { TranslationService } from '../../../../core/_base/metronic';
import { UserService } from '../../../../core/services/users.service';
/**
 * ! Just example => Should be removed in development
 */
const USER = {
	EMAIL: '',
	PASSWORD: ''
};

@Component({
	selector: 'kt-login',
	templateUrl: './login.component.html',
	encapsulation: ViewEncapsulation.None
})
export class LoginComponent implements OnInit, OnDestroy {  //
	// Public params
	loginForm: FormGroup;
	loading = false;
	isLoggedIn$: Observable<boolean>;
	errors: any = [];
	email: string;
	password: string;
	errorMessage: string;
	mfaStep = false;
	emailvalidate:any=true;
	private unsubscribe: Subject<any>;
	/**
	 * Component constructor
	 *
	 * @param router: Router
	 * @param auth: AuthService
	 * @param authNoticeService: AuthNoticeService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 * @param fb: FormBuilder
	 * @param cdr
	 */
	constructor(
		private router: Router,
		private auth: UserService,
		private authNoticeService: AuthNoticeService,
		private store: Store<AppState>,
		private fb: FormBuilder,
		private cdr: ChangeDetectorRef,
		private toastr: ToastrService,
		private translationService: TranslationService,
	) {
		this.unsubscribe = new Subject();
	}
	ngOnInit(): void {
		this.initLoginForm();
	}
	ngOnDestroy(): void {
		this.authNoticeService.setNotice(null);
		this.unsubscribe.next();
		this.unsubscribe.complete();
		this.loading = false;
	}
	initLoginForm() {
		localStorage.setItem('language', 'en');
		this.translationService.setLanguage('en');
		this.loginForm = this.fb.group({
			email: [USER.EMAIL, Validators.compose([
				Validators.required,
				Validators.email,
				Validators.minLength(3),
				Validators.maxLength(320)
			])
			],
			password: [USER.PASSWORD, Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			]
		});
	}
	submit() {
		const controls = this.loginForm.controls;
		if (this.loginForm.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);
			this.toastr.error('Incorrect Email-id or Password. Try again.', '');
			return;
		}
		this.loading = true;
		const authData = {
			email: controls['email'].value,
			password: controls['password'].value
		};
		const _user: User = new User();
		_user.email=authData.email;
		_user.password=authData.password;
		this.auth.getUserDetail(_user).pipe(
			tap((usr:any) => {
				if (usr.status==200) {
					this.toastr.success('Login successfully', ''); 
					localStorage.setItem(environment.authTokenKey, usr.data[0].accesstoken);
					localStorage.setItem('dataSource', usr.data[0].accesstoken);	
					this.store.dispatch(new Login({ authToken: usr.data[0].accesstoken }));
					
					localStorage.setItem('userDetail', JSON.stringify(usr.data[0]));
					if(usr.data[0].language="null"){
						localStorage.setItem('language', 'en');		
						this.translationService.setLanguage('en');												
					}else{
						localStorage.setItem('language', usr.data[0].language);
						this.translationService.setLanguage(usr.data[0].language);
					}
				} else {
					this.toastr.error('Invalid Username Or Password');
				}
			}),	
			takeUntil(this.unsubscribe),
			finalize(() => {
				this.loading = false;
				//
				this.cdr.detectChanges();
				this.router.navigateByUrl('/');
				this.router.navigateByUrl('/default/dashboard');
			})
		).subscribe();
		this.loading = false;
	}

	/**
	 * Checking control validation
	 *
	 * @param controlName: string => Equals to formControlName
	 * @param validationType: string => Equals to valitors name
	 */
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.loginForm.controls[controlName];
		if (!control) {
			return false;
		}
		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}
	
	isLoggedIn(message: string, isLoggedIn: boolean) {
		if (isLoggedIn) {
			this.router.navigateByUrl('/');
		}
	}
	onSearchChange(emailvalue) {
		var k = this.loginForm.value.email.includes('@');
        if (k == true && emailvalue != "") {
            this.emailvalidate = this.loginForm.value.email.includes('.')
            if (this.emailvalidate == true) {
            }
            else {
                this.loginForm.controls['email'].setErrors({ 'incorrect': true });
            }
        }
        else{
            this.loginForm.controls['email'].setErrors({ 'incorrect': false });
        }
	}
}
