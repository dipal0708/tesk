import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { DragDropModule } from '@angular/cdk/drag-drop';
 import { FileUploadModule } from 'ng2-file-upload';
import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { PurchaseOrderHistoryComponent } from './purchase-order-history/purchase-order-history.component';
import { UpdatePurchaseOrderComponent } from './update-purchase-order/update-purchase-order.component';



const diamondRoutes: Routes = [
  {
    path: 'PurchaseOrderHistory',
    component: PurchaseOrderHistoryComponent

  },
  {
    path: 'UpdatePurchaseOrder',
    component: UpdatePurchaseOrderComponent

  }
  

  
  
];
@NgModule({
  declarations: [PurchaseOrderHistoryComponent, UpdatePurchaseOrderComponent],
  imports: [DragDropModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
    MatSlideToggleModule,CommonModule,InfiniteScrollModule,
    RouterModule.forChild(diamondRoutes),
    FileUploadModule,TranslateModule.forRoot(),
  ],

})
export class JewelryPurchaseOrderModule { }
