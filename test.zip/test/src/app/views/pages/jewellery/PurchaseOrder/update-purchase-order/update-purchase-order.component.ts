import { Component, OnInit,ViewChild } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import { ToastrService } from 'ngx-toastr';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import { ConfirmPopupboxComponent } from '../../../diamond/common-component/confirm-popupbox/confirm-popupbox.component';

@Component({
  selector: 'kt-update-purchase-order',
  templateUrl: './update-purchase-order.component.html',
  styleUrls: ['./update-purchase-order.component.scss']
})
export class UpdatePurchaseOrderComponent implements OnInit {

  displayedColumns: string[] = ['retailername','product','quantity','orderdate','action'];


  dataSource : any = [{retailername:"Retailer 1", product:"Product1",quantity:"100",orderdate:"08/22/2019"},
  {retailername:"Retailer 2", product:"Product2",quantity:"200",orderdate:"08/23/2019"},
  {retailername:"Retailer 3", product:"Product3",quantity:"300",orderdate:"08/24/2019"},
  {retailername:"Retailer 4", product:"Product4",quantity:"400",orderdate:"08/25/2019"},
  {retailername:"Retailer 5", product:"Product5",quantity:"500",orderdate:"08/26/2019"},];
 

  constructor() { }

  ngOnInit() {
  }

}
