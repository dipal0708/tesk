import { Component, OnInit,ViewChild } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import { ToastrService } from 'ngx-toastr';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import { ConfirmPopupboxComponent } from '../../../diamond/common-component/confirm-popupbox/confirm-popupbox.component';

@Component({
  selector: 'kt-purchase-order-history',
  templateUrl: './purchase-order-history.component.html',
  styleUrls: ['./purchase-order-history.component.scss']
})
export class PurchaseOrderHistoryComponent implements OnInit {

  displayedColumns: string[] = ['retailername','product','purchaseorderdate','orderconfirmdate','status','saleper'];


 dataSource : any = [{retailername:"Retailer 1", product:"Product1",purchaseorderdate:"08/21/2019",orderconfirmdate:"08/22/2019",status:"Confirm",saleper:"User1"},
 {retailername:"Retailer 2", product:"Product2",purchaseorderdate:"08/22/2019",orderconfirmdate:"08/23/2019",status:"Confirm",saleper:"User2"},
 {retailername:"Retailer 3", product:"Product3",purchaseorderdate:"08/23/2019",orderconfirmdate:"08/24/2019",status:"Confirm",saleper:"User3"},
 {retailername:"Retailer 4", product:"Product4",purchaseorderdate:"08/24/2019",orderconfirmdate:"08/25/2019",status:"Confirm",saleper:"User4"},
 {retailername:"Retailer 5", product:"Product5",purchaseorderdate:"08/25/2019",orderconfirmdate:"08/26/2019",status:"Confirm",saleper:"User5"},];

  constructor() { }

  ngOnInit() {
  }

}
