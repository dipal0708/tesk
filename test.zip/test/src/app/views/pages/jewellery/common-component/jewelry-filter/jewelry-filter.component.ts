import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../../../../core/services/users.service';
import { Options } from 'ng5-slider';
@Component({
  selector: 'kt-jewelry-filter',
  templateUrl: './jewelry-filter.component.html',
  styleUrls: ['./jewelry-filter.component.scss']
})
export class JewelryFilterComponent implements OnInit {

  constructor( @Inject(MAT_DIALOG_DATA) public data: any,private fb: FormBuilder,private service:UserService, public dialogRef: MatDialogRef<JewelryFilterComponent>) { }
  showSlider:boolean= false ;
  minValue2: number = 0;
  FilterData: FormGroup;
  companies:any;
  maxValue2: number = 100000;
  options2: Options = {
    floor: 0,
    ceil: 100000,
     step: 20
  };
  jewelrymetaltype:any=[];
  jewelrymetalcolor:any=[];
  jewelrycategory:any=[];


  ngOnInit() {
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this.getAlldropdownValue();
    this.initAddForm();
    this.allMetalTypeddl();
    this.allMetalColorddl();
    this.allCategory();
    this.allCollection();
  }


  initAddForm(){
    this.FilterData = this.fb.group({
      category:[''],
      metalcolor:[''],
      metaltype:[''],
      gender:[''],
      collection:[''],
      vendor:['']
    });
  }

  allMetalTypeddl(){
    
    var object={
      dealerid:this.companies[0].dealerid,
    }

    this.service.allJewelleryMetalType(object).subscribe((data:any)=>{
      debugger;
      this.jewelrymetaltype = data.data;
      // for(var i = 0; i <= data.data.length; i++) {

      //   this.alllistofmetaltype.push(data.data[i].metaltype);

      // }
     
    });
  }

  allMetalColorddl(){
    var objct={
      dealerid:this.companies[0].dealerid,
    }

    this.service.allJewelleryMetalColor(objct).subscribe((data:any)=>{
      debugger;
      
      this.jewelrymetalcolor=data.data;
      // for(var j = 0; j <= data.data.length; j++) {

      //   this.alllistofmetalcolor.push(data.data[j].metalcolor);

      // }
      
     
    });
    
  }

  allCategory(){
    var ob={
      dealerid:this.companies[0].dealerid,
    }

    this.service.allJewelleryCategory(ob).subscribe((data:any)=>{
      debugger

      this.jewelrycategory=data.data;
      // for(var k = 0; k <= data.data.length; k++) {

      //   this.alllistofcategory.push(data.data[k].categoryname);

      // }
     
     
    });
    
  }
  
  allCollection(){
    
    var object={
      dealerid:this.companies[0].dealerid,
    }

    this.service.allJewelleryCollection(object).subscribe((data:any)=>{
      debugger;
      //this.jewelrymetaltype = data.data;
      // for(var i = 0; i <= data.data.length; i++) {

      //   this.alllistofmetaltype.push(data.data[i].metaltype);

      // }
     
    });
  }

  cencelClick(){
    this.dialogRef.close()
  }
  onNoClick(): void {
   
    this.dialogRef.close("No");
  }
  getAlldropdownValue(){
    setTimeout(() => {
    this.showSlider = true;
  },400);
}
resetClick(){
}
applyFilterclick(){
  
}
  
}
