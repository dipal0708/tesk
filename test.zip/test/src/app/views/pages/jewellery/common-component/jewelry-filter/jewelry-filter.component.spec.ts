import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryFilterComponent } from './jewelry-filter.component';

describe('JewelryFilterComponent', () => {
  let component: JewelryFilterComponent;
  let fixture: ComponentFixture<JewelryFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
