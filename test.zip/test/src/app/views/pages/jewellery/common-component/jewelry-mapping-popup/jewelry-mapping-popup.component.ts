import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
@Component({
  selector: 'kt-jewelry-mapping-popup',
  templateUrl: './jewelry-mapping-popup.component.html',
  styleUrls: ['./jewelry-mapping-popup.component.scss']
})
export class JewelryMappingPopupComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<JewelryMappingPopupComponent>) { }

  ngOnInit() {
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
