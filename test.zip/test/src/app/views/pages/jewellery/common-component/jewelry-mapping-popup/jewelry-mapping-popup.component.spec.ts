import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryMappingPopupComponent } from './jewelry-mapping-popup.component';

describe('JewelryMappingPopupComponent', () => {
  let component: JewelryMappingPopupComponent;
  let fixture: ComponentFixture<JewelryMappingPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryMappingPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryMappingPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
