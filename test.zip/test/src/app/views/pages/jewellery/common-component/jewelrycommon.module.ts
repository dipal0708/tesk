import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule, MatDividerModule, MatRadioModule, MatSliderModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";
import { CommonModule } from '@angular/common';
import { Ng5SliderModule } from 'ng5-slider';
import { JewelryFilterComponent } from './jewelry-filter/jewelry-filter.component';
import { JewelryMappingPopupComponent } from './jewelry-mapping-popup/jewelry-mapping-popup.component';


const PopupCommonRoutes: Routes = [
//   {
//     path: '',
//     component: DiamondSearchComponent

//   }, {
//     path: 'createuser',
//     component: CreateUserComponent
//   }, {
//     path: 'diamondImport',
//     component: DiamondFileUploadComponent
//   },{
//     path: 'diamondMapping',
//     component: DiamondMappingComponent
//   }
];
@NgModule({
  declarations: [JewelryFilterComponent, JewelryMappingPopupComponent],
  imports: [MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
    CommonModule,MatDividerModule,
		Ng5SliderModule,
		MatRadioModule,
		MatSliderModule,
  ],
  exports:[JewelryFilterComponent,JewelryMappingPopupComponent],
  entryComponents:[JewelryFilterComponent,JewelryMappingPopupComponent]
})
export class jewelryCommonModule { }
 