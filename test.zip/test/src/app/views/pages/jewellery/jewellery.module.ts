import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { JewelleryProductModule } from './products/jewelryproduct.module';
//'import {jewelryCommonModule} from './common-component/jewelrycommon.module'
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule,MatButtonToggleModule } from "@angular/material";



import { DragDropModule } from '@angular/cdk/drag-drop';
import { FileUploadModule } from 'ng2-file-upload';

import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
// import { DiscountListComponent } from './GroupDiscount/discount-list/discount-list.component';
// import { JewelryRetailerAndPermissionComponent } from './vendors/jewelry-retailer-and-permission/jewelry-retailer-and-permission.component';
// import { PurchaseOrderHistoryComponent } from './PurchaseOrder/purchase-order-history/purchase-order-history.component';
// import { UploadMarketingMaterialComponent } from './Marketing/upload-marketing-material/upload-marketing-material.component';
// import { JewelryChartReportComponent } from './JewelryReport/jewelry-chart-report/jewelry-chart-report.component';

const diamondRoutes: Routes = [
//   {
//     path: 'viewmyproduct',
//     component: ViewMyProductComponent
//   }
];
@NgModule({
  declarations: [],
  imports: [DragDropModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
    CommonModule,InfiniteScrollModule,MatButtonToggleModule,
    RouterModule.forChild(diamondRoutes),
    FileUploadModule,TranslateModule.forRoot(),
  ],
})
export class JewelleryModule { }

