import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddToWishlistReportComponent } from './add-to-wishlist-report.component';

describe('AddToWishlistReportComponent', () => {
  let component: AddToWishlistReportComponent;
  let fixture: ComponentFixture<AddToWishlistReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddToWishlistReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddToWishlistReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
