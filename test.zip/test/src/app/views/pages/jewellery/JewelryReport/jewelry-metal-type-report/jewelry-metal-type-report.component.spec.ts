import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryMetalTypeReportComponent } from './jewelry-metal-type-report.component';

describe('JewelryMetalTypeReportComponent', () => {
  let component: JewelryMetalTypeReportComponent;
  let fixture: ComponentFixture<JewelryMetalTypeReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryMetalTypeReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryMetalTypeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
