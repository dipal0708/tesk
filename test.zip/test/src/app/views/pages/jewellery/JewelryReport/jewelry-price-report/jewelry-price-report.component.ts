import { Component, OnInit,ViewChild,NgZone } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_animated);

@Component({
  selector: 'kt-jewelry-price-report',
  templateUrl: './jewelry-price-report.component.html',
  styleUrls: ['./jewelry-price-report.component.scss']
})
export class JewelryPriceReportComponent implements OnInit {

  displayedColumns: string[] = ['useripaddress','date','productname','metal','stylenumber','retailprice','cost'];

  dataSource : any = [
  {useripaddress:"10.0.0.170",date:"10/10/2019", productname:"Product 1",metal:"14 K Gold",stylenumber:"EGL",retailprice:"1000",cost:"500"},
  {useripaddress:"10.0.0.171",date:"10/10/2019", productname:"Product 2",metal:"14 K Gold",stylenumber:"EGL",retailprice:"2000",cost:"1000"},
  {useripaddress:"10.0.0.172",date:"10/10/2019", productname:"Product 3",metal:"14 K Gold",stylenumber:"EGL",retailprice:"3000",cost:"1500"},
  {useripaddress:"10.0.0.173",date:"10/10/2019", productname:"Product 4",metal:"14 K Gold",stylenumber:"EGL",retailprice:"4000",cost:"2000"},
  {useripaddress:"10.0.0.174",date:"10/10/2019", productname:"Product 5",metal:"14 K Gold",stylenumber:"EGL",retailprice:"5000",cost:"2500"}];


  constructor() { }

  ngOnInit() {
    this.pieChartLoad();
  }


  pieChartLoad(){
    let chart = am4core.create("pie-chartdiv", am4charts.PieChart);
    chart.exporting.menu = new am4core.ExportMenu();
    chart.data = [ {
    "country": "Lithuania",
    "litres": 501.9
    }, {
    "country": "Czechia",
    "litres": 301.9
    }, {
    "country": "Ireland",
    "litres": 201.1
    }, {
    "country": "Germany",
    "litres": 165.8
    }, {
    "country": "Australia",
    "litres": 139.9
    }, {
    "country": "Austria",
    "litres": 128.3
    }, {
    "country": "UK",
    "litres": 99
    }, {
    "country": "Belgium",
    "litres": 60
    }, {
    "country": "Netherlands",
    "litres": 50
    } ];
    
    // Add and configure Series
    let pieSeries = chart.series.push(new am4charts.PieSeries());
    pieSeries.dataFields.value = "litres";
    pieSeries.dataFields.category = "country";
    pieSeries.slices.template.stroke = am4core.color("#fff");
    pieSeries.slices.template.strokeWidth = 2;
    pieSeries.slices.template.strokeOpacity = 1;
    
    // This creates initial animation
    pieSeries.hiddenState.properties.opacity = 1;
    pieSeries.hiddenState.properties.endAngle = -90;
    pieSeries.hiddenState.properties.startAngle = -90;
    }

}
