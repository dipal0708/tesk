import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryRetailerClickReportComponent } from './jewelry-retailer-click-report.component';

describe('JewelryRetailerClickReportComponent', () => {
  let component: JewelryRetailerClickReportComponent;
  let fixture: ComponentFixture<JewelryRetailerClickReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryRetailerClickReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryRetailerClickReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
