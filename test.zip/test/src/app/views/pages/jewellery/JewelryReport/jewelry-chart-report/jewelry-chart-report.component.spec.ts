import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryChartReportComponent } from './jewelry-chart-report.component';

describe('JewelryChartReportComponent', () => {
  let component: JewelryChartReportComponent;
  let fixture: ComponentFixture<JewelryChartReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryChartReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryChartReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
