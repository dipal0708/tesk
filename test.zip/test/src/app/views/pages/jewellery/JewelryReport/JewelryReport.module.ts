import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule,MatDatepickerModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { DragDropModule } from '@angular/cdk/drag-drop';
 import { FileUploadModule } from 'ng2-file-upload';
import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { JewelryChartReportComponent } from './jewelry-chart-report/jewelry-chart-report.component';
import { JewelryCategoryReportComponent } from './jewelry-category-report/jewelry-category-report.component';
import { JewelryMetalTypeReportComponent } from './jewelry-metal-type-report/jewelry-metal-type-report.component';
import { JewelryPriceReportComponent } from './jewelry-price-report/jewelry-price-report.component';
import { JewelryRetailerClickReportComponent } from './jewelry-retailer-click-report/jewelry-retailer-click-report.component';
import { AddToWishlistReportComponent } from './add-to-wishlist-report/add-to-wishlist-report.component';



const diamondRoutes: Routes = [
  {
    path: 'JewelryChartReport',
    component: JewelryChartReportComponent
  },
  {
    path: 'JewelryCategoryReport',
    component: JewelryCategoryReportComponent
  },
  {
    path: 'JewelryMetalTypeReport',
    component: JewelryMetalTypeReportComponent
  },
  {
    path: 'JewelryPriceReport',
    component: JewelryPriceReportComponent
  },
  {
    path: 'JewelryRetailerClickReport',
    component: JewelryRetailerClickReportComponent
  },
  {
    path: 'AddToWishReport',
    component: AddToWishlistReportComponent
  }
  

  
  
];
@NgModule({
  declarations: [JewelryChartReportComponent, JewelryCategoryReportComponent, JewelryMetalTypeReportComponent, JewelryPriceReportComponent, JewelryRetailerClickReportComponent, AddToWishlistReportComponent],
  imports: [DragDropModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,MatDatepickerModule,
    MatSlideToggleModule,CommonModule,InfiniteScrollModule,
    RouterModule.forChild(diamondRoutes),
    FileUploadModule,TranslateModule.forRoot(),
  ],

})
export class JewelryReportModule { }
