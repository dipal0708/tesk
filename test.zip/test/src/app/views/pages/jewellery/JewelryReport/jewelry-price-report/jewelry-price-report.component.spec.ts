import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryPriceReportComponent } from './jewelry-price-report.component';

describe('JewelryPriceReportComponent', () => {
  let component: JewelryPriceReportComponent;
  let fixture: ComponentFixture<JewelryPriceReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryPriceReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryPriceReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
