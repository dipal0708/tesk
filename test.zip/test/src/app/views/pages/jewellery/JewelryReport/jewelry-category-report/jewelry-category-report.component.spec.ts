import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryCategoryReportComponent } from './jewelry-category-report.component';

describe('JewelryCategoryReportComponent', () => {
  let component: JewelryCategoryReportComponent;
  let fixture: ComponentFixture<JewelryCategoryReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryCategoryReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryCategoryReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
