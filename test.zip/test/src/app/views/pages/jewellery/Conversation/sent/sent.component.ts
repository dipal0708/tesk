import { Component, OnInit,ViewChild } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import { ToastrService } from 'ngx-toastr';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import { ConfirmPopupboxComponent } from '../../../diamond/common-component/confirm-popupbox/confirm-popupbox.component';


@Component({
  selector: 'kt-sent',
  templateUrl: './sent.component.html',
  styleUrls: ['./sent.component.scss']
})
export class SentComponent implements OnInit {

  displayedColumns: string[] = ['date','time','type','from','to','message','action'];

  dataSource : any = [
 {date:"08/22/2019", time:"1:00 PM",type:"Inquiry",from:"Alex",to:"Gemfind",message:"This is for demo"},
 {date:"08/23/2019", time:"2:00 PM",type:"Request",from:"Alex",to:"Gemfind",message:"This is for demo"},
 {date:"08/24/2019", time:"3:00 PM",type:"Inquiry",from:"Alex",to:"Gemfind",message:"This is for demo"},
 {date:"08/25/2019", time:"4:00 PM",type:"Request",from:"Alex",to:"Gemfind",message:"This is for demo"}];


  constructor() { }

  ngOnInit() {
  }

}
