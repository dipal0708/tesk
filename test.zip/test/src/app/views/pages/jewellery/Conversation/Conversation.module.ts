import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { DragDropModule } from '@angular/cdk/drag-drop';
 import { FileUploadModule } from 'ng2-file-upload';
import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { AllConversationComponent } from './all-conversation/all-conversation.component';
import { MessageDetailComponent } from './message-detail/message-detail.component';
import { UnReadedMessageComponent } from './un-readed-message/un-readed-message.component';
import { SentComponent } from './sent/sent.component';




const diamondRoutes: Routes = [
  {
    path: 'allconversation',
    component: AllConversationComponent
  },
  {
    path: 'messagedetail',
    component: MessageDetailComponent
  },
  {
    path: 'unreadedmessage',
    component: UnReadedMessageComponent
  },
  {
    path: 'sent',
    component: SentComponent
  }
  

  
  
];
@NgModule({
  declarations: [AllConversationComponent, MessageDetailComponent, UnReadedMessageComponent, SentComponent],
  imports: [DragDropModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
    MatSlideToggleModule,CommonModule,InfiniteScrollModule,
    RouterModule.forChild(diamondRoutes),
    FileUploadModule,TranslateModule.forRoot(),
  ],

})
export class JewelryConversationModule { }
