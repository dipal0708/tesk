import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-message-detail',
  templateUrl: './message-detail.component.html',
  styleUrls: ['./message-detail.component.scss']
})
export class MessageDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
