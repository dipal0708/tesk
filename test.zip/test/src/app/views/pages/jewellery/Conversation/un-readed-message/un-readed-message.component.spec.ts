import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnReadedMessageComponent } from './un-readed-message.component';

describe('UnReadedMessageComponent', () => {
  let component: UnReadedMessageComponent;
  let fixture: ComponentFixture<UnReadedMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnReadedMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnReadedMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
