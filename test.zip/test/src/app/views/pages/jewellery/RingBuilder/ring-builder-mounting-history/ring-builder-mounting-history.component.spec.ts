import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RingBuilderMountingHistoryComponent } from './ring-builder-mounting-history.component';

describe('RingBuilderMountingHistoryComponent', () => {
  let component: RingBuilderMountingHistoryComponent;
  let fixture: ComponentFixture<RingBuilderMountingHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RingBuilderMountingHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RingBuilderMountingHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
