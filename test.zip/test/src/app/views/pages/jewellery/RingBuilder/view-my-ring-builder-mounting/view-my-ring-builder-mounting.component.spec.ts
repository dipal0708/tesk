import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMyRingBuilderMountingComponent } from './view-my-ring-builder-mounting.component';

describe('ViewMyRingBuilderMountingComponent', () => {
  let component: ViewMyRingBuilderMountingComponent;
  let fixture: ComponentFixture<ViewMyRingBuilderMountingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMyRingBuilderMountingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMyRingBuilderMountingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
