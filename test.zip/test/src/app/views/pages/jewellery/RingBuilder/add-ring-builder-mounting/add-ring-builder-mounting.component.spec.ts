import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRingBuilderMountingComponent } from './add-ring-builder-mounting.component';

describe('AddRingBuilderMountingComponent', () => {
  let component: AddRingBuilderMountingComponent;
  let fixture: ComponentFixture<AddRingBuilderMountingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddRingBuilderMountingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddRingBuilderMountingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
