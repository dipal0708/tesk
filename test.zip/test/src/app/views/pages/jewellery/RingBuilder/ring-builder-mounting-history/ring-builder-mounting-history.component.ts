import { Component, OnInit,ViewChild } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'kt-ring-builder-mounting-history',
  templateUrl: './ring-builder-mounting-history.component.html',
  styleUrls: ['./ring-builder-mounting-history.component.scss']
})
export class RingBuilderMountingHistoryComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: MatTableDataSource<any>;
  fileUrl;
  viewLoader:boolean=false;
  displayedColumns: string[] = ['updated_date','updated_time','file_name','file_type','status','numrecords','report'];

  constructor(private service:UserService,private sanitizer:DomSanitizer) { 
    this.dataSource = new MatTableDataSource<any>([]);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngOnInit() {
    this.getAllHistory();
  }

  getAllHistory(){
    this.viewLoader = true;
    this.service.getDiamondUploadHistory().subscribe((data:any)=>{
      data.data.sort((a, b) => new Date(b.updated_date).getTime() - new Date(a.updated_date).getTime());
      //this.allcompaniesList = data.data;
      this.dataSource.data = data.data;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.viewLoader = false;
      //const rows = [];
       ///this.dataSource.forEach(element => rows.push( { detailRow: true, element }));
      //  this.allcompaniesList = this.allcompaniesList.filter(x => x.created_by == this.userDetail.pk_id);
      
      });
  }

  sanitize(url:string){     
    var lnk = url.split('uploads');
    var urllink = 'http://34.205.171.23:3000/uploads'+lnk[1]; 
    return this.sanitizer.bypassSecurityTrustUrl(urllink);
  }

  diamondReport(obj) {  
    
    // var lnk1 = url.split('\\').reverse()[0];  //.split('uploads');
     //var urllink1 = 'http://localhost:3000/FinalOutputFiles/error_'+obj.file_name; 
     var urllink1 = 'http://34.205.171.23:3000/FinalOutputFiles/error_'+obj.file_name; 
     return this.sanitizer.bypassSecurityTrustUrl(urllink1);


    // this.service.getFileUploadHistoryData(obj).subscribe((data:any)=>{        
    //     //window.location.href='http://34.205.171.23:3000/FinalOutputFiles/error_'+obj.file_name;
    //     window.location.href='http://localhost:3000/FinalOutputFiles/error_'+obj.file_name;
    // });

  ///  return this.sanitizer.bypassSecurityTrustUrl(urllink1);

    // var lnk = url.split('uploads');
    // var urllink = 'http://34.205.171.23:3000/FinalOutputFiles/error_RAPNET_57.csv';///+lnk[0]; 
    // ///return this.sanitizer.bypassSecurityTrustUrl(urllink);
    // // const data =":: Diamond Upload Report :: :File Name: " +  obj.file_name + " :Time Stamp: "+obj.created_time+ " :Records: "+ obj.numrecords; 
    // // const blob = new Blob([data], { type: 'application/octet-stream' });

    //  return this.sanitizer.bypassSecurityTrustUrl(urllink); ///this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
  }
  onClickRefresh(){
    this.getAllHistory();
  }
}
