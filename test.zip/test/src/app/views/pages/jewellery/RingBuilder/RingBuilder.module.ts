import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule,MatDividerModule,MatRadioModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule,MatSlideToggleModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";



import { DragDropModule } from '@angular/cdk/drag-drop';
import { FileUploadModule } from 'ng2-file-upload';

import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ViewMyRingBuilderMountingComponent } from './view-my-ring-builder-mounting/view-my-ring-builder-mounting.component';
import { RingBuilderMountingHistoryComponent } from './ring-builder-mounting-history/ring-builder-mounting-history.component';
import { UploadRingBuilderMountingFileComponent } from './upload-ring-builder-mounting-file/upload-ring-builder-mounting-file.component';
import { ManageFTPForRIngBuilderComponent } from './manage-ftpfor-ring-builder/manage-ftpfor-ring-builder.component';
import { AddRingBuilderMountingComponent } from './add-ring-builder-mounting/add-ring-builder-mounting.component';



const diamondRoutes: Routes = [
  {
    path: 'viewmyringbuilder',
    component: ViewMyRingBuilderMountingComponent

  },
  {
    path: 'ringbuildermountinghistory',
    component:RingBuilderMountingHistoryComponent
  },
  {
    path: 'uploadringbuildermountingfile',
    component:UploadRingBuilderMountingFileComponent
  },
  {
    path: 'manageftpforringbuilder',
    component:ManageFTPForRIngBuilderComponent
  },
  {
    path: 'addringbuildermounting',
    component:AddRingBuilderMountingComponent
  }
];
@NgModule({
  declarations: [ViewMyRingBuilderMountingComponent, RingBuilderMountingHistoryComponent, UploadRingBuilderMountingFileComponent, ManageFTPForRIngBuilderComponent, AddRingBuilderMountingComponent],
  imports: [DragDropModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
    CommonModule,InfiniteScrollModule,MatRadioModule,MatDividerModule,MatSlideToggleModule,
    RouterModule.forChild(diamondRoutes),
    FileUploadModule,TranslateModule.forRoot(),
  ],
  exports:[],
  entryComponents:[]
})
export class JewelleryRingBuilderModule { }
