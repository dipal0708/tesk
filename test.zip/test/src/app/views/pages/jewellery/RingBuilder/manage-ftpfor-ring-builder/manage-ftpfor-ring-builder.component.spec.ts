import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageFTPForRIngBuilderComponent } from './manage-ftpfor-ring-builder.component';

describe('ManageFTPForRIngBuilderComponent', () => {
  let component: ManageFTPForRIngBuilderComponent;
  let fixture: ComponentFixture<ManageFTPForRIngBuilderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageFTPForRIngBuilderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageFTPForRIngBuilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
