import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadRingBuilderMountingFileComponent } from './upload-ring-builder-mounting-file.component';

describe('UploadRingBuilderMountingFileComponent', () => {
  let component: UploadRingBuilderMountingFileComponent;
  let fixture: ComponentFixture<UploadRingBuilderMountingFileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadRingBuilderMountingFileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadRingBuilderMountingFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
