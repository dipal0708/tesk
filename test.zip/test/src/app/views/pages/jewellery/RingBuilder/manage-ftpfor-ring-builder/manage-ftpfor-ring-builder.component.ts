import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-manage-ftpfor-ring-builder',
  templateUrl: './manage-ftpfor-ring-builder.component.html',
  styleUrls: ['./manage-ftpfor-ring-builder.component.scss']
})
export class ManageFTPForRIngBuilderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
