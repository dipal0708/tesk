import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '../../../../../../environments/environment';
import { FileUploader } from 'ng2-file-upload';
import { Uploader } from '@syncfusion/ej2-inputs';
import { UserService } from '../../../../../core/services/users.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ExcelService } from '../../../../excel.service';



@Component({
  selector: 'kt-add-ring-builder-mounting',
  templateUrl: './add-ring-builder-mounting.component.html',
  styleUrls: ['./add-ring-builder-mounting.component.scss']
})
export class AddRingBuilderMountingComponent implements OnInit {
  public uploader: FileUploader = new FileUploader({ url: environment.api_url + 'api/diamondupload' }); //  withCredentials: true
	userDetail: any = [];
	uploadedFilename: any;
	uploadedFiles: Array<File>;
	profilePic: string;
	imagepath: any;
	imageFolder: any = environment.api_url + '/uploads/';
	selectedType: any;
	private target: any;
	selectedFileName:string = "Choose file";
	selectedFileName1:string = "Choose file";
	companies:any=[];
	company:any=[{name:'RAPNET'},{name:'INDEX ONLINE'},{name:'POLYGON'}];
  ringbuilderaddform: FormGroup;
  jewelrymetaltype:any=[];
  jewelrymetalcolor:any=[];
  // --------------------Bind Data----------------
 

  //-----Upload and dislay
  public imagePath;
  imgURL: any;
  public message: string;
  show:boolean=false;
  step1 = true;
  step2 = false;
  step3 = false;
  //--------------bind data arrray end
  
 
  // private unsubscribe: Subject<any>;
 

  constructor(private toastr: ToastrService,private fb: FormBuilder,private service:UserService,
		private http: HttpClient, private translate: TranslateService) { }

  ngOnInit() {

    this.initAddForm();
    this.allMetalTypeddl();
    this.allMetalColorddl();
    this.userDetail = JSON.parse(localStorage.getItem('userDetail2'));
			this.selectedType='Replace all';
			this.companies = JSON.parse(localStorage.getItem('userCompany'));
			this.uploader.onBeforeUploadItem = (file) => {
				debugger
				file.withCredentials = false;
			};
			debugger
			this.uploader.onBuildItemForm = (file: any, form: any) => {
				debugger
				
				if(file.file.name)
				{
					debugger
					form.append('dealer_id', this.companies[0].dealerid); //note comma separating key and value			
					form.append('upload_type', this.selectedType);
					form.append('file_name',file.file.name)
				}else{
					this.toastr.error("Select file and upload type. Please try again.");	
					return; 
				}	
			};
  }



  allMetalTypeddl(){
    
    var object={
      dealerid:this.companies[0].dealerid,
    }

    this.service.allJewelleryMetalType(object).subscribe((data:any)=>{
      debugger;
      this.jewelrymetaltype = data.data;
      // for(var i = 0; i <= data.data.length; i++) {

      //   this.alllistofmetaltype.push(data.data[i].metaltype);

      // }
     
    });
  }

  allMetalColorddl(){
    var objct={
      dealerid:this.companies[0].dealerid,
    }

    this.service.allJewelleryMetalColor(objct).subscribe((data:any)=>{
      debugger;
      
      this.jewelrymetalcolor=data.data;
      // for(var j = 0; j <= data.data.length; j++) {

      //   this.alllistofmetalcolor.push(data.data[j].metalcolor);

      // }
      
     
    });
    
  }

  initAddForm(){

    this.ringbuilderaddform=this.fb.group({
      productname:[''],
      retaildescription:[''],
      gender:[''],
      status:[''],
      collection:[''],
      retailprice:[''],
      stylenumber:[''],
      dealerstock:[''],
      additionalinfo:[''],
      parentsku:[''],
      metaltype:[''],
      qty:[''],
      metalcolor:[''],
      displayorder:[''],
      wholesaledesc:[''],
      weight:[''],
      thickness:[''],
      width:[''],
      dimention:[''],
      unitofmeasure:[''],
      stockfingersize:[''],
      maxfingersize:[''],
      minfingersize:[''],
      fingersizeincrement:[''],
      pricetype:[''],
      wholesaleprice:[''],
      addvideo:[''],
      discountleveltype1:[''],
      discountlevelvalue1:[''],
      discountleveltype2:[''],
      discountlevelvalue2:[''],
      brandname:[''],
      retailpricemethod:[''],
      msrp:[''],
      selectattribute:[''],
      selectattributelabel:[''],
      selectattributevalue:[''],
      qty1:[''],
      qty2:[''],
      qty3:[''],
      qty4:[''],
      qty5:[''],
      totaldiamondweight:[''],
      totalgemstoneweight:[''],
      progmetal:[''],
      hassidestone:[''],
      gemstonetype:[''],
      dimentionunitofmeasure:[''],
      noofgemstone:[''],
      stonecreationmethod:[''],
      gemstoneshape:[''],
      gemstoneorigin:[''],
      gemstonecarateweight:[''],
      bottominformation:[''],
      gemstonedimention:[''],
      gemstonequality:['']
    });

  }


  submit(){
    debugger;
    this.ringbuilderaddform.value;

    var obj={
      dealerid:this.companies[0].dealerid,
      stylenumber:this.ringbuilderaddform.value.stylenumber,
      DealerStockNumber:this.ringbuilderaddform.value.dealerstock,
      ProductName:this.ringbuilderaddform.value.productname,
      ShortDescription:this.ringbuilderaddform.value.retaildescription,
      productdescription:this.ringbuilderaddform.value.wholesaledesc,
      quantity:this.ringbuilderaddform.value.qty,
      DisplayOrder:this.ringbuilderaddform.value.displayorder,
      StatusID:this.ringbuilderaddform.value.status,
      MetalTypeID:1,
      MetalColorID:1,
      Terms:"",
      IsStockBalancing:1,
      RetailPriceCodeID:this.ringbuilderaddform.value.retailpricemethod,
      IsCalculatedRetailPrice:120,
      backfinding:"",
      retailprice:this.ringbuilderaddform.value.retailprice,
      msrp:this.ringbuilderaddform.value.msrp,
      MSRP2:0.2,
      MSRPTypeID:1,
      IsCalculatedMSRP:1,
      HasSideStones:this.ringbuilderaddform.value.hassidestone,
      ProgMetal:this.ringbuilderaddform.value.progmetal,
      GemstoneType:this.ringbuilderaddform.value.gemstonetype,
      NoOfGemstone:this.ringbuilderaddform.value.noofgemstone,
      GemstoneShape:this.ringbuilderaddform.value.gemstoneshape,
      GemstoneCaratWeight:this.ringbuilderaddform.value.gemstonecarateweight,
      GemstoneQuality:this.ringbuilderaddform.value.gemstonequality,
      GemstoneCarat:0.8,
      GemstoneColor:"",
      AllowableShapeName:"",
      AllowableMinSize:"",
      AllowableMaxSize:"",
      CustomField1Name:"",
      CustomField1:"",
      CustomField2Name:"",
      CustomField2:"",
      CustomField3Name:"",
      CustomField3:"",
      CustomField4Name:"",
      CustomField4:"",
      CustomField5Name:"",
      CustomField5:"",
      DesigenrID:5,
      CategoryID:5,
      SubCategoryID:5,
      CollectionID:this.ringbuilderaddform.value.collection,
      GenderID:this.ringbuilderaddform.value.gender,
      PriceType:this.ringbuilderaddform.value.pricetype,
      DiscountLevelType1:this.ringbuilderaddform.value.discountleveltype1,
      DiscountLevelValue1:this.ringbuilderaddform.value.discountlevelvalue1,
      DiscountLevelType2:this.ringbuilderaddform.value.discountleveltype2,
      DiscountLevelValue2:this.ringbuilderaddform.value.discountlevelvalue2,
      RetailerDiscountType:"",
      RetailerDiscountValue:"",
      SelectedAttributes:this.ringbuilderaddform.value.selectattribute,
      CustomeAttributelabel:this.ringbuilderaddform.value.selectattributelabel,
      SecondaryMetalType:"",
      ProductType:1,
      ParentSKU:this.ringbuilderaddform.value.parentsku,
      IsRingBuilder:1,
      PrimaryDiamondShape:"",
      NumberOfPrimaryDiamond:1,
      PrimaryDiamondTotalWeight:0.5,
      PrimaryDiamondClarity:"",
      PrimaryDiamondColor:"",
      PrimaryDiamondSecondaryColor:"",
      PrimaryDiamondSaturation:"",
      PrimaryDiamondCertificateType:"",
      PrimaryDiamondCertificateNo:"",
      SecondaryDiamondShape:"",
      NumberOfSecondaryDiamonds:2,
      SecondaryDiamondTotalWeight:0.5,
      SecondaryDiamondClarity:"",
      SecondaryDiamondColor:"",
      SecondaryDiamondSecondaryColor:"",
      SecondaryDiamondSaturation:"",
      OtherDiamondInfo:"",
      OtherDiamondTotalWeight:0.2,
      TotalDiamondWeight:this.ringbuilderaddform.value.totaldiamondweight,
      PrimaryGemstoneType:"",
      PrimaryGemstoneShape:"",
      NumberOfPrimaryGemstones:2,
      PrimaryGemstoneCaratWeight:5.5,
      PrimaryGemstoneDimensions:this.ringbuilderaddform.value.gemstonedimention,
      PrimaryGemstoneOrigin:this.ringbuilderaddform.value.gemstoneorigin,
      PrimaryGemstoneQuality:"",
      SecondaryGemstoneType:"",
      SecondaryGemstoneShape:"",
      NumberOfSecondaryGemstones:5,
      SecondaryGemstoneCaratWeight:0.2,
      SecondaryGemstoneDimensions:"",
      SecondaryGemstoneOrigin:"",
      SecondaryGemstoneQuality:"",
      OtherGemstoneInfo:"",
      OtherGemstoneCaratWeight:0.1,
      OtherGemstoneQuality:"",
      TotalGemstoneWeight:this.ringbuilderaddform.value.totalgemstoneweight,
      FingerSize:this.ringbuilderaddform.value.stockfingersize,
      FingerSizeMinRange:this.ringbuilderaddform.value.minfingersize,
      FingerSizeMaxRange:this.ringbuilderaddform.value.maxfingersize,
      FingerSizeIncrement:this.ringbuilderaddform.value.fingersizeincrement,
      AllowableCenterStoneShape:"",
      AllowableCenterStoneSize:"",
      FlgISBlocked:1,
      ImagePath:"",
      ChainType:"",
      HasImage:2,
      AdditionalInformation:this.ringbuilderaddform.value.additionalinfo,
      AdditionalInformation2:this.ringbuilderaddform.value.bottominformation,
      videourl:this.ringbuilderaddform.value.addvideo,
      // additionalinformation:"",
      groupedproductskus:"",
      dimensions:this.ringbuilderaddform.value.dimention,
      width:this.ringbuilderaddform.value.width,
      Length_in:0.5,
      weight:this.ringbuilderaddform.value.weight,
      thickness_mm:this.ringbuilderaddform.value.thickness,
      dimensionunitofmeasure:this.ringbuilderaddform.value.dimentionunitofmeasure,
      qty1:this.ringbuilderaddform.value.qty1,
      qty2:this.ringbuilderaddform.value.qty2,
      qty3:this.ringbuilderaddform.value.qty3,
      qty4:this.ringbuilderaddform.value.qty4,
      qty5:this.ringbuilderaddform.value.qty5,
      brandname:this.ringbuilderaddform.value.brandname,
      wholesaleprice:this.ringbuilderaddform.value.wholesaleprice


    };

    this.service.addRingBuilder(obj).subscribe((data:any)=>{
      debugger
      
      //allJewelryProduct
       this.allRingBuilder();

    });

  }


  allRingBuilder(){
debugger;
    var obj1={
      dealerid:this.companies[0].dealerid,
    }

   
    this.service.allJewelryProduct(obj1).subscribe((data:any)=>{
      debugger
      
      //

    });
  }

  preview(files) {
    debugger;
    if (files.length === 0)
      return;
 
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }
    else{
      this.message = "";
    }
 
    var reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
      this.imgURL = reader.result; 
    }
  }

  hidshow(value){
    if(value == 'show'){
      this.show = true;
    }
    if(value == 'hide'){
      this.show = false;
    }
    
  }

  public onChange(event: any): void {
    debugger
    
    if(this.uploader.queue.length == 2){
      debugger
      this.uploader.queue[0] = this.uploader.queue[1];
      this.uploader.queue.splice(1, 1);
    }
    this.uploader.onSuccessItem = (item: any, response: string, status: number) => {
      debugger
      let data = JSON.parse(response); //success server response
      if (data.error_code == 1)
        this.toastr.success("There is some issue in upload. Please try again.");
      else {
        this.toastr.success("File uploaded successfully.");
        debugger
        event.target.value.split("\\" ).pop();
        //this.uploader.queue = [];
      }
    }
    this.uploader.onErrorItem = (item: any, response: string, status: number) => {

      //let data = JSON.parse(response); //success server response
      this.toastr.error("There is some issue in upload. Please try again.");
    }
    this.target = event.target || event.srcElement;
    this.selectedFileName = event.target.files[0].name
    event.srcElement.value = "";
  }
  DiamondInfoDownload(value){
    if(value == 'diamond'){

      let link = document.createElement("a");
      link.download = "Diamond Guidline";
      link.href = "assets/media/users/ImageGuideline.pdf";
      link.click();

      // window.open('/assets/media/users/ImageGuideline.pdf', '_blank');
    }
    if(value == 'diamondExcelDemo'){

      let link = document.createElement("a");
      link.download = "JC Diamond Data Form";
      link.href = "assets/media/files/JCDiamondDataForm.xlsx";
      link.click();

      // window.open('/assets/media/users/ImageGuideline.pdf', '_blank');
    }else{
      
    }
  }
  public onChange1(event: any): void {
    debugger
    
    if(this.uploader.queue.length == 2){
      debugger
      this.uploader.queue[0] = this.uploader.queue[1];
      this.uploader.queue.splice(1, 1);
    }
    this.uploader.onSuccessItem = (item: any, response: string, status: number) => {
      debugger
      let data = JSON.parse(response); //success server response
      if (data.error_code == 1)
        this.toastr.success("There is some issue in upload. Please try again.");
      else {
        this.toastr.success("File uploaded successfully.");
        debugger
        event.target.value.split("\\" ).pop();
        //this.uploader.queue = [];
      }
    }
    this.uploader.onErrorItem = (item: any, response: string, status: number) => {

      //let data = JSON.parse(response); //success server response
      this.toastr.error("There is some issue in upload. Please try again.");
    }
    this.target = event.target || event.srcElement;
    this.selectedFileName = event.target.files[0].name
    event.srcElement.value = "";
  }


}
