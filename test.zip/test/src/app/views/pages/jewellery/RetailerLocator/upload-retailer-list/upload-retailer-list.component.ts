import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { UserService } from '../../../../../core/services/users.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'kt-upload-retailer-list',
  templateUrl: './upload-retailer-list.component.html',
  styleUrls: ['./upload-retailer-list.component.scss']
})
export class UploadRetailerListComponent implements OnInit {
  
  arrayBuffer:any;
  file:File;
  forlocal:any;
  companies:any;
  DataForUploadRetailerList: any;

  constructor(private toastr: ToastrService,private service:UserService) { }

  ngOnInit() {
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
  }

  incomingfile(event) 
  {
    debugger;
  this.file= event.target.files[0]; 
  }
  // fileUpload(files: FileList){
  //   debugger
  //   const file: File = files.item(0);
  //   const reader: FileReader = new FileReader();
  //   reader.readAsText(file);
  //   reader.onload = (e) => {
  //     const res = reader.result as string; // This variable contains your file as text
  //     const lines = res.split('\n'); // Splits you file into lines
  //     const Value = lines[0].split(',');
  //     const ids = [];
  //     for (let i = 0; i <= Value.length - 1; i++) {
  //       ids.push(Value[i]); // Get first item of line
  //     }
     
      

  //     // this.service.DealerUploadedDiamondColumns(obj).subscribe((data: any) => {
       
  //     // });
  //   };
  // }

  Upload() {
    debugger;
    let fileReader = new FileReader();
      fileReader.onload = (e) => {
          this.arrayBuffer = fileReader.result;
          var data = new Uint8Array(this.arrayBuffer);
          var arr = new Array();
          for(var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
          var bstr = arr.join("");
          var workbook = XLSX.read(bstr, {type:"binary"});
          var first_sheet_name = workbook.SheetNames[0];
          var worksheet = workbook.Sheets[first_sheet_name];
          console.log(XLSX.utils.sheet_to_json(worksheet,{raw:true}));
          this.forlocal=XLSX.utils.sheet_to_json(worksheet,{raw:true});
         // localStorage.setItem('DataForUploadRetailerList', JSON.stringify(this.forlocal));
      }
      fileReader.readAsArrayBuffer(this.file);

      var obj ={
        DealerID:this.companies[0].dealerid,
        excelData:this.forlocal
      }
      this.service.uploadRetailerList(obj).subscribe((data:any)=>{
        debugger;
            this.toastr.success('File Uploaded Successfully');
      });
       
}

}
