import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink,Router } from '@angular/router';
import { UserService } from '../../../../../core/services/users.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'kt-edit-retailer',
  templateUrl: './edit-retailer.component.html',
  styleUrls: ['./edit-retailer.component.scss']
})
export class EditRetailerComponent implements OnInit {

  UpdateData:any;
  id:any;
  companies:any;
  updateretailerlocatorform: FormGroup;
  constructor(private fb: FormBuilder,private route:ActivatedRoute,private service:UserService, private router:Router) { }

  ngOnInit() {
debugger;
this.forUpdateData();
this.initRegisterForm();

  }

  initRegisterForm(){
    this.updateretailerlocatorform= this.fb.group({
		
      storename:[''],
      address:[''],
      contactname:[''],
      city:[''],
      zipcode:[''],
      email:[''],
      facebookappid:[''],
      phone:[''],
      state:[''],
      country:[''],
      website:[''],
      facebookappurl:['']
          
  });
    
  }

  forUpdateData(){

    this.id  = this.route.snapshot.queryParamMap.get('value');
    var obj ={
      ID:this.id
    }
    this.service.getAllRetailerListForUpdate(obj).subscribe((data:any)=>{
      debugger;
     
      this.UpdateData=data.data;

      this.updateretailerlocatorform.controls['storename'].setValue( this.UpdateData[0].storename);
      this.updateretailerlocatorform.controls['address'].setValue(this.UpdateData[0].address);
      this.updateretailerlocatorform.controls['contactname'].setValue(this.UpdateData[0].contactname);
      this.updateretailerlocatorform.controls['city'].setValue(this.UpdateData[0].city);
      this.updateretailerlocatorform.controls['zipcode'].setValue(this.UpdateData[0].zipcode);
      this.updateretailerlocatorform.controls['email'].setValue(this.UpdateData[0].email);
      this.updateretailerlocatorform.controls['facebookappid'].setValue(this.UpdateData[0].facebookappid);
      this.updateretailerlocatorform.controls['phone'].setValue(this.UpdateData[0].phone);
      this.updateretailerlocatorform.controls['state'].setValue(this.UpdateData[0].state);
      this.updateretailerlocatorform.controls['country'].setValue(this.UpdateData[0].country);
      this.updateretailerlocatorform.controls['website'].setValue(this.UpdateData[0].website);
      this.updateretailerlocatorform.controls['facebookappurl'].setValue(this.UpdateData[0].facebookappurl);
    });
    
  }


  update(){
    debugger;
    // const id:string = this.route.snapshot.queryParamMap.get('value');
   this.updateretailerlocatorform.value;
   this.companies = JSON.parse(localStorage.getItem('userCompany')); 
    var obj={
      id: this.id,
      DealerID:this.companies[0].dealerid,
      storename:this.updateretailerlocatorform.value.storename,
      address:this.updateretailerlocatorform.value.address,
      contactname:this.updateretailerlocatorform.value.contactname,
      city:this.updateretailerlocatorform.value.city,
      zipcode:this.updateretailerlocatorform.value.zipcode,
      email:this.updateretailerlocatorform.value.email,
      facebookappid:this.updateretailerlocatorform.value.facebookappid,
      phone:this.updateretailerlocatorform.value.phone,
      state:this.updateretailerlocatorform.value.state,
      country:this.updateretailerlocatorform.value.country,
      website:this.updateretailerlocatorform.value.website,
      facebookappurl:this.updateretailerlocatorform.value.facebookappurl

    }


    this.service.updateRetailerList(obj).subscribe((data:any)=>{
      debugger;

      this.router.navigate(['/default/jewelleryretailer/retailerlocatorall']);
    

    });

  }

}
