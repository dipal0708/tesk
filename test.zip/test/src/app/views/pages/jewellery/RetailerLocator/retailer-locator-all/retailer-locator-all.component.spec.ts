import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailerLocatorAllComponent } from './retailer-locator-all.component';

describe('RetailerLocatorAllComponent', () => {
  let component: RetailerLocatorAllComponent;
  let fixture: ComponentFixture<RetailerLocatorAllComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetailerLocatorAllComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetailerLocatorAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
