import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadRetailerListComponent } from './upload-retailer-list.component';

describe('UploadRetailerListComponent', () => {
  let component: UploadRetailerListComponent;
  let fixture: ComponentFixture<UploadRetailerListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadRetailerListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadRetailerListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
