import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatTabsModule, MatFormFieldModule, MatRadioModule,MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { DragDropModule } from '@angular/cdk/drag-drop';
 import { FileUploadModule } from 'ng2-file-upload';
import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { RetailerLocatorAllComponent } from './retailer-locator-all/retailer-locator-all.component';
import { UploadRetailerListComponent } from './upload-retailer-list/upload-retailer-list.component';
import { EditRetailerComponent } from './edit-retailer/edit-retailer.component';



const diamondRoutes: Routes = [
  {
    path: 'retailerlocatorall',
    component: RetailerLocatorAllComponent

  },
  {
    path: 'uploadretailerlist',
    component: UploadRetailerListComponent

  },
  {
    path: 'editretailer',
    component: EditRetailerComponent
  }
  
  

  
  
];
@NgModule({
  declarations: [RetailerLocatorAllComponent, UploadRetailerListComponent, EditRetailerComponent],
  imports: [DragDropModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,MatRadioModule,
    MatSlideToggleModule,CommonModule,InfiniteScrollModule,
    RouterModule.forChild(diamondRoutes),
    FileUploadModule,TranslateModule.forRoot(),
  ],

})
export class RetailerLocatorModule { }
