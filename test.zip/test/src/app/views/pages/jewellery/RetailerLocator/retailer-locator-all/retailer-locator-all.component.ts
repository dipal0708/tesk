import { Component, OnInit,ViewChild } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import {Router} from '@angular/router';

@Component({
  selector: 'kt-retailer-locator-all',
  templateUrl: './retailer-locator-all.component.html',
  styleUrls: ['./retailer-locator-all.component.scss']
})
export class RetailerLocatorAllComponent implements OnInit {

  // managecollectionform: FormGroup;
  dataSource: MatTableDataSource<any>;
  getLocalStorage: any;
  companies:any;
  viewLoader:boolean=false;
  displayedColumns: string[] = ['StoreName','ContactName','Phone','Email','Address','City','Zipcode','State','Country','action'];
//   dataSource =[
 
//  ];
 
  constructor(private service:UserService,private sanitizer:DomSanitizer,private router:Router) { }

  ngOnInit() {
    debugger;
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this. getAllData();
    // this.getLocalStorage = JSON.parse(localStorage.getItem('DataForUploadRetailerList'));
    // this.dataSource=this.getLocalStorage;
  }

 getAllData(){
  var obj ={
    DealerID:this.companies[0].dealerid
  }
  this.service.getAllRetailerList(obj).subscribe((data:any)=>{
    debugger;
    this.dataSource=data.data;
  });
 }

  edit(value){
debugger;

this.router.navigate(['/default/jewelleryretailer/editretailer'], { queryParams: { value: value.id } });
  }


  delete(val){
    debugger;
    var newobj={
      id:val.id,
    }
    this.service.deleteRetailerLocator(newobj).subscribe((data:any)=>{
      debugger;
      this.getAllData();
    });
  }





 
 
}
