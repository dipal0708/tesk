import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule,MatDatepickerModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { DragDropModule } from '@angular/cdk/drag-drop';
 import { FileUploadModule } from 'ng2-file-upload';
import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { UploadMarketingMaterialComponent } from './upload-marketing-material/upload-marketing-material.component';
import { AppointmentComponent } from './appointment/appointment.component';




const diamondRoutes: Routes = [
  {
    path: 'JewelryMarketingModule',
    component: UploadMarketingMaterialComponent

  },
  {
    path: 'Appointment',
    component: AppointmentComponent

  }
 
  

  
  
];
@NgModule({
  declarations: [UploadMarketingMaterialComponent, AppointmentComponent],
  imports: [DragDropModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,MatDatepickerModule,
    MatSlideToggleModule,CommonModule,InfiniteScrollModule,
    RouterModule.forChild(diamondRoutes),
    FileUploadModule,TranslateModule.forRoot(),
  ],

})
export class JewelryMarketingModule { }
