import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-upload-marketing-material',
  templateUrl: './upload-marketing-material.component.html',
  styleUrls: ['./upload-marketing-material.component.scss']
})
export class UploadMarketingMaterialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
