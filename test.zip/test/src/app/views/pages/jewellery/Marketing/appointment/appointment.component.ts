import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.scss']
})
export class AppointmentComponent implements OnInit {

  displayedColumns: string[] = ['time','storename','buyer','location'];

  dataSource : any = [{time:"10/10/2019", storename:"Store 1",buyer:"Name",location:"Vadodara"},
  {time:"10/10/2019", storename:"Store 1",buyer:"Name",location:"Vadodara"},
  {time:"10/10/2019", storename:"Store 1",buyer:"Name",location:"Vadodara"},
  {time:"10/10/2019", storename:"Store 1",buyer:"Name",location:"Vadodara"},
  {time:"10/10/2019", storename:"Store 1",buyer:"Name",location:"Vadodara"}];
 


  constructor() { }

  ngOnInit() {
  }

}
