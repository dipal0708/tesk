import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadMarketingMaterialComponent } from './upload-marketing-material.component';

describe('UploadMarketingMaterialComponent', () => {
  let component: UploadMarketingMaterialComponent;
  let fixture: ComponentFixture<UploadMarketingMaterialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadMarketingMaterialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadMarketingMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
