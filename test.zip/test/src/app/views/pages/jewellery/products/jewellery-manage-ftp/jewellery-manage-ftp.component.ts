import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../../../../core/services/users.service';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'kt-jewellery-manage-ftp',
  templateUrl: './jewellery-manage-ftp.component.html',
  styleUrls: ['./jewellery-manage-ftp.component.scss']
})
export class JewelleryManageFTPComponent implements OnInit {

  userDetail:any=[];
  createuserform: FormGroup;
  userData:any=[];
  showspinner:boolean=false;
  viewDom:number;
  private unsubscribe: Subject<any>;

  constructor(private toastr: ToastrService,private cdr: ChangeDetectorRef,private fb: FormBuilder,public service:UserService) { 
    this.unsubscribe = new Subject();
  }

  ngOnInit() {
    this.initLoginForm();
    this.userDetail = JSON.parse(localStorage.getItem('userDetail2'));
    this.getuploadedData();
  }

  initLoginForm() {
		this.createuserform = this.fb.group({
      username: [''],
			password: [''],
      filepath: ['']
		});
  }
  
  createUserClick(){
    debugger
     this.showspinner= true;
     var useremail = this.userDetail.company_name.replace(/ /g, "");
     var randomstring = Math.random().toString(36).slice(-8);
     var obj = {
       username: useremail,
       pass:randomstring,
       FTP_Path:"xlxs",
       fileType:"2"
     }
     this.service.insertFtp(obj).pipe(
       tap((data:any) => {
         if (data.status==200) { 
           
       this.createuserform.controls['username'].disable();
       this.createuserform.controls['password'].disable();
       this.createuserform.controls['filepath'].disable();
 
         } else {
           this.toastr.error('Somthing Wrong..');
         }
       }),
       takeUntil(this.unsubscribe),
       finalize(() => {
         this.getuploadedData();
       })
     ).subscribe();
 
     // this.service.insertFtp(obj).subscribe((data:any)=>{
     //  debugger
      
     // });
     
   }

   getuploadedData(){
    debugger
     var companyname = this.userDetail.company_name.replace(/ /g, "");
     var useremail = this.userDetail.company_name.replace(/ /g, "") + "@"+"gemfind.com";
     this.service.getuploadeddatabyusername(companyname).pipe(
       tap((data:any) => {
         if (data.status==200) { 
           
           if(data.data.length != 0){
             this.viewDom = 0;
             this.userData = data.data[0];
             this.createuserform.controls['username'].setValue(this.userData.username);
             this.createuserform.controls['password'].setValue(this.userData.password);
             this.createuserform.controls['filepath'].setValue("ftp.gemfind.net\\FTP_USERS\\"+this.userData.ftp_path);
           }
           else{
             this.viewDom = 1;
 
           }
         } else {
           this.toastr.error('Somthing Wrong..');
         }
       }),
       takeUntil(this.unsubscribe),
       finalize(() => {
         this.showspinner = false;
         this.cdr.detectChanges();
       })
     ).subscribe();
 
     // this.service.getuploadeddatabyusername(companyname).subscribe((data:any)=>{
     //  debugger
     //  if(data.data.length != 0){
     //   this.viewDom = 0;
     //   this.userData = data.data[0];
     //   this.createuserform.controls['username'].setValue(this.userData.username);
     //   this.createuserform.controls['password'].setValue(this.userData.password);
     //   this.createuserform.controls['filepath'].setValue("ftp.gemfind.net\\FTP_USERS\\"+this.userData.ftp_path);
     // }
     // else{
     //   this.viewDom = 1;
     // }
     // })
     
   }
 
}
