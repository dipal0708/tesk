import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewMyProductComponent } from './view-my-product/view-my-product.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule,MatDividerModule,MatRadioModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule,MatSlideToggleModule } from '@angular/material';
import { MatExpansionModule, MatPaginatorModule, MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";



import { DragDropModule } from '@angular/cdk/drag-drop';
import { FileUploadModule } from 'ng2-file-upload';

import { TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { JewelryUploadHistoryComponent } from './jewelry-upload-history/jewelry-upload-history.component';
import { JewelryDataMappingComponent} from './jewelry-data-mapping/jewelry-data-mapping.component';
import { JewelryUploadFileComponent } from './jewelry-upload-file/jewelry-upload-file.component';
import { JewelryAddProductComponent } from './jewelry-add-product/jewelry-add-product.component';
import { JewelryManageCollectionComponent } from './jewelry-manage-collection/jewelry-manage-collection.component';
import { JewelleryLandingComponent } from './jewellery-landing/jewellery-landing.component';
import { JewelleryManageFTPComponent } from './jewellery-manage-ftp/jewellery-manage-ftp.component';


const diamondRoutes: Routes = [
  {
    path: 'viewmyproduct',
    component: ViewMyProductComponent

  },
  {
    path: 'jewelryuploadhistory',
    component: JewelryUploadHistoryComponent

  },
  {
    path: 'jewelryaddproduct',
    component: JewelryAddProductComponent

  },
  {
    path: 'jewelryuploadfile',
    component: JewelryUploadFileComponent

  },
  {
    path: 'jewelrydatamapping',
    component: JewelryDataMappingComponent

  },
  {
    path: 'jewelrymanagecollection',
    component: JewelryManageCollectionComponent

  },
  {
    path: 'landingPage',
    component: JewelleryLandingComponent

  },
  {
    path: 'jewelrymanageftp',
    component: JewelleryManageFTPComponent

  },
];
@NgModule({
  declarations: [ViewMyProductComponent, JewelryUploadHistoryComponent, JewelryDataMappingComponent, JewelryUploadFileComponent, JewelryAddProductComponent, JewelryManageCollectionComponent, JewelleryLandingComponent, JewelleryManageFTPComponent],
  imports: [DragDropModule,MatExpansionModule, MatTableModule, MatAutocompleteModule, MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, FormsModule, ReactiveFormsModule,
    MatButtonModule, MatTabsModule, MatCardModule, MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
    CommonModule,InfiniteScrollModule,MatRadioModule,MatDividerModule,MatSlideToggleModule,
    RouterModule.forChild(diamondRoutes),
    FileUploadModule,TranslateModule.forRoot(),
  ],
  exports:[],
  entryComponents:[]
})
export class JewelleryProductModule { }
