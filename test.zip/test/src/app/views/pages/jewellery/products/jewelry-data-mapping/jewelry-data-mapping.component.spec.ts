import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryDataMappingComponent } from './jewelry-data-mapping.component';

describe('JewelryDataMappingComponent', () => {
  let component: JewelryDataMappingComponent;
  let fixture: ComponentFixture<JewelryDataMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryDataMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryDataMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
