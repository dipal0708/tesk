import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelleryManageFTPComponent } from './jewellery-manage-ftp.component';

describe('JewelleryManageFTPComponent', () => {
  let component: JewelleryManageFTPComponent;
  let fixture: ComponentFixture<JewelleryManageFTPComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelleryManageFTPComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelleryManageFTPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
