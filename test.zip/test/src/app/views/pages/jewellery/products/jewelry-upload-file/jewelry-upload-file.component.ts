import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '../../../../../../environments/environment';
import { FileUploader } from 'ng2-file-upload';
import { Uploader } from '@syncfusion/ej2-inputs';
import { UserService } from '../../../../../core/services/users.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ExcelService } from '../../../../excel.service';
import * as XLSX from 'xlsx';

@Component({
  selector: 'kt-jewelry-upload-file',
  templateUrl: './jewelry-upload-file.component.html',
  styleUrls: ['./jewelry-upload-file.component.scss']
})
export class JewelryUploadFileComponent implements OnInit {
	public uploader: FileUploader = new FileUploader({ url: environment.api_url + 'api/diamondupload' }); //  withCredentials: true
	userDetail: any = [];
	uploadedFilename: any;
	uploadedFiles: Array<File>;
	profilePic: string;
	imagepath: any;
	imageFolder: any = environment.api_url + '/uploads/';
	selectedType: any;
	private target: any;
	selectedFileName:string = "Choose file";
	selectedFileName1:string = "Choose file";
	companies:any=[];
	DataForLocalStorage: any;
	arrayBuffer:any;
  file:File;
  forlocal:any;
	company:any=[{name:'RAPNET'},{name:'INDEX ONLINE'},{name:'POLYGON'}];
	diamondFileUploadform: FormGroup;
	constructor(private toastr: ToastrService,
		private http: HttpClient, private translate: TranslateService) { }

		ngOnInit() {
			
			this.userDetail = JSON.parse(localStorage.getItem('userDetail2'));
			this.selectedType='Replace all';
			this.companies = JSON.parse(localStorage.getItem('userCompany'));
			this.uploader.onBeforeUploadItem = (file) => {
				debugger
				file.withCredentials = false;
			};
			debugger
			this.uploader.onBuildItemForm = (file: any, form: any) => {
				debugger
				
				if(file.file.name)
				{
					debugger
					form.append('dealer_id', this.companies[0].dealerid); //note comma separating key and value			
					form.append('upload_type', this.selectedType);
					form.append('file_name',file.file.name)
				}else{
					this.toastr.error("Select file and upload type. Please try again.");	
					return; 
				}	
			};
		}
		
		incomingfile(event) 
		{
		  debugger;
		this.file= event.target.files[0]; 
		}
		public onChange2(event: any): void {
			debugger
			
			if(this.uploader.queue.length == 2){
				debugger
				this.uploader.queue[0] = this.uploader.queue[1];
				this.uploader.queue.splice(1, 1);
			}
			this.uploader.onSuccessItem = (item: any, response: string, status: number) => {
				debugger
				let data = JSON.parse(response); //success server response
				if (data.error_code == 1)
					this.toastr.success("There is some issue in upload. Please try again.");
				else {
					this.toastr.success("File uploaded successfully.");
					debugger
					event.target.value.split("\\" ).pop();
					//this.uploader.queue = [];
				}
			}
			this.uploader.onErrorItem = (item: any, response: string, status: number) => {
	
				//let data = JSON.parse(response); //success server response
				this.toastr.error("There is some issue in upload. Please try again.");
			}
			this.target = event.target || event.srcElement;
			this.selectedFileName1 = event.target.files[0].name
			event.srcElement.value = "";
		}
		
		public onChange(event: any): void {
			debugger
			
			if(this.uploader.queue.length == 2){
				debugger
				this.uploader.queue[0] = this.uploader.queue[1];
				this.uploader.queue.splice(1, 1);
			}
			this.uploader.onSuccessItem = (item: any, response: string, status: number) => {
				debugger
				let data = JSON.parse(response); //success server response
				if (data.error_code == 1)
					this.toastr.success("There is some issue in upload. Please try again.");
				else {
					this.toastr.success("File uploaded successfully.");
					debugger
					event.target.value.split("\\" ).pop();
					//this.uploader.queue = [];
				}
			}
			this.uploader.onErrorItem = (item: any, response: string, status: number) => {
	
				//let data = JSON.parse(response); //success server response
				this.toastr.error("There is some issue in upload. Please try again.");
			}
			this.target = event.target || event.srcElement;
			this.selectedFileName = event.target.files[0].name
			event.srcElement.value = "";
		}

		

		DiamondInfoDownload(value){
			if(value == 'diamond'){
	
				let link = document.createElement("a");
				link.download = "Diamond Guidline";
				link.href = "assets/media/users/ImageGuideline.pdf";
				link.click();
	
				// window.open('/assets/media/users/ImageGuideline.pdf', '_blank');
			}
			if(value == 'diamondExcelDemo'){
	
				let link = document.createElement("a");
				link.download = "JC Diamond Data Form";
				link.href = "assets/media/files/JCDiamondDataForm.xlsx";
				link.click();
	
				// window.open('/assets/media/users/ImageGuideline.pdf', '_blank');
			}else{
				
			}
		}
		
		Upload() {
			debugger;
			let fileReader = new FileReader();
			  fileReader.onload = (e) => {
				  this.arrayBuffer = fileReader.result;
				  var data = new Uint8Array(this.arrayBuffer);
				  var arr = new Array();
				  for(var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
				  var bstr = arr.join("");
				  var workbook = XLSX.read(bstr, {type:"binary"});
				  var first_sheet_name = workbook.SheetNames[0];
				  var worksheet = workbook.Sheets[first_sheet_name];
				  console.log(XLSX.utils.sheet_to_json(worksheet,{raw:true}));
				  this.forlocal=XLSX.utils.sheet_to_json(worksheet,{raw:true});
				  localStorage.setItem('DataForLocalStorage', JSON.stringify(this.forlocal));
			  }
			  fileReader.readAsArrayBuffer(this.file);
		
			 
			   
		}
}


	// fileChange(element) {
	// 	this.uploadedFiles = element.target.files;
	// 	this.uploadedFilename = this.uploadedFiles[0].name;
	// }
	// upload() {

	// 	let formData = new FormData();
	// 	var obj: any = {
	// 		imageDetial: this.uploadedFiles[0].name,
	// 		formData: formData
	// 	};
	// 	for (var i = 0; i < this.uploadedFiles.length; i++) {
	// 		formData.append("uploads[]", this.uploadedFiles[i], this.uploadedFiles[i].name);
	// 		formData.append("uploads2[]", '720');
	// 		// formData.append("imageDetail",obj );
	// 	}

	// 	this.http.post(environment.api_url + 'api/diamondupload', formData)
	// 		.subscribe((response: any) => {
	// 			this.profilePic = response.data;
	// 			this.toastr.success(this.translate.instant('File Upload successfully..'), 'Success!');
	// 			console.log('response received is ', response);
	// 		});
	// }

	