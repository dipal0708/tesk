import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-jewellery-landing',
  templateUrl: './jewellery-landing.component.html',
  styleUrls: ['./jewellery-landing.component.scss']
})
export class JewelleryLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
