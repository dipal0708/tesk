import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryAddProductComponent } from './jewelry-add-product.component';

describe('JewelryAddProductComponent', () => {
  let component: JewelryAddProductComponent;
  let fixture: ComponentFixture<JewelryAddProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryAddProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryAddProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
