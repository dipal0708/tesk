import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelleryLandingComponent } from './jewellery-landing.component';

describe('JewelleryLandingComponent', () => {
  let component: JewelleryLandingComponent;
  let fixture: ComponentFixture<JewelleryLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelleryLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelleryLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
