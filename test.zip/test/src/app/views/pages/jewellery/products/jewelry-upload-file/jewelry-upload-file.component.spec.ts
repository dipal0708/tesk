import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryUploadFileComponent } from './jewelry-upload-file.component';

describe('JewelryUploadFileComponent', () => {
  let component: JewelryUploadFileComponent;
  let fixture: ComponentFixture<JewelryUploadFileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryUploadFileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryUploadFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
