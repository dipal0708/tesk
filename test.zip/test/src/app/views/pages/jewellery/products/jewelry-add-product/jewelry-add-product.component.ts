import { Component, OnInit, Inject ,ChangeDetectorRef} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SafeHtml } from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { UserService } from '../../../../../core/services/users.service';
import { ToastrService } from 'ngx-toastr';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'kt-jewelry-add-product',
  templateUrl: './jewelry-add-product.component.html',
  styleUrls: ['./jewelry-add-product.component.scss']
})
export class JewelryAddProductComponent implements OnInit {


  companyaddform: FormGroup;
  // --------------------Bind Data----------------
 

  //-----Upload and dislay
  uploadedFiles: Array < File > ;
  uploadedFilename:any;
  public imagePath;
  imgURL: any;
  companies:any;
  public message: string;
  show:boolean=false;
  selectedFileName:string = "Choose file";
  selectedFileName1:string = "Choose file";
  file:File;
  alllistofmetaltype:any=[];
  alllistofmetalcolor:any=[];
  alllistofcategory:any=[];
  jewelrymetaltype:any=[];
  jewelrymetalcolor:any=[];
  //--------------bind data arrray end
  
 
  private unsubscribe: Subject<any>;
 
  constructor(private fb: FormBuilder,private service:UserService) {
  };

  ngOnInit() {
    debugger;
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this.initAddForm();
    this.allMetalTypeddl();
    this.allMetalColorddl();
    this.allCategory();
    
  }

  allMetalTypeddl(){
    
    var object={
      dealerid:this.companies[0].dealerid,
    }

    this.service.allJewelleryMetalType(object).subscribe((data:any)=>{
      debugger;
      this.jewelrymetaltype = data.data;
      // for(var i = 0; i <= data.data.length; i++) {

      //   this.alllistofmetaltype.push(data.data[i].metaltype);

      // }
     
    });
  }

  allMetalColorddl(){
    var objct={
      dealerid:this.companies[0].dealerid,
    }

    this.service.allJewelleryMetalColor(objct).subscribe((data:any)=>{
      debugger;
      
      this.jewelrymetalcolor=data.data;
      // for(var j = 0; j <= data.data.length; j++) {

      //   this.alllistofmetalcolor.push(data.data[j].metalcolor);

      // }
      
     
    });
    
  }
  fileChange(element) {
		this.uploadedFiles = element.target.files;
		this.uploadedFilename = this.uploadedFiles[0].name;
	}

  allCategory(){
    var ob={
      dealerid:this.companies[0].dealerid,
    }

    this.service.allJewelleryCategory(ob).subscribe((data:any)=>{
      debugger
      // for(var k = 0; k <= data.data.length; k++) {

      //   this.alllistofcategory.push(data.data[k].categoryname);

      // }
     
     
    });
    
  }

  incomingfile(event) 
		{
		  debugger;
		this.file= event.target.files[0]; 
    }
    

    
  
  initAddForm(){
    this.companyaddform=this.fb.group({
      stylenumber:[''],
      metaltype:[''],
      metalcolor:[''],
      productname:[''],
      retaildescription:[''],
      qtyonhand:[''],
      width:[''],
      gender:[''],
      Displayorder:[''],
      finishingtechnique:[''],
      claptype:[''],
      backfinding:[''],
      retailprice:[''],
      productdescription2:[''],
      msrp:[''],
      videourl:[''],
      bulletpoint1:[''],
      matchingst:[''],
      additionalinfo:[''],
      bulletpoint2:[''],
      upsell:[''],
      wholesaledescription:[''],
      bulletpoint3:[''],
      groupedproduct:[''],
      bulletpoint4:[''],
      dimentions:[''],
      bulletpoint5:[''],
      weight:[''],
      thickness:[''],
      unitofmeasure:[''],
      discounta:[''],
      qty1:[''],
      qty2:[''],
      qty3:[''],
      qty4:[''],
      qty5:[''],
      retailerbrandname:[''],
      vendorname:[''],
      wholesalebaseprice:[''],
      basemetalmark:[''],
      collection:[''],
      availability:[''],
      retailpricemethod:[''],
      stockfingersize:[''],
      minfingersize:[''],
      maxfingersize:[''],
      fingersizeincrement:[''],
      basecostfixed2:[''],
      basecostfixed1:[''],
      discount1:[''],
      discount2:[''],
      file_name:['']
    });
  }

  

  submit(){
    debugger;
    this.companyaddform.value;
    let formData = new FormData();
		for (var i = 0; i < this.uploadedFiles.length; i++) {
			formData.append("uploads[]", this.uploadedFiles[i], this.uploadedFiles[i].name);
		}
    var obj={
      dealerid:this.companies[0].dealerid,
      stylenumber:this.companyaddform.value.stylenumber,
      DealerStockNumber:"test",
      ProductName:this.companyaddform.value.productname,
      ShortDescription:this.companyaddform.value.retaildescription,
      productdescription:this.companyaddform.value.productdescription2,
      quantity:this.companyaddform.value.qtyonhand,
      DisplayOrder:this.companyaddform.value.Displayorder,
      StatusID:1,
      MetalTypeID:this.companyaddform.value.metaltype,
      MetalColorID:this.companyaddform.value.metalcolor,
      Terms:"",
      IsStockBalancing:1,
      RetailPriceCodeID:this.companyaddform.value.retailpricemethod,
      IsCalculatedRetailPrice:120,
      backfinding:this.companyaddform.value.backfinding,
      retailprice:this.companyaddform.value.retailprice,
      msrp:this.companyaddform.value.msrp,
      MSRP2:0.2,
      MSRPTypeID:1,
      IsCalculatedMSRP:1,
      HasSideStones:2,
      ProgMetal:"",
      GemstoneType:"",
      NoOfGemstone:5,
      GemstoneShape:"",
      GemstoneCaratWeight:0.5,
      GemstoneQuality:"",
      GemstoneCarat:0.8,
      GemstoneColor:"",
      AllowableShapeName:"",
      AllowableMinSize:"",
      AllowableMaxSize:"",
      CustomField1Name:"",
      CustomField1:"",
      CustomField2Name:"",
      CustomField2:"",
      CustomField3Name:"",
      CustomField3:"",
      CustomField4Name:"",
      CustomField4:"",
      CustomField5Name:"",
      CustomField5:"",
      DesigenrID:5,
      CategoryID:5,
      SubCategoryID:5,
      CollectionID:this.companyaddform.value.collection,
      GenderID:this.companyaddform.value.gender,
      PriceType:1,
      DiscountLevelType1:this.companyaddform.value.basecostfixed1,
      DiscountLevelValue1:this.companyaddform.value.discount1,
      DiscountLevelType2:this.companyaddform.value.basecostfixed2,
      DiscountLevelValue2:this.companyaddform.value.discount2,
      RetailerDiscountType:"",
      RetailerDiscountValue:"",
      SelectedAttributes:"",
      CustomeAttributelabel:"",
      SecondaryMetalType:"",
      ProductType:1,
      ParentSKU:"",
      IsRingBuilder:0,
      PrimaryDiamondShape:"",
      NumberOfPrimaryDiamond:1,
      PrimaryDiamondTotalWeight:0.5,
      PrimaryDiamondClarity:"",
      PrimaryDiamondColor:"",
      PrimaryDiamondSecondaryColor:"",
      PrimaryDiamondSaturation:"",
      PrimaryDiamondCertificateType:"",
      PrimaryDiamondCertificateNo:"",
      SecondaryDiamondShape:"",
      NumberOfSecondaryDiamonds:2,
      SecondaryDiamondTotalWeight:0.5,
      SecondaryDiamondClarity:"",
      SecondaryDiamondColor:"",
      SecondaryDiamondSecondaryColor:"",
      SecondaryDiamondSaturation:"",
      OtherDiamondInfo:"",
      OtherDiamondTotalWeight:0.2,
      TotalDiamondWeight:0.5,
      PrimaryGemstoneType:"",
      PrimaryGemstoneShape:"",
      NumberOfPrimaryGemstones:2,
      PrimaryGemstoneCaratWeight:5.5,
      PrimaryGemstoneDimensions:"",
      PrimaryGemstoneOrigin:"",
      PrimaryGemstoneQuality:"",
      SecondaryGemstoneType:"",
      SecondaryGemstoneShape:"",
      NumberOfSecondaryGemstones:5,
      SecondaryGemstoneCaratWeight:0.2,
      SecondaryGemstoneDimensions:"",
      SecondaryGemstoneOrigin:"",
      SecondaryGemstoneQuality:"",
      OtherGemstoneInfo:"",
      OtherGemstoneCaratWeight:0.1,
      OtherGemstoneQuality:"",
      TotalGemstoneWeight:0.5,
      FingerSize:this.companyaddform.value.stockfingersize,
      FingerSizeMinRange:this.companyaddform.value.minfingersize,
      FingerSizeMaxRange:this.companyaddform.value.maxfingersize,
      FingerSizeIncrement:this.companyaddform.value.fingersizeincrement,
      AllowableCenterStoneShape:"",
      AllowableCenterStoneSize:"",
      FlgISBlocked:1,
      ImagePath:this.companyaddform.value.file_name,
      ChainType:"",
      HasImage:2,
      AdditionalInformation:this.companyaddform.value.additionalinfo,
      AdditionalInformation2:this.companyaddform.value.wholesaledescription,
      videourl:this.companyaddform.value.videourl,
      additionalinformation:this.companyaddform.value.additionalinfo,
      groupedproductskus:this.companyaddform.value.groupedproduct,
      dimensions:this.companyaddform.value.dimentions,
      width:this.companyaddform.value.width,
      Length_in:0.5,
      weight:this.companyaddform.value.weight,
      thickness_mm:this.companyaddform.value.thickness,
      dimensionunitofmeasure:this.companyaddform.value.unitofmeasure,
      qty1:this.companyaddform.value.qty1,
      qty2:this.companyaddform.value.qty2,
      qty3:this.companyaddform.value.qty3,
      qty4:this.companyaddform.value.qty4,
      qty5:this.companyaddform.value.qty5,
      brandname:this.companyaddform.value.retailerbrandname,
      wholesaleprice:this.companyaddform.value.wholesalebaseprice,

    };


    this.service.addJewelryProduct(obj,formData).subscribe((data:any)=>{
      debugger
      
      //allJewelryProduct
       this.allJewellryProduct();

    });

  }

  allJewellryProduct(){

    var obj1={
      dealerid:this.companies[0].dealerid,
    }

   
    this.service.allJewelryProduct(obj1).subscribe((data:any)=>{
      debugger
      
      //

    });
  }

  preview(files) {
    debugger;
    if (files.length === 0)
      return;
 
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }
    else{
      this.message = "";
    }
 
    var reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
      this.imgURL = reader.result; 
    }

   
  }

  hidshow(value){
    if(value == 'show'){
      this.show = true;
    }
    if(value == 'hide'){
      this.show = false;
    }
    
  }

}