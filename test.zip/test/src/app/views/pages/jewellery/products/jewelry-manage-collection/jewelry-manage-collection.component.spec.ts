import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelryManageCollectionComponent } from './jewelry-manage-collection.component';

describe('JewelryManageCollectionComponent', () => {
  let component: JewelryManageCollectionComponent;
  let fixture: ComponentFixture<JewelryManageCollectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JewelryManageCollectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelryManageCollectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
