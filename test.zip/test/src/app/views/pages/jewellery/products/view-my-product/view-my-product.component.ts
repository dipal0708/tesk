import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import {JewelryFilterComponent} from '../../common-component/jewelry-filter/jewelry-filter.component'

@Component({
  selector: 'kt-view-my-product',
  templateUrl: './view-my-product.component.html',
  styleUrls: ['./view-my-product.component.scss']
})
export class ViewMyProductComponent implements OnInit {
  totalItems = 2222 ;
  forhide= false;
  buttonName="List";
  searchbox1:any;
  TableArray :any = ['1','2','2','2','2','1','2','2','2','2'];
  selectedItems:any = ['1','2']
  displayedColumns: string[] = ['styleNo','price','gemfindid'];
  selecteitem:any={styleNo:"E-PR-4P-100",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-4prong-yellow.jpg&wi=189&hi=189",gemfindid:"1234"};
  itemArray :any = [{styleNo:"E-PR-4P-100",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-3prong-white.jpg&wi=189&hi=189",gemfindid:"1235"},
  {styleNo:"E-PR-4P-1001",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-princess-4prong-white.jpg&wi=189&hi=189",gemfindid:"1236"},
  {styleNo:"E-PR-4P-1002",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-4prong-yellow.jpg&wi=189&hi=189",gemfindid:"1237"},
  {styleNo:"E-PR-4P-1003",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-3prong-white.jpg&wi=189&hi=189",gemfindid:"1238"},
  {styleNo:"E-PR-4P-1004",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-4prong-yellow.jpg&wi=189&hi=189",gemfindid:"1239"},
  {styleNo:"E-PR-4P-1005",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-4prong-yellow.jpg&wi=189&hi=189",gemfindid:"1240"},
  {styleNo:"E-PR-4P-1006",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-4prong-yellow.jpg&wi=189&hi=189",gemfindid:"1241"},
  {styleNo:"E-PR-4P-1007",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-3prong-white.jpg&wi=189&hi=189",gemfindid:"1242"},
  {styleNo:"E-PR-4P-1008",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-bezel-yellow.jpg&wi=189&hi=189",gemfindid:"1243"},
  {styleNo:"E-PR-4P-1009",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-4prong-yellow.jpg&wi=189&hi=189",gemfindid:"1244"},
  {styleNo:"E-PR-4P-101",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-bezel-yellow.jpg&wi=189&hi=189",gemfindid:"1245"},
  {styleNo:"E-PR-4P-101",price:"490.00",image:"https://designers.gemfind.net/ResizeProductImages.aspx?img=https://www.gemfind.net/JewelryImages/2692/media/productimages/v2-stud-round-bezel-white.jpg&wi=189&hi=189",gemfindid:"1246"}]
  constructor(private dialog: MatDialog) { }
  
  ngOnInit() {
  }
  showFilterClick(){
    const dialogRef = this.dialog.open(JewelryFilterComponent, {
    });
    dialogRef.afterClosed().subscribe(result => {   
      
      
      if (!result) { 
        debugger
        return
      }
      else { 
        debugger
      }
    });
  }
  onClickimage(value){
    debugger
    var imagevalue = value
    this.selecteitem  = imagevalue;
  }
  applyFilter(filterValue: string) {
    
  }

  showList(){
    debugger;
    if(this.forhide==false){
      this.forhide=true;
      this.buttonName = "Grid";
    }
    else{
      this.forhide=false;
      this.buttonName = "List";
    }
  }
}
