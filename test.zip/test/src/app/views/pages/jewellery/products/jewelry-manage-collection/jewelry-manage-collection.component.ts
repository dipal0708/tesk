import { Component, OnInit,ViewChild } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { takeUntil, finalize, tap } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ActivatedRoute, RouterLink,Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'kt-jewelry-manage-collection',
  templateUrl: './jewelry-manage-collection.component.html',
  styleUrls: ['./jewelry-manage-collection.component.scss']
})
export class JewelryManageCollectionComponent implements OnInit {

  // dataSource: [{collectionname:"Collection 1",createdate:"08-20-2019",brandname:"Brand 1",totalproduct:"1000",status:true},
  // {collectionname:"Collection 2",createdate:"08-21-2019",brandname:"Brand 2",totalproduct:"2000",status:true},
  // {collectionname:"Collection 3",createdate:"08-22-2019",brandname:"Brand 3",totalproduct:"3000",status:true},
  // {collectionname:"Collection 4",createdate:"08-23-2019",brandname:"Brand 4",totalproduct:"4000",status:true},
  // {collectionname:"Collection 5",createdate:"08-24-2019",brandname:"Brand 5",totalproduct:"5000",status:true}];
  //For Image
  managecollectionform: FormGroup;
  public imagePath;
  imgURL: any;
  public message: string;
  show:boolean=false;
  collection_name_array;
  fordatastore:any;
  fordataindex:any;
  companies:any;
  tempCollectionid:any;
  createButton:boolean=false;
  viewLoader:boolean=false;
  displayedColumns: string[] = ['collection_name','create_date','brand_name','total_product','status','action'];
  private unsubscribe: Subject<any>;
   dataSource =[
  //    {collection:"Collection 1",createdate:"08/01/2019",brandname:"Brand 1",totalproduct:"1000"},
  // {collection:"Collection 2",createdate:"08/01/2019",brandname:"Brand 2",totalproduct:"2000"},
  // {collection:"Collection 3",createdate:"08/01/2019",brandname:"Brand 3",totalproduct:"3000"},
  // {collection:"Collection 4",createdate:"08/01/2019",brandname:"Brand 4",totalproduct:"4000"},
  // {collection:"Collection 5",createdate:"08/01/2019",brandname:"Brand 5",totalproduct:"5000"}
 ];
  constructor(private fb: FormBuilder,private service:UserService,private toastr: ToastrService,private sanitizer:DomSanitizer,private router:Router) { 
    
  }

  ngOnInit() {
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
   this.initRegisterForm();
   this.onPagecall();

  }
  initRegisterForm() {
		this.managecollectionform = this.fb.group({
		
			collectionname: [''],
      collectionbrand:[''],
      collectiondes:[''],
      collectionimage:[''],
      collectioncategory:['']
      
  });
}


//For Image
  preview(files) {
    debugger;
    if (files.length === 0)
      return;
 
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }
    else{
      this.message = "";
    }
 
    var reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
      this.imgURL = reader.result; 
    }
  }

  hideshow(value){
    debugger;
    if(value == 'show'){
      this.show = true;
      this.managecollectionform.reset();
    }
    if(value == 'hide'){
      this.show = false;
    }
    
  }
  onclickCreatecollection(){
    debugger;
    
    this.managecollectionform.value;
    var obj ={
      DealerID:this.companies[0].dealerid,
      CollectionName:this.managecollectionform.value.collectionname,
      IsEnabled:1,
      Description:this.managecollectionform.value.collectiondes,
      CollectionImage:"this.managecollectionform.value.collectionimage",
      DesginerID:1,
      CollectionCategory:"this.managecollectionform.value.collectioncategory",
      DisplayOrder:5.5,
      BrandID:2
      
    };

    //Proper API Call
    // this.service.addJewelryManageCollection(obj).pipe(
    //   tap((data:any) => {
    //     if (data.status==200) {
    //       this.toastr.success("Add Successfully..")
    //     } else {	
    //       this.toastr.error("Something Wrong.")
    //     }
    //   }),
    //   takeUntil(this.unsubscribe),
    //   finalize(() => {
        
    //     //this.cdr.detectChanges(); 
    //   })
    // ).subscribe();

   
   // Direct API Call

     this.service.addJewelryManageCollection(obj).subscribe((data:any)=>{
       debugger
       this.toastr.success('Add Manage Collection Successfully');
        this.onPagecall();

     });



    // if(!this.fordataindex){
    //   this.dataSource.push(obj);
    //   this.managecollectionform.reset();
    // }
    
    // else{
    //   this.dataSource[this.fordataindex].collection = this.managecollectionform.value.collectionname;
    //   this.dataSource[this.fordataindex].brandname = this.managecollectionform.value.collectionbrand;
    //   this.managecollectionform.reset();
    // }
    
    //this.managecollectionform.reset();
    this.show = false;
    
  }

  onclickUpdatecollection(){
    debugger;
    
    this.managecollectionform.value;
    var obj ={
      collectionid:this.tempCollectionid,
      DealerID:this.companies[0].dealerid,
      CollectionName:this.managecollectionform.value.collectionname,
      IsEnabled:1,
      Description:this.managecollectionform.value.collectiondes,
      CollectionImage:"this.managecollectionform.value.collectionimage",
      DesginerID:1,
      CollectionCategory:"this.managecollectionform.value.collectioncategory",
      DisplayOrder:5.5,
      BrandID:2
      
    };

    this.service.updateJewelleryManageCollection(obj).subscribe((data:any)=>{
      debugger
      this.toastr.success('Update Manage Collection Successfully');
       this.onPagecall();

    });

    this.show = false;

  }

onPagecall(){
  debugger;
  var obj1={
    DealerID :  this.companies[0].dealerid,
  }


  // this.service.getAllJewelleryManageCollection(obj1).pipe(
  //     tap((data:any) => {
  //       debugger;
  //       if (data.status==200) { 
         
  //       }
  //     }),
  //     takeUntil(this.unsubscribe),
  //     finalize(() => {  

  //     })
  //   ).subscribe();
  this.service.getAllJewelleryManageCollection(obj1).subscribe((data:any)=>{
    debugger
    this.dataSource = data.data;
  });
}

  getRecord(row,i){

    debugger;
    this.fordatastore={};
    this.collection_name_array=row.collection;
    this.fordatastore=row;
    this.fordataindex=i;
  }

  edit(item){
    debugger;
    this.tempCollectionid=item.collectionid;
    this.createButton = true;
    var obj1={
      forcollectionid :  item.collectionid,
    }
    // this.managecollectionform.controls['collectionname'].setValue(this.fordatastore.collection);
    this.service.getupdateJewelleryManageCollection(obj1).subscribe((data:any)=>{
      debugger;
      var collectionData = data.data;
      // this.dataSource = data.data;
      this.managecollectionform.controls['collectionname'].setValue(collectionData[0].collectionname);
      this.managecollectionform.controls['collectiondes'].setValue(collectionData[0].description);
    });

    this.show = true;
  }

  delete(idOfItem){
    debugger;
    var obj1={
      forcollectionid :  idOfItem.collectionid,
    }

    this.service.deleteJewelleryManageCollection(obj1).subscribe((data:any)=>{
      debugger;
      this.toastr.success('Delete Manage Collection Successfully');
      this.onPagecall();
    });
  }

  cancel(){
    debugger;
   
  }
 
}
