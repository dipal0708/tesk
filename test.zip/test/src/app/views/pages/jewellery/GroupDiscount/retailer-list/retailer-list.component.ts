import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-retailer-list',
  templateUrl: './retailer-list.component.html',
  styleUrls: ['./retailer-list.component.scss']
})
export class RetailerListComponent implements OnInit {

  displayedColumns: string[] = ['companyname','groupname','action'];

  dataSource : any = [
 {companyname:"Company 1", groupname:"Group 1"},
 {companyname:"Company 2", groupname:"Group 2"},
 {companyname:"Company 3", groupname:"Group 3"},
 {companyname:"Company 4", groupname:"Group 4"},
 {companyname:"Company 5", groupname:"Group 5"}];

  constructor() { }

  ngOnInit() {
  }

}
