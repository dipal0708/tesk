import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, RouterLink,Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'kt-discount-list',
  templateUrl: './discount-list.component.html',
  styleUrls: ['./discount-list.component.scss']
})
export class DiscountListComponent implements OnInit {


  displayedColumns: string[] = ['groupdiscountname','discountvalue','action'];

  dataSource : any = [
//  {groupdiscountname:"Store 1", discountvalue:"Retailer Name1"},
//  {groupdiscountname:"Store 1", discountvalue:"Retailer Name1"},
//  {groupdiscountname:"Store 1", discountvalue:"Retailer Name1"},
//  {groupdiscountname:"Store 1", discountvalue:"Retailer Name1"},
//  {groupdiscountname:"Store 1", discountvalue:"Retailer Name1"},
];
 
 companies:any;
 adddiscountlist: FormGroup;

  constructor(private fb: FormBuilder,private toastr: ToastrService,private service:UserService,private router:Router) { }

  ngOnInit() {
    
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this.initRegisterForm();
    this.getAllDiscountList();
  }

  initRegisterForm() {
		this.adddiscountlist = this.fb.group({
		
			discountname: [''],
      discountvalue:['']
      
      
  });
}

add(){
  debugger;
  this.adddiscountlist.value;
  var obj ={
    DealerID:this.companies[0].dealerid,
    groupdiscountname:this.adddiscountlist.value.discountname,
    discountvalue :this.adddiscountlist.value.discountvalue
   
    
  };

  this.service.addGroupList(obj).subscribe((data:any)=>{
    debugger
    
   this.getAllDiscountList();

  });



}

getAllDiscountList(){

  var obj1 ={
    DealerID:this.companies[0].dealerid,
       
  };

  this.service.allGroupList(obj1).subscribe((data:any)=>{
    debugger
    
    this.dataSource = data.data;

  });
}

edit(val){
debugger;

this.router.navigate(['/default/discountlist/adddiscount'], { queryParams: { value: val.groupdiscountid } });
}

delete(value){
  debugger;

  var ob = {
      id:value.groupdiscountid
  }

  this.service.DeleteDiscountList(ob).subscribe((data:any)=>{
    debugger
    this.toastr.success('Delete Discount Successfully');
    this.getAllDiscountList();


  });

}
  


}
