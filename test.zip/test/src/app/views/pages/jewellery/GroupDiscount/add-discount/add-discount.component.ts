import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../../core/services/users.service';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import {DomSanitizer} from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, RouterLink,Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'kt-add-discount',
  templateUrl: './add-discount.component.html',
  styleUrls: ['./add-discount.component.scss']
})
export class AddDiscountComponent implements OnInit {

  companies:any;
 adddiscountlist: FormGroup;
 id:any;
 UpdateData:any;
 addButton:boolean;

  constructor(private fb: FormBuilder,private service:UserService,private toastr: ToastrService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    debugger;
    this.companies = JSON.parse(localStorage.getItem('userCompany'));
    this.initRegisterForm();
    this.forUpdateData();
    
    
  }

  
  initRegisterForm() {
		this.adddiscountlist = this.fb.group({
		
			discountname: [''],
      discountvalue:['']
      
      
  });
}

forUpdateData(){
  debugger;
  this.id  = this.route.snapshot.queryParamMap.get('value');
    var obj ={
      ID:this.id
    }

    this.service.getPerticularDiscountListForUpdate(obj).subscribe((data:any)=>{
      debugger;
     
      this.UpdateData=data.data;


      this.adddiscountlist.controls['discountname'].setValue( this.UpdateData[0].groupdiscountname);
      this.adddiscountlist.controls['discountvalue'].setValue(this.UpdateData[0].discountvalue);
    
      if(this.adddiscountlist.value.discountname==" "){
        this.addButton=false;
      }
      else{
        this.addButton=true;
      }
    });

    
    
    
}

  add(){
    debugger;
    this.adddiscountlist.value;
    
    var obj ={
      DealerID:this.companies[0].dealerid,
      groupdiscountname:this.adddiscountlist.value.discountname,
      discountvalue :this.adddiscountlist.value.discountvalue
     
      
    };
  
    this.service.addGroupList(obj).subscribe((data:any)=>{
      debugger
      this.toastr.success('Add Discount Successfully');
      this.router.navigate(['/default/discountlist/Groupdiscount']);
  
    });
  
  
  
  }

  update(){
    debugger;

    this.adddiscountlist.value;

    var object={

      id:this.id,
      groupdiscountname:this.adddiscountlist.value.discountname,
      discountvalue:this.adddiscountlist.value.discountvalue
    }

    this.service.updateDiscountList(object).subscribe((data:any)=>{
      debugger
      this.toastr.success('Update Discount Successfully');
      this.router.navigate(['/default/discountlist/Groupdiscount']);
  
    });

  }

}
