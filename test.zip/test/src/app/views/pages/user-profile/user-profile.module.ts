// Angular
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
// NgBootstrap
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// Core Module
import { CoreModule } from '../../../core/core.module';
import { PartialsModule } from '../../partials/partials.module';
import { UserProfileComponent } from './user-profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule,MatTabsModule , MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule } from '@angular/material';
import { TranslateModule } from '@ngx-translate/core'; 

@NgModule({
	imports: [
		TranslateModule,
		MatButtonModule,MatTabsModule , MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
		FormsModule, ReactiveFormsModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		RouterModule.forChild([
			{
				path: '',
				component: UserProfileComponent
			}
		]),
		
	],
	providers: [],
	declarations: [
		UserProfileComponent,		
	],
	exports: [FormsModule, ReactiveFormsModule],
})
export class UserProfileModule {
}
