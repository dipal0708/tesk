
// Angular
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// RxJS
import { finalize, takeUntil, tap, timeInterval } from 'rxjs/operators';
// Translate
import { TranslateService } from '@ngx-translate/core';
// NGRX
import { Store } from '@ngrx/store';
import { AppState } from '../../../core/reducers';
// Auth
import { AuthNoticeService, AuthService, Register, User } from '../../../core/auth/';
import { Subject } from 'rxjs';
//import { ConfirmPasswordValidator } from './confirm-password.validator';
import { ApiService } from '../../../core/services/api.service';
import { CognitoCallback } from '../../../core/services/cognito.service';
import { UserService } from '../../../core';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { registerLocaleData } from '@angular/common';
import { HttpClient } from '@angular/common/http';
//import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
	selector: 'kt-register',
	templateUrl: './user-profile.component.html',
	styleUrls: ['user-profile.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class UserProfileComponent implements CognitoCallback {
	companies:any=[];
	userinfo:any=[];
	registerForm: FormGroup;
	changePassForm: FormGroup;
	loading = false;
	errors: any = [];
	countryList: any = [];
	localToken: any = [];
	getCountrycode: any = ['+000'];
	email: string;
	name: string;
	languageList: any = [{'text':'English','value':'en'},{'text':'Spanish','value':'es'}];
	currencyList: any = ['USD', 'INR', 'CAD '];
	checked:boolean=false;
// for image upload
	uploadedFilename:any;
	uploadedFiles: Array < File > ;
	profilePic:string;
	imagepath:any;
	// imageFolder:any = 'http://34.205.171.23:3000/uploads/';
	imageFolder:any = 'http://localhost:3000/UploadedContent/';
	private unsubscribe: Subject<any>; // Read more: => https://brianflove.com/2016/12/11/anguar-2-unsubscribe-observables/

	/**
	 * Component constructor
	 *
	 * @param authNoticeService: AuthNoticeService
	 * @param translate: TranslateService
	 * @param router: Router
	 * @param auth: AuthService
	 * @param store: Store<AppState>
	 * @param fb: FormBuilder
	 * @param cdr
	 */
	constructor(
		private authNoticeService: AuthNoticeService,
		private translate: TranslateService,
		private router: Router,
		private auth: AuthService,
		private store: Store<AppState>,
		private fb: FormBuilder,
		private cdr: ChangeDetectorRef,
		private apiService: ApiService,
		private usersService: UserService,
		private toastr: ToastrService,
		private http: HttpClient

	) {
		this.unsubscribe = new Subject();
		this.router = router;
		this.usersService.getCountry().subscribe((data: any) => {
			this.countryList = data.data;
		});
	}

	/*
	 * @ Lifecycle sequences => https://angular.io/guide/lifecycle-hooks
    */

	/**
	 * On init
	 */

	ngOnInit() { 
		this.userinfo = JSON.parse(localStorage.getItem('userDetail'));
		this.companies = JSON.parse(localStorage.getItem('userCompany'));
		this.initRegisterForm();		
		this.registerForm.controls['email'].disable();	
		this.registerForm.controls['username'].disable();
		this.changePassForm.controls['chngEmail'].disable();	 
		
	}
	 
	/*
    * On destroy
    */
	ngOnDestroy(): void {

		this.unsubscribe.next();
		this.unsubscribe.complete();
		this.loading = false;
	}

	/**
	 * Form initalization
	 * Default params, validators
	 */
	initRegisterForm() {	
		this.changePassForm = this.fb.group({
			oldpass:[''],
			newpass:['',Validators.compose([
				Validators.required,
				Validators.minLength(8),
				Validators.maxLength(100)
			])],
			confirmpass:[''],
			chngEmail:['',Validators.compose([
				Validators.required,
				Validators.email,
				Validators.minLength(3), 
				Validators.maxLength(320)
			]),],
			verifyCode:['']
		 });
		this.registerForm = this.fb.group({
			companyname: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			firstname: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			], 
			lastname: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			], 
			address: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			city: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			state: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			country: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			zipcode: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			], 
			accounttype: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			contactno: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			//------------------------------------------------------------------------------------------------------------------------------------
			fullname: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			],
			email: ['', Validators.compose([
				Validators.required,
				Validators.email,
				Validators.minLength(3),
				// https://stackoverflow.com/questions/386294/what-is-the-maximum-length-of-a-valid-email-address
				Validators.maxLength(320)
			]),
			],
			username: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			]),
			],
			password: [''],
			// confirmPassword: ['', Validators.compose([
			// 	Validators.required,
			// 	Validators.minLength(3),
			// 	Validators.maxLength(100)
			// ])
			// ],
			language: [''],
			currency: [''],
			pk_id: [''],
			access_token: [''],
			agree: [false, Validators.compose([Validators.required])]
		}, {
				//validator: ConfirmPasswordValidator.MatchPassword
			});
		
		 
			debugger
		var userDetail = JSON.parse(localStorage.getItem('userDetail'));
		this.email = userDetail.email;
		this.name = userDetail.firstname +" "+ userDetail.lastname;
		this.registerForm.controls['companyname'].setValue(userDetail.company_name);
		this.registerForm.controls['accounttype'].setValue(userDetail.account_type);
		this.registerForm.controls['address'].setValue(userDetail.address);
		this.registerForm.controls['city'].setValue(userDetail.city);
		this.registerForm.controls['contactno'].setValue(userDetail.contact_no);
		this.registerForm.controls['firstname'].setValue(userDetail.firstname);
		this.registerForm.controls['lastname'].setValue(userDetail.lastname);
		this.registerForm.controls['state'].setValue(userDetail.state);
		this.registerForm.controls['zipcode'].setValue(userDetail.zip_code);
		this.registerForm.controls['fullname'].setValue(userDetail.company_name);
		this.registerForm.controls['email'].setValue(userDetail.email);
		this.registerForm.controls['username'].setValue(userDetail.email);
		this.registerForm.controls['pk_id'].setValue(userDetail.pk_id);
		this.registerForm.controls['access_token'].setValue(userDetail.accesstoken);
		this.registerForm.controls['currency'].setValue(userDetail.currency);
		this.registerForm.controls['language'].setValue(userDetail.language);
		this.registerForm.controls['country'].setValue(userDetail.country);
		this.changePassForm.controls['newpass'].setValue('');
		this.changePassForm.controls['chngEmail'].setValue(userDetail.email);
		this.profilePic = this.companies[0].dealerid + '/'+ userDetail.image_name;
		// this.imageFolder = this.imageFolder + ;
			///const toSelect = this.countryList.map(item => ({ pk_id: item.pk_id })); //indexOf(userDetail.country);
	}

	/**
	 * Form Submit
	 */

	submit() {

		
		const invalid = [];
		const controlsqw = this.registerForm.controls;
    	for (const name in controlsqw) {
        if (controlsqw[name].invalid) {
			invalid.push(name);
			
		}
		
	
    }	debugger
		if(this.registerForm.invalid){
			this.toastr.error('Somthing Wrong, Please Validate Fields.');
			return
		}
		
		const controls = this.registerForm.controls;
		
		this.loading = true;
		const _user: User = new User();

		_user.pk_id = this.registerForm.value.pk_id,
		_user.accesstoken = this.registerForm.value.access_token;
		//_user.accesstoken = "dfdsfdsfdfd",
		_user.account_type = this.registerForm.value.accounttype,
		_user.address = this.registerForm.value.address,
		_user.city = this.registerForm.value.city,
		_user.company_name = this.registerForm.value.companyname,
		_user.contact_no = this.registerForm.value.contactno,
		_user.country = this.registerForm.value.country;/// "9577e330-5544-11e9-b898-e35cda8b606c",
		_user.created_date = new Date().toJSON().slice(0, 10);//"2019-04-11",
		_user.currency = this.registerForm.value.currency,
		_user.email = this.registerForm.value.email,
		_user.language = this.registerForm.value.language,
		_user.firstname = this.registerForm.value.firstname,
		_user.lastname = this.registerForm.value.lastname,
		_user.password = this.registerForm.value.password,
		_user.refreshtoken = 'null',
		_user.roles = "1",
		_user.state = this.registerForm.value.state,
		_user.updated_date = new Date().toJSON().slice(0, 10);// "2019-04-11",
		_user.user_name = this.registerForm.value.username,
		_user.zip_code = this.registerForm.value.zipcode,
		localStorage.setItem('userDetail', JSON.stringify(_user));

		///this.auth.register(_user, this);
		this.loading = false;
		/// code to update data in our database //////////
		this.auth.updateProfile(_user, this).pipe(
			tap(user => {
				if (user) {
					this.toastr.success(this.translate.instant('AUTH.REGISTER.UPDATE'),'Success!'); 
				} else {
					this.toastr.error(this.translate.instant('AUTH.REGISTER.UPDATE'),'Error');
					//this.authNoticeService.setNotice(this.translate.instant('AUTH.VALIDATION.INVALID_LOGIN'), 'danger');
				}
			}),
			takeUntil(this.unsubscribe),
			finalize(() => {
				this.loading = false;
				this.cdr.detectChanges();
			})
		).subscribe();
		/// end code ////////
	}
  /**
	 * Form Submit of change password
	 */
	submitChangePassword(){
		debugger
		this.changePassForm.value.chngEmail = this.email;
		// if (this.changePassForm.invalid) {	
		// 	this.toastr.error('Enter valid email-id.', '');					
		// 	return;
		// }
		const _user: User = new User();
		
		debugger
		this.auth.requestPassword(this.email.trim()).subscribe((data:any)=>{
			if(data.status==200)
			{
				this.checked=true;
				this.toastr.success(this.translate.instant('AUTH.REGISTER.VERIFYCODE'), '');
			}
			else
			{this.toastr.error(this.translate.instant(data.data.message), '');}
		},(err)=>{
			var k = err;
			this.toastr.error(this.translate.instant(err.msg.message), '');
		});  		 
	}
	/**
	 * Checking control validation
	 *
	 * @param controlName: string => Equals to formControlName
	 * @param validationType: string => Equals to valitors name
	 */
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.registerForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

	/**
	 * Checking control validation for change password
	 *
	 * @param controlName: string => Equals to formControlName
	 * @param validationType: string => Equals to valitors name
	 */
	isControlHasErrorChangePass(controlName: string, validationType: string): boolean {
		const control = this.changePassForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

	cognitoCallback(message: string, result: any) {

		if (message != null) { //error
			///this.errorMessage = message;
			///console.log("result: " + this.errorMessage);
			this.authNoticeService.setNotice(this.translate.instant(message, 'AUTH.REGISTER.SUCCESS'), 'danger');
		} else { //success
			//move to the next step			
			this.authNoticeService.setNotice(this.translate.instant('AUTH.REGISTER.SUCCESS'), 'success');
			console.log("redirecting");
			this.router.navigate(['/auth/confirmRegistration', result.user.username]);			 
		}
	}
	selectedFile:File = null;
	getCountryCode(countryName: any) {
		var countryCode = this.countryList.filter(x => x.country_name == countryName);
		this.getCountrycode = countryCode[0].country_code;
	}
	onFileSelected(event){
		this.selectedFile =<File> event.target.files[0];
	}
	onUpload(){
		
		const fd = new FormData();
		fd.append('image',this.selectedFile,this.selectedFile.name);
		// this.usersService.fileUpload(fd).subscribe((data:any)=>{
		// 	debugger
		// });
	}

	verifyPassword(){
		var datalength = this.changePassForm.value.verifyCode.length;
		if(datalength != 6){
			this.toastr.error('Please enter valid Verification Code..');
			return
		}
		debugger
		if(this.changePassForm.value.newpass == ""){
			this.toastr.error('Please enter Password..');
			return
		}
		if(this.changePassForm.invalid){
			this.toastr.error('Something Wrong. Please Validate Password');
			return
		}
		this.auth.confirmNewPassword(this.email, this.changePassForm.value.verifyCode, this.changePassForm.value.newpass).subscribe((data:any)=>{
			//this.router.navigate(['/auth/confirmRegistration',this.registerdata]);		
			if(data.status==200){
			this.changePassword();
			this.toastr.success('Password Changed Successfully..');
		}
			else
			{this.toastr.error(this.translate.instant(data.data.message), '');}
		},(err)=>{
			var k = err;
			this.toastr.error(this.translate.instant(err.msg.message), '');
		});

		
	}

	changePassword() {			
		const _user: User = new User();
		this.auth.getUserDetailbyEmail(this.changePassForm.value.email).subscribe((data: any) => {		
			_user.pk_id=data.data[0].pk_id;			
			_user.password=this.changePassForm.value.newpass;			
			_user.email=this.changePassForm.value.email;			
			this.auth.changePassword(_user).subscribe((data:any)=>{
				if(data.status == 200){
					this.toastr.error(this.translate.instant('AUTH.RESETPASSWORD.SOMETHINGWRONG'), '');
				}else{
					this.toastr.success(this.translate.instant('AUTH.RESETPASSWORD.RESETSUCCESS'), '');
					this.router.navigate(['/auth/login']);					
				}
				
			});
		});
	}
	fileChange(element) {
		this.uploadedFiles = element.target.files;
		this.uploadedFilename = this.uploadedFiles[0].name;
	}
	upload() {  
		debugger
		let formData = new FormData();
		for (var i = 0; i < this.uploadedFiles.length; i++) {
			formData.append("uploads[]", this.uploadedFiles[i], this.uploadedFiles[i].name);
			formData.append("dealerid[]", this.companies[0].dealerid);
			formData.append("pk_id[]", this.userinfo.pk_id);
		}
		this.usersService.uploadProfile(formData).pipe(
			tap((data:any) => {
			  if (data.status==200) {
					this.profilePic = this.companies[0].dealerid + '/'+ data.data;
					//this.profilePic = './assets/media/company-logos/logo-4.png';
					this.toastr.success(this.translate.instant('File Upload successfully..'),'Success!'); 
					console.log('response received is ', data);
			  }
			}),
			takeUntil(this.unsubscribe),
			finalize(() => {
			  this.cdr.detectChanges();
			})
		  ).subscribe();
		// this.http.post('http://34.205.171.23:3000/api/upload', formData)

		// .subscribe((response:any) => {
		// 	debugger
		// 	this.profilePic = response.data;
		// 	this.toastr.success(this.translate.instant('File Upload successfully..'),'Success!'); 
		// 	 console.log('response received is ', response);
		// });
	}
}

