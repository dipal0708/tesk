import { Component,Input, OnInit,ViewChild } from '@angular/core';
import { UserService } from '../../../core/services/users.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslationService } from '../../../core/_base/metronic';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { debug } from 'util';
import { Observable ,of } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { EmailTemplateComponent } from '../email-template/email-template.component';

import { DomSanitizer } from '@angular/platform-browser';
import { SecurityContext } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { element } from '@angular/core/src/render3';
import { DataSource } from '@angular/cdk/collections';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { CreatenewcompanyPopupboxComponent } from '../../pages/diamond/common-component/createnewcompany-popupbox/createnewcompany-popupbox.component';
import { ConfirmDialogboxComponent } from '../../pages/diamond/common-component/confirm-dialogbox/confirm-dialogbox.component';



@Component({
  selector: 'kt-companiesusers-list',
  templateUrl: './companiesusers-list.component.html',
  styleUrls: ['./companiesusers-list.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0', display: 'none'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class CompaniesusersListComponent implements OnInit {
  @ViewChild(CompaniesusersListComponent) private surveyComponent: CompaniesusersListComponent;
  dataSource: MatTableDataSource<any>;
  dataSource2: MatTableDataSource<any>;
  @Input() detailExpand ;
  @ViewChild('sortCol1') sortCol1: MatSort;
  @ViewChild('sortCol2') sortCol2: MatSort;
  @ViewChild(MatPaginator) paginator1: MatPaginator;
  @ViewChild('MatPaginator2') paginator2: MatPaginator;
  columnsToDisplay = ['name', 'weight', 'symbol', 'position'];
  expandedElement: CompaniesusersListComponent;

  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  SearchText:string;
  selectedIndex: number = 0;
  emailTemplateform: FormGroup;
  allcompaniesList:any=[];
  alluserssList:any=[];
  
  searchbox1:string;
  searchbox2:string;
  // dataSource =[
  //   {
  //     position: 1,
  //     name: 'Hydrogen',
  //     weight: 1.0079,
  //     symbol: 'H',
  //     description: `Hydrogen is a chemical element with symbol H and atomic number 1. With a standard
  //         atomic weight of 1.008, hydrogen is the lightest element on the periodic table.`
  //   }, {
  //     position: 2,
  //     name: 'Helium',
  //     weight: 4.0026,
  //     symbol: 'He',
  //     description: `Helium is a chemical element with symbol He and atomic number 2. It is a
  //         colorless, odorless, tasteless, non-toxic, inert, monatomic gas, the first in the noble gas
  //         group in the periodic table. Its boiling point is the lowest among all the elements.`
  //   }
  // ];
  // dataSource  = [];
  // dataSource2  = [];
  companydatabyId:any=[];
  companyeditform: FormGroup;
  updatebyPk:any;
  btnHideshow:boolean=false;
  isEnebale:boolean;
  countryList:any=[];
  userDetail:any=[];
  getCountrycode:any=['+000'];
  emailvalidate: any=true;
  filteredOptions: Observable<string[]>;
  resultsLength: number = 0;
  displayedColumns1: string[] = ['enabledisable', 'company_name','email','account_type', 'contact_no','action'];
  displayedColumns2: string[] = ['enabledisable', 'user_name', 'email','password','action'];

  constructor(public loader: LoadingBarService,private dom: DomSanitizer,private dialog:MatDialog, private activatedRoute:ActivatedRoute, private service:UserService,private fb: FormBuilder,private translate: TranslateService,private toastr:ToastrService) { 
    this.dataSource = new MatTableDataSource<any>([]);
    	this.dataSource.paginator = this.paginator1;
      this.dataSource.sort = this.sortCol1;
      this.dataSource2 = new MatTableDataSource<any>([]);
    	this.dataSource2.paginator = this.paginator2;
      this.dataSource2.sort = this.sortCol2;
  }
  ngOnInit() {
    this.initLoginForm();
    this.getAllrecords();
    this.companyeditform.controls['countryCode'].disable();

  }
  getAllrecords(){
    this.userDetail = JSON.parse(localStorage.getItem('userDetail2'));
    if(this.userDetail.roles == '1'){
      this.displayedColumns1 = [ 'company_name','email','account_type', 'contact_no','action'];
    }
    this.service.getAllcompanies(this.userDetail.pk_id).subscribe((data:any)=>{
      
      //this.allcompaniesList = data.data;
      
      
      this.dataSource.data = data.data;
      this.selectedIndex = 0;
      this.dataSource.data.sort((a, b) => {
        if (a.company_name < b.company_name) return -1;
        else if (a.company_name > b.company_name) return 1;
        else return 0;
      });
      console.log(data.data);
       this.dataSource.paginator = this.paginator1;
      this.dataSource.sort = this.sortCol1;
     

      //  this.allcompaniesList = this.allcompaniesList.filter(x => x.created_by == this.userDetail.pk_id);
      
      });
        
       
    this.filteredOptions = this.companyeditform.controls['country'].valueChanges.pipe(
			startWith(''),
			map(val => this.filter(val))
		  );

		this.service.getCountry().subscribe((data: any) => {
			var data1 = data.data;
			this.countryList  = data1.sort(function(a, b) {
				if(a.country_name < b.country_name) { return -1; }
				if(a.country_name > b.country_name) { return 1; }
				return 0;
				// Ascending: first age less than the previous
			});
    });
  }
  initLoginForm() {
		this.companyeditform = this.fb.group({
      companyname: ['', Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(100)])],
			accounttype: ['', Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(100)])],
      companyaddress: ['', Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(100)])],
      mobilenumber: ['', Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(15),
				Validators.pattern("^[0-9]*$"),				
			])
      ],
      
			// mobilenumber: ['', Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(13)])],
      country: ['', Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(100)])],
      state: ['', Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(100)])],
      zipcode: ['', Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(8)])],
      city: ['', Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(100)])],
      email: ['', Validators.compose([Validators.required,Validators.email,Validators.minLength(3),Validators.maxLength(50)])],
      countryCode:[''],
		});
	}
  onclickUser($event){
    if($event.index == 0){
      
      this.searchbox1;
      this.getAllrecords();
      
		}
		if($event.index == 1){
			this.selectedIndex = 1;
    }
		if($event.index == 2){
      
      this.searchbox2;
      this.service.getAllusers().subscribe((data:any)=>{
        ;
        this.alluserssList = data.data;
        this.dataSource2.data = this.alluserssList;
        this.dataSource2.paginator = this.paginator2;
			this.dataSource2.sort = this.sortCol2;
      });
      this.selectedIndex = 2;
		}
  }
  onEditclick(data){

    this.companyeditform.controls['email'].disable();
    this.service.getcompanybyId(data.pk_id).subscribe((data:any)=>{
      
      this.selectedIndex = 1;
      this.companydatabyId = data.data[0];
      this.isEnebale = this.companydatabyId.is_enable;
      var country = this.countryList.filter(x => x.pk_id == this.companydatabyId.country);
      
        this.updatebyPk = this.companydatabyId.pk_id;
        this.companyeditform.controls['companyname'].setValue(this.companydatabyId.company_name);
        this.companyeditform.controls['accounttype'].setValue(this.companydatabyId.account_type);
        this.companyeditform.controls['companyaddress'].setValue(this.companydatabyId.address);
        this.companyeditform.controls['email'].setValue(this.companydatabyId.email);
        this.companyeditform.controls['mobilenumber'].setValue(this.companydatabyId.contact_no);
        this.companyeditform.controls['country'].setValue(country[0].country_name);
        // this.companyeditform.controls['countryCode'].setValue(country[0].country_code);
        this.companyeditform.controls['city'].setValue(this.companydatabyId.city);
        this.companyeditform.controls['state'].setValue(this.companydatabyId.state);
        this.companyeditform.controls['zipcode'].setValue(this.companydatabyId.zip_code);
        this.getCountrycode = country[0].country_code;
        
        this.btnHideshow = true;
    });
	};
	onDeleteClick(data){
		// this.service.deleteEmailTemplate(data.pk_id).subscribe((data:any)=>{
		// 	
		// });
  }
  getCountryCode() {
		
    var countryCode = this.countryList.filter(x => x.country_name.toLowerCase() == this.companyeditform.value.country.toLowerCase());
    if(countryCode.length == 1){
      this.getCountrycode = countryCode[0].country_code;
    }
		
  }
  isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.companyeditform.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

  onUpdateclick(){
    if(this.companyeditform.invalid){
      this.toastr.error("Please Fill All Fields");
      return
    }
    ;
      this.selectedIndex = 0;
      var country = this.countryList.filter(x => x.country_name.toLowerCase() == this.companyeditform.value.country.toLowerCase());
     var obj = {
            pk_id: this.updatebyPk,
            account_type:  this.companyeditform.value.accounttype,
            address: this.companyeditform.value.companyaddress,
            city: this.companyeditform.value.city,
            company_name: this.companyeditform.value.companyname,
            contact_no: this.companyeditform.value.mobilenumber,
            country: country[0].pk_id,
            created_date: "2019-05-03",
            currency: "null",
            email:  this.companydatabyId.email,
            language: "null",
            name: this.userDetail.name,
            state: this.companyeditform.value.state,
            is_enable :this.isEnebale,
            updated_date: "2019-05-03",
            zip_code: this.companyeditform.value.zipcode,
            created_by : this.userDetail.pk_id
    };
		this.service.updateCompanydetails(obj).subscribe((data:any)=>{
			
			this.getAllrecords();
    });
    this.clearForm();
    };
    submit(){
      
      if(this.companyeditform.invalid){
        this.toastr.error("Please Fill All Fields");
        return
      }
      var country = this.countryList.filter(x => x.country_name.toLowerCase() == this.companyeditform.value.country.toLowerCase());
     var obj = {
            account_type:  this.companyeditform.value.accounttype,
            address: this.companyeditform.value.companyaddress,
            city: this.companyeditform.value.city,
            company_name: this.companyeditform.value.companyname,
            contact_no: this.companyeditform.value.mobilenumber,
            country: country[0].pk_id,
            created_date: "2019-05-03",
            currency: "null",
            email:  this.companyeditform.value.email,
            language: "null",
            name: this.userDetail.name,
            state: this.companyeditform.value.state,
            updated_date: "2019-05-03",
            zip_code: this.companyeditform.value.zipcode,
            created_by : this.userDetail.pk_id
    };
    this.service.addnewCompany(obj).subscribe((data:any)=>{
      if(data.status ==  202){
        
        this.toastr.error("Companny Already Exists");
        this.getCountrycode = "";
        return
      }else{
        
        this.selectedIndex = 0;
        this.getAllrecords();
      }
    });
    this.clearForm();
    }
    onChange(event,data) {
      ;
      if(event.checked == true){
        this.service.updateuserDisable(data.pk_id).subscribe((data:any)=>{
          ;
          this.toastr.success("User Disable Successfully");
        });
      }
      if(event.checked == false){
        this.service.updateuserEnable(data.pk_id).subscribe((data:any)=>{
          ;
          this.toastr.success("User Enable Successfully");
        });
      }
  }
  onChangecompany(event,data) {
    ;
   
      // const dialogRef = this.dialog.open(ConfirmDialogboxComponent, {
      //   width: '250px',
      //   data: {name: "", animal: "this.animal"}
      // });
  
      // dialogRef.afterClosed().subscribe(result => {
      //   
      //   console.log('The dialog was closed');
      //   var result = result;
      // });
 

    // this.dialog.open(ConfirmDialogboxComponent);
    if(event.checked == true){
      this.service.updatecompanyDisable(data.pk_id).subscribe((data:any)=>{
        ;
        this.toastr.success("Company Disable Successfully");
      });
    }
    if(event.checked == false){
      this.service.updatecompanyEnable(data.pk_id).subscribe((data:any)=>{
        ;
        this.toastr.success("Company Enable Successfully");
      });
    }
  }
  onclickAddnew(){
    ;
    // const dialogRef = this.dialog.open(CreatenewcompanyPopupboxComponent, {
    //   width: '60%',
    //   height: '50%',

    // });
    
    
    this.selectedIndex = 1;
    this.clearForm();
  }
  onChnagePasswordclick(data){
    
    const dialogRef = this.dialog.open(ConfirmDialogboxComponent, {
      height: '28%',
      width: '20%',

        data: {Password:data.password}
      });
  
      dialogRef.afterClosed().subscribe(result => {
        
        if(!result){
          return
        }
        if(result != "No"){
         var obj={
           pk_id :data.pk_id,
           email : data.email,
           password : result
         }
         
          this.service.updateuserPassword(obj).subscribe((data:any)=>{
            ;
            alert("Chnage Successfully");
            this.getAllrecords();
           
          });
        }
      });
    
  }
  filter(val: string): string[] {
		return this.countryList.filter(option => option.country_name.toLowerCase().indexOf(val.toLowerCase()) === 0);
  }
  onSearchChange(emailvalue) {
		var k = this.companyeditform.value.email.includes('@')
		if (k == true) {
			this.emailvalidate = this.companyeditform.value.email.includes('.')
			if (this.emailvalidate == true) {
			}
			else {
				this.companyeditform.controls['email'].setErrors({ 'incorrect': true });
			}
		}
  }
  clearForm(){
    this.companyeditform.controls['companyname'].setValue('');
        this.companyeditform.controls['accounttype'].setValue('');
        this.companyeditform.controls['companyaddress'].setValue('');
        this.companyeditform.controls['email'].setValue('');
        this.companyeditform.controls['mobilenumber'].setValue('');
        this.companyeditform.controls['country'].setValue('');
        this.companyeditform.controls['countryCode'].setValue('');
        this.companyeditform.controls['city'].setValue('');
        this.companyeditform.controls['state'].setValue('');
        this.companyeditform.controls['zipcode'].setValue('');
        this.btnHideshow = false;
        this.companyeditform.controls['email'].enable();
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  applyFilter2(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource2.filter = filterValue;
  }
}
