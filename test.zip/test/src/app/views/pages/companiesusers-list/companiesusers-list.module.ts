
// Angular
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
// NgBootstrap
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// Core Module
import { CoreModule } from '../../../core/core.module';
import { PartialsModule } from '../../partials/partials.module';
import { CompaniesusersListComponent } from './companiesusers-list.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core'; 
import { MatButtonModule,MatTabsModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule, MatCardModule, MatIconModule, MatAutocompleteModule } from '@angular/material';
import { MatPaginatorModule,MatDialogModule, MatProgressSpinnerModule, MatSortModule, MatTableModule } from "@angular/material";
import { EmailTemplateComponent } from '../email-template/email-template.component';

// import { ConfirmDialogboxComponent } from '../../../confirm-dialogbox/confirm-dialogbox.component';
@NgModule({
	imports: [MatTableModule,MatAutocompleteModule,MatDialogModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule,FormsModule, ReactiveFormsModule,
        MatButtonModule,MatTabsModule,MatCardModule,MatIconModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatOptionModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		TranslateModule,
		RouterModule.forChild([
			{
				path: '',
				component: CompaniesusersListComponent
			},
		]),
		DragDropModule
	],
	providers: [],
	declarations: [
		CompaniesusersListComponent
	],
	exports: [FormsModule, ReactiveFormsModule,MatTableModule],
	// entryComponents : [ConfirmDialogboxComponent]

})
export class CompaniesusersListModule {
}
