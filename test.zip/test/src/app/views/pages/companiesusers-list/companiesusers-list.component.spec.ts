import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompaniesusersListComponent } from './companiesusers-list.component';

describe('CompaniesusersListComponent', () => {
  let component: CompaniesusersListComponent;
  let fixture: ComponentFixture<CompaniesusersListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompaniesusersListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompaniesusersListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
