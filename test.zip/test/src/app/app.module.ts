// Angular
import { BrowserModule, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
import { APP_INITIALIZER, NgModule ,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GestureConfig, MatProgressSpinnerModule } from '@angular/material';
import { OverlayModule } from '@angular/cdk/overlay';
// Angular in memory
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
// NgBootstrap
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// Perfect Scroll bar
import { PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
// SVG inline
import { InlineSVGModule } from 'ng-inline-svg';
// Env
import { environment } from '../environments/environment';
// Hammer JS
import 'hammerjs';
// NGX Permissions
import { NgxPermissionsModule } from 'ngx-permissions';
// NGRX
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
// State
import { metaReducers, reducers } from './core/reducers';
// Copmponents
import { AppComponent } from './app.component';
// Modules
import { AppRoutingModule } from './app-routing.module';
import { CoreModule } from './core/core.module';
// Partials
import { PartialsModule } from './views/partials/partials.module';
// Metronic Services
import { DataTableService, FakeApiService } from './core/_base/metronic';
// Layout Services
import {  LayoutRefService,  PageConfigService, SplashScreenService, LayoutConfigService, //ng build --prod --build-optimizer    
	KtDialogService } from './core/_base/layout';
// Auth
import { AuthModule } from './views/pages/auth/auth.module';

import { AuthService } from './core/auth';
import { UserService } from './core/services';


// CRUD
import { HttpUtilsService, LayoutUtilsService, TypesUtilsService } from './core/_base/crud';
// Config
import { LayoutConfig } from './core/_config/default/layout.config';
// Highlight JS
import { HIGHLIGHT_OPTIONS, HighlightLanguage } from 'ngx-highlightjs';

import { HashLocationStrategy, LocationStrategy } from '@angular/common';
//import { DragDropModule } from '@angular/cdk/drag-drop';
import { ToastrModule } from 'ngx-toastr';
import { FormsModule } from '@angular/forms';
import { DataService } from './views/data.service';
import {  ReactiveFormsModule } from '@angular/forms';
import { DataRoutingService } from '../app/views/dataRouting.service';

import { HTTP_INTERCEPTORS } from '@angular/common/http';

import {SocialLoginModule} from 'ng4-social-login'
import {AgmCoreModule} from '@agm/core';
import { FilterServiceService } from './views/filter-service.service';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
	wheelSpeed: 0.5,
	swipeEasing: true,
	minScrollbarLength: 40,
	maxScrollbarLength: 300,
};
export function initializeLayoutConfig(appConfig: LayoutConfigService) {
	// initialize app by loading default demo layout config
	return () => {
		if (appConfig.getConfig() === null) {
			appConfig.loadConfigs(new LayoutConfig().configs);
		}
	};
}

export function hljsLanguages(): HighlightLanguage[] {
	return [
		// {name: 'typescript', func: typescript},
		// {name: 'scss', func: scss},
		// {name: 'xml', func: xml},
		// {name: 'json', func: json}
	];
}

@NgModule({
	declarations: [  AppComponent,//CreateUserComponent
		// EmailTemplateComponent
	],
	schemas:  [ CUSTOM_ELEMENTS_SCHEMA ],
	imports: [//QuillModule,
		//RichTextEditorAllModule,
		AgmCoreModule.forRoot({
			apiKey: 'AIzaSyAc6HbqpQfHx_SEUcGRHYiQ-tDOoNqtb0g'}),
		// Ng5SliderModule,
		// MatRadioModule,
		// MatSliderModule,
		SocialLoginModule,
		ReactiveFormsModule,
		FormsModule,
		MatProgressSpinnerModule,
		BrowserAnimationsModule,
		BrowserModule.withServerTransition({ appId: 'serverApp' }),
		AppRoutingModule,
		HttpClientModule,
		environment.isMockEnabled ? HttpClientInMemoryWebApiModule.forRoot(FakeApiService, {
			passThruUnknownUrl: true,
			dataEncapsulation: false
		}) : [],
		NgxPermissionsModule.forRoot(),
		PartialsModule,
		CoreModule,
		OverlayModule,
		StoreModule.forRoot(reducers, {metaReducers}),
		EffectsModule.forRoot([]),
		StoreRouterConnectingModule.forRoot({stateKey: 'router'}),
		StoreDevtoolsModule.instrument(),
		AuthModule.forRoot(),
		//DiamondModule,
		//DiamondRetailerModule,
		NgbModule,
		TranslateModule.forRoot(),
		MatProgressSpinnerModule,
		InlineSVGModule.forRoot(),
		//DragDropModule,
		ToastrModule.forRoot(
			// {
			// timeOut: 2000,
			// positionClass: 'toast-top-right',
			// preventDuplicates: true,
			// }
			),
	],
	exports: [],
	providers: [
		//ExcelService,
		FilterServiceService,
		DataService,
		AuthService,
		UserService,
		LayoutConfigService,
		LayoutRefService,
		DataRoutingService,
		//MenuConfigService,
		PageConfigService,
		KtDialogService,
		DataTableService,
		SplashScreenService,
		{
			provide: PERFECT_SCROLLBAR_CONFIG,
			useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
		},
		{
			provide: HAMMER_GESTURE_CONFIG,
			useClass: GestureConfig
		},
		// {
		// 	// layout config initializer
		// 	provide: APP_INITIALIZER,
		// 	useFactory: initializeLayoutConfig,
		// 	deps: [LayoutConfigService], multi: true
		// },
		{
			provide: HIGHLIGHT_OPTIONS,
			useValue: {languages: hljsLanguages}
		},
		// template services
		//SubheaderService,
		// MenuHorizontalService,
		// MenuAsideService,
		HttpUtilsService,
		TypesUtilsService,
		LayoutUtilsService,
		// To solve issue of 404 on page refresh
		{ provide: LocationStrategy, useClass: HashLocationStrategy },
	],
	bootstrap: [
	AppComponent
	],
	entryComponents:[]
})
export class AppModule {
}
