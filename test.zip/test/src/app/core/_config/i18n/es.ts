// Spain
export const locale = {
	lang: 'es',
	data: {
		TRANSLATOR: {
			SELECT: 'Elige tu idioma',
		},
		MENU: {
			NEW: 'nuevo',
			ACTIONS: 'Comportamiento',
			CREATE_POST: 'Crear nueva publicación',
			PAGES: 'Pages',
			FEATURES: 'Caracteristicas',
			APPS: 'Aplicaciones',
			DASHBOARD: 'Tablero',
			MYPROFILE:'Mi perfil',
			PROFILE:'Perfil',
			EMAILTEMPLATE:'Plantilla de correo electrónico',
			COMPANYANDUSERS:"Empresa y Usuarios",
			DIAMONDUPLOADHISTORY:'Historial de carga de diamantes',
		},
		AUTH: {
			GENERAL: {
				OR: 'O',
				SUBMIT_BUTTON: 'Enviar',
				NO_ACCOUNT: 'No tienes una cuenta?',
				SIGNUP_BUTTON: 'Regístrate',
				FORGOT_BUTTON: 'Se te olvidó tu contraseña',
				UPDATE_BUTTON:'Actualizar',
				ADDNEW_BUTTON:'Añadir nuevo',
				BACK_BUTTON: 'Espalda',
				PRIVACY: 'Intimidad',
				LEGAL: 'Legal',
				CONTACT: 'Contacto',
			},
			LOGIN: {
				TITLE: 'Crear una cuenta',
				BUTTON: 'Registrarse',
			},
			FORGOT: {
				TITLE: 'Contraseña olvidada?',
				DESC: 'Ingrese su correo electrónico para restablecer su contraseña',
				SUCCESS: 'Your account has been successfully reset.'
			},
			REGISTER: {
				TITLE: 'Sign Up',
				DESC: 'Enter your details to create your account',
				SUCCESS: 'Your account has been successfuly registered.',
				UPDATE: 'Tu cuenta ha sido actualizada exitosamente.',
			},
			RESENDCODE: {
				TITLE: 'Resend verification code',
				DESC: 'Enter your email to resend verification code',
				SUCCESS: 'Your password reset code has been sent successfully.'
			},
			RESETPASSWORD:{
				VERIFYCODE:'Por favor revise su correo electrónico para el código de verificación.',
				SOMETHINGWRONG:'Algo mal, inténtalo de nuevo.',
				RESETSUCCESS:'Su contraseña se restablece con éxito.',
				CHANGEPASS:'Cambiar contraseña con verificación',
				VERIFYCODETITLE:'Código de verificación',
				NEWPASS:'Nueva contraseña',
				CHANGEPASSTITLE:'Cambia la contraseña',
				GETVERICODE:'Obtener código de verificación',
			},
			INPUT: {
				PERSONALDETAIL: 'Detalle personal',
				EMAIL: 'Email',
				FULLNAME: 'Fullname',
				PASSWORD: 'Password',
				CONFIRM_PASSWORD: 'Confirm Password',
				USERNAME: 'Usuario',
				COMPANYNAME:'nombre de empresa',
				NAME:'Nombre',
				CONTACTNO:'Contacto No.',
				ACCOUNTTYPE:'Tipo de cuenta',
				ADDRESS:'Dirección',
				CITY:'Ciudad',
				STATE:'Estado',
				COUNTRY:'País', 
				ZIPCODE:'Código postal',
				LANGUAGE:'Idioma',
				CURRENCY:'Moneda',
				EMAILTYPE:'Tipo de correo electrónico',
				EMAILSUBJECT:'Asunto del email',
				EMAILBODY:'Cuerpo del correo electronico',
				FIRSTNAME:'Nombre de pila',
                LASTNAME:'Apellido',
			},
			VALIDATION: {
				INVALID: '{{name}} is not valid',
				REQUIRED: '{{name}} is required',
				MIN_LENGTH: '{{name}} minimum length is {{min}}',
				AGREEMENT_REQUIRED: 'Accepting terms & conditions are required',
				NOT_FOUND: 'The requested {{name}} is not found',
				INVALID_LOGIN: 'The login detail is incorrect',
				REQUIRED_FIELD: 'Required field',
				MIN_LENGTH_FIELD: 'Minimum field length:',
				MAX_LENGTH_FIELD: 'Maximum field length:',
				INVALID_FIELD: 'Field is not valid',
				EMAILID_FIELD: 'Email-id is not valid',
				PASS_FIELD:'Password contain 8 char with lower/uppper & one numeric and symbol char.',
			}
		},
		ECOMMERCE: {
			COMMON: {
				SELECTED_RECORDS_COUNT: 'Selected records count: ',
				ALL: 'All',
				SUSPENDED: 'Suspended',
				ACTIVE: 'Active',
				FILTER: 'Filter',
				BY_STATUS: 'by Status',
				BY_TYPE: 'by Type',
				BUSINESS: 'Business',
				INDIVIDUAL: 'Individual',
				SEARCH: 'Search',
				IN_ALL_FIELDS: 'in all fields'
			},
			ECOMMERCE: 'eCommerce',
			CUSTOMERS: {
				CUSTOMERS: 'Customers',
				CUSTOMERS_LIST: 'Customers list',
				NEW_CUSTOMER: 'New Customer',
				DELETE_CUSTOMER_SIMPLE: {
					TITLE: 'Customer Delete',
					DESCRIPTION: 'Are you sure to permanently delete this customer?',
					WAIT_DESCRIPTION: 'Customer is deleting...',
					MESSAGE: 'Customer has been deleted'
				},
				DELETE_CUSTOMER_MULTY: {
					TITLE: 'Customers Delete',
					DESCRIPTION: 'Are you sure to permanently delete selected customers?',
					WAIT_DESCRIPTION: 'Customers are deleting...',
					MESSAGE: 'Selected customers have been deleted'
				},
				UPDATE_STATUS: {
					TITLE: 'Status has been updated for selected customers',
					MESSAGE: 'Selected customers status have successfully been updated'
				},
				EDIT: {
					UPDATE_MESSAGE: 'Customer has been updated',
					ADD_MESSAGE: 'Customer has been created'
				}
			}
		},
		SUBHEADER:{
			TODAY:'Hoy',
			MONTH:'Mes',
			YEAR:'Año',
			YESTERDAY:'Ayer',
			LAST7DAYS:'Los últimos 7 días',
			LAST30DAYS:'Últimos 30 días',
			THISMONTH:'Este mes',
			LASTMONTH:'El mes pasado',
			CUSTOMRANGE:'Rango personalizado',
			MESSAGES:'mensajes',
			MYPROFILE:'Mi perfil',
			SUBTEXTPROFILE:'Configuraciones de cuenta y más',
			SIGNOUT:'desconectar',
			HI:'Hola',
			SEARCH:'Buscar...',
			USERNOTE:'Notificaciones de usuario',
			NEW:'nuevo',
			ALERTS:'Las alertas',
			EVENTS:'Eventos',
			LOGS:'Troncos',
			QUICKACTIONS:'Acciones rápidas del usuario',
			TASKSPENDING:'tareas pendientes',
			QUICKPANEL:'Panel rapido',
		},
		DASHBOARDTEXT:{
			DAILYSALES:'Ventas diarias',
			PROFITSHARE:'División de ganancias',
			MEMBERPROFIT:'Beneficio del miembro',
			ORDERS:'Pedidos',
			MONTHLYINCOME:'Ingreso mensual',
			TAXESINFO:'Información de impuestos', 
		},
		TAB:{
			TEMPLATEDETAILS:'Detalles de la plantilla',
			TEMPLATELIST:'Lista de plantillas',
			COMPANIES:'Compañias',
			COMPANYDETAIL:'Detalle de la empresa',
			USERS:'Usuarios'


		}
	}
};
