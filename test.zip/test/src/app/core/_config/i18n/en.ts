// USA
export const locale = {
	lang: 'en',
	data: {
		TRANSLATOR: {
			SELECT: 'Select your language',
		},
		MENU: {
			NEW: 'new',
			ACTIONS: 'Actions',
			CREATE_POST: 'Create New Post',
			PAGES: 'Pages',
			FEATURES: 'Features',
			APPS: 'Apps',
			DASHBOARD: 'Dashboard',
			MYPROFILE:'My Profile',
			PROFILE:'Profile',
			DIAMONDUPLOADHISTORY:'Diamond Upload History',
			COMPANYANDUSERS:'Company & Users',
			EMAILTEMPLATE:'Email Template'

		},
		AUTH: {
			GENERAL: {
				OR: 'Or',
				SUBMIT_BUTTON: 'Submit',
				NO_ACCOUNT: 'Don\'t have an account?',
				SIGNUP_BUTTON: 'Sign Up',
				FORGOT_BUTTON: 'Forgot Password',
				UPDATE_BUTTON:'Update',
				ADDNEW_BUTTON:'Add New',
				BACK_BUTTON: 'Back',
				PRIVACY: 'Privacy',
				LEGAL: 'Legal',
				CONTACT: 'Contact',
			},
			LOGIN: {
				TITLE: 'Login Account',
				BUTTON: 'Sign In',
			},
			FORGOT: {
				TITLE: 'Forgotten Password?',
				DESC: 'Enter your email to reset your password',
				SUCCESS: 'Your account has been successfully reset.'
			},
			REGISTER: {
				TITLE: 'Sign Up',
				DESC: 'Enter your details to create your account',
				SUCCESS: 'Your account has been successfuly registered.',
				UPDATE: 'Your account has been updated successfuly.',
			},
			RESENDCODE: {
				TITLE: 'Resend verification code',
				DESC: 'Enter your email to resend verification code',
				SUCCESS: 'Your password reset code has been sent successfully.'
			},
			RESETPASSWORD:{
				VERIFYCODE:'Please check your email for verification code.',
				SOMETHINGWRONG:'Something wrong, Try again.',
				RESETSUCCESS:'Your password is reset successfully.',
				CHANGEPASS:'Change Password with verification',
				VERIFYCODETITLE:'Verification Code',
				NEWPASS:'New Password',
				CHANGEPASSTITLE:'Change Password',
				GETVERICODE:'Get Verification Code',
			},
			INPUT: {
				PERSONALDETAIL: 'Personal Detail',
				EMAIL: 'Email',
				FULLNAME: 'Fullname',
				PASSWORD: 'Password',
				CONFIRM_PASSWORD: 'Confirm Password',
				USERNAME: 'Username',
				COMPANYNAME:'Company Name',
				NAME:'Name',
				CONTACTNO:'Contact No.',
				ACCOUNTTYPE:'Account Type',
				ADDRESS:'Address',
				CITY:'City',
				STATE:'State',
				COUNTRY:'Country',
				ZIPCODE:'Zip Code',
				LANGUAGE:'Language',
				CURRENCY:'Currency',
				EMAILTYPE:'Email Type',
				EMAILSUBJECT:'Email Subject',
				EMAILBODY:'Email Body',
				FIRSTNAME:'First Name',
                LASTNAME : 'Last Name',
			},
			VALIDATION: {
				INVALID: '{{name}} is not valid',
				REQUIRED: '{{name}} is required',
				MIN_LENGTH: '{{name}} minimum length is {{min}}',
				AGREEMENT_REQUIRED: 'Accepting terms & conditions are required',
				NOT_FOUND: 'The requested {{name}} is not found',
				INVALID_LOGIN: 'The login detail is incorrect',
				REQUIRED_FIELD: 'Required field',
				MIN_LENGTH_FIELD: 'Minimum field length:',
				MAX_LENGTH_FIELD: 'Maximum field length:',
				INVALID_FIELD: 'Field is not valid',
				EMAILID_FIELD: 'Email-id is not valid',
				PASS_FIELD:'Password contain 8 char with lower/uppper & one numeric and symbol char.',
			}
		},
		ECOMMERCE: {
			COMMON: {
				SELECTED_RECORDS_COUNT: 'Selected records count: ',
				ALL: 'All',
				SUSPENDED: 'Suspended',
				ACTIVE: 'Active',
				FILTER: 'Filter',
				BY_STATUS: 'by Status',
				BY_TYPE: 'by Type',
				BUSINESS: 'Business',
				INDIVIDUAL: 'Individual',
				SEARCH: 'Search',
				IN_ALL_FIELDS: 'in all fields'
			},
			ECOMMERCE: 'eCommerce',
			CUSTOMERS: {
				CUSTOMERS: 'Customers',
				CUSTOMERS_LIST: 'Customers list',
				NEW_CUSTOMER: 'New Customer',
				DELETE_CUSTOMER_SIMPLE: {
					TITLE: 'Customer Delete',
					DESCRIPTION: 'Are you sure to permanently delete this customer?',
					WAIT_DESCRIPTION: 'Customer is deleting...',
					MESSAGE: 'Customer has been deleted'
				},
				DELETE_CUSTOMER_MULTY: {
					TITLE: 'Customers Delete',
					DESCRIPTION: 'Are you sure to permanently delete selected customers?',
					WAIT_DESCRIPTION: 'Customers are deleting...',
					MESSAGE: 'Selected customers have been deleted'
				},
				UPDATE_STATUS: {
					TITLE: 'Status has been updated for selected customers',
					MESSAGE: 'Selected customers status have successfully been updated'
				},
				EDIT: {
					UPDATE_MESSAGE: 'Customer has been updated',
					ADD_MESSAGE: 'Customer has been created'
				}
			}
		},
		SUBHEADER:{
			TODAY:'Today',
			MONTH:'Month',
			YEAR:'Year',
			YESTERDAY:'Yesterday',
			LAST7DAYS:'Last 7 Days',
			LAST30DAYS:'Last 30 Days',
			THISMONTH:'This Month',
			LASTMONTH:'Last Month',
			CUSTOMRANGE:'Custom Range',
			MESSAGES:'messages',
			MYPROFILE:'My Profile',
			SUBTEXTPROFILE:'Account settings and more',
			SIGNOUT:'SIGN OUT',
			HI:'Hi',
			SEARCH:'Search...',
			USERNOTE:'User Notifications',
			NEW:'new',
			ALERTS:'Alerts',
			EVENTS:'Events',
			LOGS:'Logs',
			QUICKACTIONS:'User Quick Actions',
			TASKSPENDING:'tasks pending',
			QUICKPANEL:'Quick panel',
		},
		DASHBOARDTEXT:{
			DAILYSALES:'Daily Sales',
			PROFITSHARE:'Profit Share',
			MEMBERPROFIT:'Member Profit',
			ORDERS:'Orders',
			MONTHLYINCOME:'Monthly Income',
			TAXESINFO:'Taxes info', 
		},
		TAB:{
			TEMPLATEDETAILS:'Template Details',
			TEMPLATELIST:'Template List',
			COMPANIES:'Companies',
			COMPANYDETAIL:'Company Detail',
			USERS:'Users'


		}
	}
};
