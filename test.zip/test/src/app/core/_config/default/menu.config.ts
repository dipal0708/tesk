export class MenuConfig {
	public defaults: any = {
		header: {
			self: {},
			'items': [
				{
					'title': 'Dashboard',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left',
					'page': 'dashboard',
					'id':'diamondDashboard',			
				},
				{
					'title': 'Search',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left',
					//'page': 'diamondsearch/alldiamondSearch',
					'id':'diamondSearch'				
				},
				{
					'title': 'Catalog',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left',
					'page': 'diamondsearch/landingPage',
					'id':'diamondCatalog'				
				},
				{
					'title': 'Retailers',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class':'Menubutton button',/// 'kt-menu__item--active',
					'alignment': 'left',
					'page': 'diamondRetailer/myRetailer',
					'id':'diamondRetailers'			
				},
				{
					'title': 'Reports',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left', 
					'page': 'diamondReport/diamondReport',
					'id':'diamondReports'	
				},
				{
					'title': 'Marketing',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left', 	
					'page': 'diamondMarketing/uploadmarketingmaterial',	
					'id':'diamondMarketing'
				},
				{
					'title': 'PO',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left',
					'page': 'diamondPurchaseOrder/diamondpurchaseorder',
					'id':'diamondPO'
				}	]
		},
		//--------------------------------------------------------JewelMenu
		jewelheader: {
			self: {},
			'items': [
				{
					'title': 'Dashboard',
					'root': true,	
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left',
					'page': 'dashboard',
					'id':'jewelryDashboard'					
				},
				{
					'title': 'Search',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left',
					'page': 'diamondsearch/alldiamondSearch',
					'id':'jewelrySearch'						
				},
				{
					'title': 'Catalog',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left',
					'page': 'diamondsearch/landingPage',
					'id':'jewelryCatalog'		
				},
				{
					'title': 'Retailers',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class':'Menubutton button',/// 'kt-menu__item--active',
					'alignment': 'left',
					'page': 'diamondRetailer/myRetailer',
					'id':'jewelryRetailers'		
				},
				{
					'title': 'PO',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left', 	
					'id':'jewelryPO'
				},
				{
					'title': 'Reports',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left', 	
					'id':'jewelryReports'
				},
				{
					'title': 'Marketing',
					'root': true,
					'icon-': 'flaticon-add',
					'toggle': 'click',
					'custom-class': 'Menubutton button',
					'alignment': 'left', 
					'id':'jewelryMarketing'
				},
				]
		},
		// -------------------------------------------------------- Old Menu
		aside: {
			self: {},
			items: [
				// {
				// 	title: 'Dashboard',
				// 	root: true,
				// 	icon: 'flaticon2-architecture-and-city',
				// 	page: 'dashboard',
				// 	translate: 'MENU.DASHBOARD',
				// 	bullet: 'dot',
				// },
				// {section: 'Profile',translate:'MENU.PROFILE'},
				{
					title: 'My Profile',
					root: true,
					icon: 'flaticon2-user',
					bullet: 'dot',
					page: 'profile',
					translate: 'MENU.MYPROFILE',
				},
				{
					title: 'Email Template',
					root: true,
					icon: 'flaticon2-mail-1',
					bullet: 'dot',
					page: 'emailTemplate',
					translate: 'MENU.EMAILTEMPLATE',
				},
				{
					title: 'Company & Users',
					root: true,
					icon: 'flaticon2-add',
					bullet: 'dot',
					page: 'companiesuserslist',
					translate: 'MENU.COMPANYANDUSERS',
				},
				{
					title: 'Create User',
					root: true,
					icon: 'flaticon2-user',
					bullet: 'dot',
					page: 'diamondsearch/createuser',
					translate: 'Create FTP User',
				}
				// {
				// 	title: 'Diamond Upload History',
				// 	root: true,
				// 	icon: 'flaticon2-rocket-2',
				// 	bullet: 'dot',
				// 	page: 'diamonduploadhistory',
				// 	translate: 'MENU.DIAMONDUPLOADHISTORY',
				// },
				// {
				// 	title: 'Diamond',
				// 	root: true,
				// 	icon: 'flaticon2-menu-1',
				// 	submenu: [{
				// 		title: 'Diamond Search',
				// 		root: true,
				// 		icon: 'flaticon2-search',
				// 		bullet: 'dot',
				// 		page: 'diamondsearch',
				// 		translate: 'Diamond Search',						
				// 		},
				// 		{
				// 		title: 'Create User',
				// 		root: true,
				// 		icon: 'flaticon2-user',
				// 		bullet: 'dot',
				// 		page: 'diamondsearch/createuser',
				// 		translate: 'Create User',
				// 		}],
				// },	
			]
		},
		//----------------------------------------------------------------------------------Dashboard Manu
		DashboardMenu: {
			self: {},
			items: [
				{
					title: 'Dashboard',
					root: true,
					icon: 'flaticon2-architecture-and-city',
					page: 'dashboard',
					translate: 'MENU.DASHBOARD',
					bullet: 'dot',
				}
			]
			},

			//-----------------------------------------------------------------------Reports Menu
			// ReportsMenu: {
			// 	self: {},
			// 	items: [
			// 		{
			// 			title: 'Diamond Reports',
			// 			root: true,
			// 			icon: 'flaticon2-architecture-and-city',
			// 			translate: 'Diamond Reports',
			// 			bullet: 'dot',
			// 		},
			// 	]
			// 	},
//----------------------------------------------------------------------- Marketing Menu
				MarketingMenu: {
					self: {},
					items: [
						{
							title: 'Upload Marketing Materials',
							root: true,
							icon: 'flaticon2-architecture-and-city',
							translate: 'Upload Marketing Materials',
							bullet: 'dot',
							page:'diamondMarketing/uploadmarketingmaterial'
						},
						{
							title: 'Appointments',
							root: true,
							icon: 'flaticon2-architecture-and-city',
							translate: 'Appointments',
							bullet: 'dot',
							page:'diamondMarketing/appointments'
						},
						
					]
					},

		// ---------------------------------------------------------------------------------Diamond Menu
		DiamondMenu: {
			self: {},
			items: [
				{
					title: 'Diamond',
					root: true,
					icon: 'flaticon2-menu-4',
					bullet: 'dot',
					page: 'diamondsearch/landingPage',
					translate: 'Diamond',
				},
				{
					title: 'View my Diamond',
					root: false,
					icon: 'flaticon2-menu-1',
					bullet: 'dot',
					translate: 'View my Diamond',
					submenu: [{
								title: 'View Natural Diamond',
								root: true,
								bullet: 'dot',
								page: 'diamondsearch/diamondsearchComp',
								translate: 'View Natural Diamond',						
								},
								{
								title: 'View Lab Diamond',
								root: true,
								bullet: 'dot',
								page: 'diamondsearch/labDiamond',
								translate: 'View Lab Diamond',
								 },
								 {
								title: 'View Color Diamond',
								root: true,
								bullet: 'diamond',
								page: 'diamondsearch/colorDiamond',
								translate: 'View Color Diamond',
								}],
				},
				{
					title: 'Upload Diamond History',
					root: true,
					icon: 'flaticon2-checking',
					bullet: 'dot',
					page: 'diamondsearch/diamonduploadhistory',
					translate: 'Upload Diamond History',
				},
				{
					title: 'Add Single Diamond',
					root: true,
					icon: 'flaticon2-add',
					bullet: 'dot',
					page: 'diamondsearch/addDiamond',
					translate: 'Add Single Diamond',
				},
				{
					title: 'Upload Diamond File',
					root: true,
					icon: 'flaticon2-paper-plane',
					bullet: 'dot',
					page: 'diamondsearch/diamondImport',
					translate: 'Upload Diamond File',
				},
				{
					title: 'Diamond Mapping',
					root: true,
					icon: 'flaticon2-map',
					bullet: 'dot',
					page: 'diamondsearch/diamondMapping',
					translate: 'Diamond Mapping',
				},
				{
					title: 'Manage FTP Credentials',
					root: true,
					icon: 'flaticon2-lock',
					bullet: 'dot',
					page: 'diamondsearch/createuser',
					translate: 'Manage FTP Credentials',
				},	
				{
					title: 'Diamond Group Discount',
					root: true,
					icon: 'flaticon2-lock',
					bullet: 'dot',
					translate: 'Diamond Group Discount',
					submenu: [{
						title: 'Diamond Group Discount',
						root: true,
						bullet: 'dot',
						page: 'diamondsearch/retailergroupdiscount',
						translate: 'Diamond Group Discount',						
						},
						 {
						title: 'Retailer Group',
						root: true,
						bullet: 'diamond',
						page: 'diamondsearch/retailergroup',
						translate: 'Retailer Group',
						}],
				},
			]
		},
		// -------------------------------------------
		DiamonRetailerMenu: {
			self: {},
			items: [
				{
					title: 'Manage Retailer & Permition',
					root: true,
					icon: 'flaticon2-user',
					bullet: 'dot',
					page:'diamondRetailer/myRetailer',
					translate: 'Manage Retailer & Permition',
					submenu: [{
						title: 'My Retailers',
						root: true,
						icon: 'flaticon2-user',
						bullet: 'dot',
						page: 'diamondRetailer/myRetailer',
						translate: 'My Retailers',						
						},
						{
						title: 'All Retailers',
						root: true,
						icon: 'flaticon2-search',
						bullet: 'dot',
						page: 'diamondRetailer/allRetailers',
						translate: 'All Retailers',
						 }],
				},
				{
					title: 'Pending Retailer Request',
					root: true,
					icon: 'flaticon2-mail-1',
					bullet: 'dot',
					page:'diamondRetailer/retailerRequest',
					translate: 'Pending Retailer Request',
				},
				{
					title: 'Conversation',
					root: true,
					icon: 'flaticon2-talk',
					bullet: 'dot',
					page:'diamondRetailer/conversation',
					translate: 'Conversation',
				},

				
				
			]
		},

		// ---------------------------------------------------------------------------------
		SearchMenu: {
			self: {},
			items: [
				{
					title: 'Natural Diamond',
					root: true,
					icon: 'flaticon2-search',
					bullet: 'dot',
					translate: 'Natural Diamond Search',
					page: 'diamondsearch/alldiamondSearch'
				},
				{
					title: 'Lab Diamond',
					root: true,
					icon: 'flaticon2-search',
					bullet: 'dot',
					translate: 'Lab Diamond Search',
					page: 'diamondsearch/alllabDiamond'
				},
				{
					title: 'Color Diamond',
					root: true,
					icon: 'flaticon2-search',
					bullet: 'dot',
					translate: 'Color Diamond Search',
					page: 'diamondsearch/allcolorDiamond'

				},
				// {
				// 	title: 'Diamond Search',
				// 	root: true,
				// 	icon: 'flaticon2-search',
				// 	page: 'diamondsearch/alldiamondSearch',
				// 	bullet: 'dot',
				// 	translate: 'Diamond Search',
				// },
				{
					title: 'Jewelry Search',
					root: true,
					icon: 'flaticon2-search',
					bullet: 'dot',
					translate: 'Jewelry Search',
				},
				{
					title: 'Watches Search',
					root: true,
					icon: 'flaticon2-search',
					bullet: 'dot',
					translate: 'Watches Search',
				},
			]
		},

		ReportsMenu: {
			self: {},
			items: [
				{
					title: 'Diamond Charts',
					root: true,
					icon: 'flaticon2-line-chart',
					bullet: 'dot',
					translate: 'Diamond Charts',
					page: 'diamondReport/diamondReport'
				},
				{
					title: 'Retailer Search Report',
					root: true,
					icon: 'flaticon2-list-3',
					bullet: 'dot',
					translate: 'Retailer Search Report',
					page: 'diamondReport/diamondretailerReport'
				},
				{
					title: 'Extended Diamond Chart',
					root: true,
					// icon: 'fa fa-genderless kt-font-danger',
					icon: 'flaticon2-poll-symbol',
					bullet: 'dot',
					translate: 'Extended Diamond Chart',
					page: 'diamondReport/extendedDiamondReport'
				},
				{
					title: 'Diamond Clarity Report',
					root: true,
					icon: 'flaticon2-pie-chart',
					bullet: 'dot',
					translate: 'Diamond Clarity Report',
					page: 'diamondReport/diamondclarityReport'
				},
				{
					title: 'Diamond Color Report',
					root: true,
					icon: 'flaticon2-pie-chart',
					bullet: 'dot',
					translate: 'Diamond Color Report',
					page: 'diamondReport/diamondcolorReport'
				},
				{
					title: 'Diamond Cut Grade Report',
					root: true,
					icon: 'flaticon2-pie-chart',
					bullet: 'dot',
					translate: 'Diamond Cut Grade Report',
					page: 'diamondReport/diamondcutgradeReport'
				},
				{
					title: 'Diamond Certificate Report',
					root: true,
					icon: 'flaticon2-pie-chart',
					bullet: 'dot',
					translate: 'Diamond Certificate Report',
					page: 'diamondReport/diamondcertificateReport'
				},
				{
					title: 'Diamond Shape Report',
					root: true,
					icon: 'flaticon2-pie-chart',
					bullet: 'dot',
					translate: 'Diamond Shape Report',
					page: 'diamondReport/diamondshapeReport'
				},
				{
					title: 'Diamond Size Report',
					root: true,
					icon: 'flaticon2-pie-chart',
					bullet: 'dot',
					translate: 'Diamond Size Report',
					page: 'diamondReport/diamondsizeReport'
				}
			]
		},
		POsMenu: {
			self: {},
			items: [
				{
					title: 'Purchase Order',
					root: true,
					icon: 'flaticon2-user',
					bullet: 'dot',
					translate: 'Purchase Order',
					page:'diamondPurchaseOrder/diamondpurchaseorder'
				},
				{
					title: 'History',
					root: true,
					icon: 'flaticon2-mail-1',
					bullet: 'dot',
					translate: 'History',
					page:'diamondPurchaseOrder/diamondpurchaseorderhistory'
				}
			]
		},
//---------------------------------------------------------------------------- JewelryMenu ------------------------------------------
		

JewelryReportsMenu: {
	self: {},
	items: [
		{
			title: 'Jewelry Chart Report',
			root: true,
			icon: 'flaticon2-user',
			bullet: 'dot',
			translate: 'Jewelry Chart Report',
			page:'jewelleryreport/JewelryChartReport'
		},
		{
			title: 'Jewelry Category Report',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Jewelry Category Report',
			page:'jewelleryreport/JewelryCategoryReport'
		},
		{
			title: 'Jewelry Metal Type Report',
			root: true,
			icon: 'flaticon2-user',
			bullet: 'dot',
			translate: 'Jewelry Metal Type Report',
			page:'jewelleryreport/JewelryMetalTypeReport'
		},
		{
			title: 'Jewelry Price Report',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Jewelry Price Report',
			page:'jewelleryreport/JewelryPriceReport'
		}
		,
		{
			title: 'Jewelry Retailer Click Report',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Jewelry Retailer Click Report',
			page:'jewelleryreport/JewelryRetailerClickReport'
		}
		,
		{
			title: 'Location Activity',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Location Activity',
			//page:'jewelleryreport/JewelryPriceReport'
		},
		{
			title: 'Add T0 Wish List Report',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Add TO Wish List Report',
			page:'jewelleryreport/AddToWishReport'
		}
	]
},

JewelryCatalogsMenu: {
	self: {},
	items: [
		{
			title: 'Jewellery',
			root: true,
			// icon: 'flaticon-eye',
			bullet: 'dot',
			translate: 'Jewellery',
			page:'jewelleryproduct/viewmyproduct',
			submenu:[{
				title: 'View My Product',
				root: true,
				
				bullet: 'dot',
				translate: 'View My Product',
				page:'jewelleryproduct/viewmyproduct'
			},
			{
				title: 'Upload History',
				root: true,
				
				bullet: 'dot',
				translate: 'Jewelry Category Report',
				page:'jewelleryproduct/jewelryuploadhistory'
			},
			{
				title: 'Add Product',
				root: true,
				
				bullet: 'dot',
				translate: 'Add Product',
				page:'jewelleryproduct/jewelryaddproduct'
			},
			{
				title: 'Upload File',
				root: true,
				
				bullet: 'dot',
				translate: 'Upload File',
				page:'jewelleryproduct/jewelryuploadfile'
			},
			{
				title: 'Data Mapping',
				root: true,
				
				bullet: 'dot',
				translate: 'Data Mapping',
				page:'',
				submenu:[{
					title: 'Essentials',
					root: true,
					
					bullet: 'dot',
					translate: 'Essentials',
					page:'jewelleryproduct/jewelrydatamapping'
				},
				{
					title: 'Item Identity',
					root: true,
					
					bullet: 'dot',
					translate: 'Item Identity',
					page:'jewelleryproduct/jewelrydatamapping'
				},
				{
					title: 'Configurable Product',
					root: true,
					
					bullet: 'dot',
					translate: 'Configurable Product',
					page:'jewelleryproduct/jewelrydatamapping'
				},
				{
					title: 'Item Details',
					root: true,
					
					bullet: 'dot',
					translate: 'Item Details',
					page:'jewelleryproduct/jewelrydatamapping'
				},
				{
					title: 'Item Pricing',
					root: true,
					
					bullet: 'dot',
					translate: 'Item Pricing',
					page:'jewelleryproduct/jewelrydatamapping'
				},
				{
					title: 'Relational Pricing',
					root: true,
					
					bullet: 'dot',
					translate: 'Relational Pricing',
					page:'jewelleryproduct/jewelrydatamapping'
				},
				{
					title: 'Cost Basis Pricing',
					root: true,
					
					bullet: 'dot',
					translate: 'Cost Basis Pricing',
					page:'jewelleryproduct/jewelrydatamapping'
				}
			,{
				title: 'Item-Promo Special',
				root: true,
				
				bullet: 'dot',
				translate: 'Item-Promo Special',
				page:'jewelleryproduct/jewelrydatamapping'
			},
			{
				title: 'Item Media',
				root: true,
				
				bullet: 'dot',
				translate: 'Item Media',
				page:'jewelleryproduct/jewelrydatamapping'
			},
			{
				title: 'Item Sizing',
				root: true,
				
				bullet: 'dot',
				translate: 'Item Sizing',
				page:'jewelleryproduct/jewelrydatamapping'
			},
			{
				title: 'GemStone Details',
				root: true,
				
				bullet: 'dot',
				translate: 'GemStone Details',
				page:'jewelleryproduct/jewelrydatamapping'
			},
			{
				title: 'semi Mounts & Ring Build',
				root: true,
				
				bullet: 'dot',
				translate: 'semi Mounts & Ring Build',
				page:'jewelleryproduct/jewelrydatamapping'
			},
			{
				title: 'Watch Details',
				root: true,
				
				bullet: 'dot',
				translate: 'Watch Details',
				page:'jewelleryproduct/jewelrydatamapping'
			}]
			},
			{
				title: 'Manage Collection',
				root: true,
				
				bullet: 'dot',
				translate: 'Manage Collection',
				page:'jewelleryproduct/jewelrymanagecollection'
			},
			{
				title: 'Manage FTP',
				root: true,
				
				bullet: 'dot',
				translate: 'Manage FTP',
				page:'jewelleryproduct/jewelrymanageftp'
			}
		]
		},
		
		{
			title: 'Ring Builder',
			root: true,
			// icon: 'flaticon2-user',
			bullet: 'dot',
			translate: 'Ring Builder',
			page:'jewelleryringbuilder/viewmyringbuilder',
			submenu:[{
				title: 'View My Ring Builder Mounting',
				root: true,
				
				bullet: 'dot',
				translate: 'View My Ring Builder Mounting',
				page:'jewelleryringbuilder/viewmyringbuilder'
			},
			{
				title: 'Ring Builder Mounting History',
				root: true,
				
				bullet: 'dot',
				translate: 'Ring Builder Mounting History',
				page:'jewelleryringbuilder/ringbuildermountinghistory'
			},
			{
				title: 'Add Ring Builder Mounting',
				root: true,
				
				bullet: 'dot',
				translate: 'Add Ring Builder Mounting',
				page:'jewelleryringbuilder/addringbuildermounting'
			},
			{
				title: 'Upload Ring Builder Mounting File',
				root: true,
				
				bullet: 'dot',
				translate: 'Upload Ring Builder Mounting File',
				page:'jewelleryringbuilder/uploadringbuildermountingfile'
			},
			{
				title: 'Manage FTP For Ring Builder',
				root: true,
				
				bullet: 'dot',
				translate: 'Manage FTP For Ring Builder',
				page:'jewelleryringbuilder/manageftpforringbuilder'
			}]
		},
		
		
		
		
		
		
	]
},


JewelryRetailersMenu: {
	self: {},
	items: [
		{
			title: 'Jewelry Retailer & Permission',
			root: true,
			icon: 'flaticon2-user',
			bullet: 'dot',
			translate: 'Jewelry Retailer & Permission',
			page:'jewelleryvendor/JewelryRetailerPermission'
		},
		{
			title: 'Panding Jewelry Request',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Panding Jewelry Request',
			page:'jewelleryvendor/PendingJewelryRequest'
		},
		{
			title: 'Ring Builder Retailer & Permision',
			root: true,
			icon: 'flaticon2-user',
			bullet: 'dot',
			translate: 'Ring Builder Retailer & Permision',
			page:'jewelleryvendor/RingBuilderRetailerAndPermission'
		},
		{
			title: 'Panding Ring Builder Request',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Panding Ring Builder Request',
			page:'jewelleryvendor/PendingRingBuilderRequest'
		},
		{
			title: 'Conversation',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Conversation',
			page:'jewellerycoversation/allconversation',
			submenu: [{
				title: 'All Conversation',
				root: true,
				//icon: '<i class="fa fa-diamond" aria-hidden="true"  style="font-size:60px;color:red;"></i>',
				bullet: 'dot',
				page: 'jewellerycoversation/allconversation',
				translate: 'All Conversation',						
				},
				{
				title: 'Unread',
				root: true,
				//icon: 'flaticon2-diamond-3',
				bullet: 'dot',
				page: 'jewellerycoversation/unreadedmessage',
				translate: 'Unread',
				 },
				 {
				title: 'Sent',
				root: true,
				//icon: 'flaticon2-pie-chart-2',
				bullet: 'diamond',
				page: 'jewellerycoversation/sent',
				translate: 'Sent',
				}],
		},
		{
			title: 'Retailer Locator',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Retailer Locator',
			page:'jewelleryretailer/retailerlocatorall',
			submenu: [{
				title: 'Retailer Locator All',
				root: true,
				//icon: '<i class="fa fa-diamond" aria-hidden="true"  style="font-size:60px;color:red;"></i>',
				bullet: 'dot',
				page: 'jewelleryretailer/retailerlocatorall',
				translate: 'Retailer Locator All',						
				},
				{
				title: 'Upload Retailer List',
				root: true,
				//icon: 'flaticon2-diamond-3',
				bullet: 'dot',
				page: 'jewelleryretailer/uploadretailerlist',
				translate: 'Upload Retailer List',
				 }
				 ],
		},
		
	]
},
JewelryPOMenu: {
	self: {},
	items: [
		{
			title: 'Purchase Order History',
			root: true,
			icon: 'flaticon2-user',
			bullet: 'dot',
			translate: 'Purchase Order History',
			page:'jewellerypurchaseorder/PurchaseOrderHistory'
		},
		{
			title: 'Update Purchase Order',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Update Purchase Order',
			page:'jewellerypurchaseorder/UpdatePurchaseOrder'
		}
		
	]
},
JewelryMarketingMenu: {
	self: {},
	items: [
		{
			title: 'Update Marketing Material',
			root: true,
			icon: 'flaticon2-user',
			bullet: 'dot',
			translate: 'Update Marketing Material',
			page:'jewellerymarketing/JewelryMarketingModule'
		},
		{
			title: 'Appointment',
			root: true,
			icon: 'flaticon2-mail-1',
			bullet: 'dot',
			translate: 'Appointment',
			page:'jewellerymarketing/Appointment'
		}
		
	]
},

		// JewelryReportsMenu: {
		// 	self: {},
		// 	items: [
		// 		{
		// 			title: 'Jewelry Chart Report',
		// 			root: true,
		// 			icon: 'flaticon2-user',
		// 			bullet: 'dot',
		// 			translate: 'Jewelry Chart Report',
		// 			page:'jewelleryreport/JewelryChartReport'
		// 		},
		// 		{
		// 			title: 'Jewelry Category Report',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Jewelry Category Report',
		// 			page:'jewelleryreport/JewelryCategoryReport'
		// 		},
		// 		{
		// 			title: 'Jewelry Metal Type Report',
		// 			root: true,
		// 			icon: 'flaticon2-user',
		// 			bullet: 'dot',
		// 			translate: 'Jewelry Metal Type Report',
		// 			page:'jewelleryreport/JewelryMetalTypeReport'
		// 		},
		// 		{
		// 			title: 'Jewelry Price Report',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Jewelry Price Report',
		// 			page:'jewelleryreport/JewelryPriceReport'
		// 		}
		// 		,
		// 		{
		// 			title: 'Jewelry Retailer Click Report',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Jewelry Retailer Click Report',
		// 			page:'jewelleryreport/JewelryRetailerClickReport'
		// 		}
		// 		,
		// 		{
		// 			title: 'Location Activity',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Location Activity',
		// 			//page:'jewelleryreport/JewelryPriceReport'
		// 		},
		// 		{
		// 			title: 'Add T0 Wish List Report',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Add TO Wish List Report',
		// 			page:'jewelleryreport/AddToWishReport'
		// 		}
		// 	]
		// },

		// JewelryCatalogsMenu: {
		// 	self: {},
		// 	items: [
		// 		{
		// 			title: 'View My Product',
		// 			root: true,
		// 			icon: 'flaticon-eye',
		// 			bullet: 'dot',
		// 			translate: 'View My Product',
		// 			page:'jewelleryproduct/viewmyproduct'
		// 		},
		// 		{
		// 			title: 'Upload History',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Jewelry Category Report',
		// 			page:'jewelleryproduct/jewelryuploadhistory'
		// 		},
		// 		{
		// 			title: 'Add Product',
		// 			root: true,
		// 			icon: 'flaticon2-user',
		// 			bullet: 'dot',
		// 			translate: 'Add Product',
		// 			page:'jewelleryproduct/jewelryaddproduct'
		// 		},
		// 		{
		// 			title: 'Upload File',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Upload File',
		// 			page:'jewelleryproduct/jewelryuploadfile'
		// 		}
		// 		,
		// 		{
		// 			title: 'Data Mapping',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Data Mapping',
		// 			page:'jewelleryproduct/jewelrydatamapping'
		// 		}
		// 		,
		// 		{
		// 			title: 'Manage Collection',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Manage Collection',
		// 			page:'jewelleryproduct/jewelrymanagecollection'
		// 		},
		// 		{
		// 			title: 'Manage FTP',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Manage FTP',
		// 			page:'diamondsearch/createuser'
		// 		}
		// 	]
		// },


		// JewelryRetailersMenu: {
		// 	self: {},
		// 	items: [
		// 		{
		// 			title: 'Jewelry Retailer & Permission',
		// 			root: true,
		// 			icon: 'flaticon2-user',
		// 			bullet: 'dot',
		// 			translate: 'Jewelry Retailer & Permission',
		// 			page:'jewelleryvendor/JewelryRetailerPermission'
		// 		},
		// 		{
		// 			title: 'Panding Jewelry Request',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Panding Jewelry Request',
		// 			page:'jewelleryvendor/PendingJewelryRequest'
		// 		},
		// 		{
		// 			title: 'Ring Builder Retailer & Permision',
		// 			root: true,
		// 			icon: 'flaticon2-user',
		// 			bullet: 'dot',
		// 			translate: 'Ring Builder Retailer & Permision',
		// 			page:'jewelleryvendor/RingBuilderRetailerAndPermission'
		// 		},
		// 		{
		// 			title: 'Panding Ring Builder Request',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Panding Ring Builder Request',
		// 			page:'jewelleryvendor/PendingRingBuilderRequest'
		// 		}
				
		// 	]
		// },
		// JewelryPOMenu: {
		// 	self: {},
		// 	items: [
		// 		{
		// 			title: 'Purchase Order History',
		// 			root: true,
		// 			icon: 'flaticon2-user',
		// 			bullet: 'dot',
		// 			translate: 'Purchase Order History',
		// 			page:'jewellerypurchaseorder/PurchaseOrderHistory'
		// 		},
		// 		{
		// 			title: 'Update Purchase Order',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Update Purchase Order',
		// 			page:'jewellerypurchaseorder/UpdatePurchaseOrder'
		// 		}
				
		// 	]
		// },
		// JewelryMarketingMenu: {
		// 	self: {},
		// 	items: [
		// 		{
		// 			title: 'Update Marketing Material',
		// 			root: true,
		// 			icon: 'flaticon2-user',
		// 			bullet: 'dot',
		// 			translate: 'Update Marketing Material',
		// 			page:'jewellerymarketing/JewelryMarketingModule'
		// 		},
		// 		{
		// 			title: 'Appointment',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Appointment',
		// 			page:'jewellerymarketing/Appointment'
		// 		}
				
		// 	]
		// },

		
		//----------------------------------------------------------------------------
		// RetailerMenu: {
		// 	self: {},
		// 	items: [
				
			
		// 		{
		// 			title: 'Manage Retailer & Permission',
		// 			root: true,
		// 			icon: 'flaticon2-user',
		// 			bullet: 'dot',
		// 			translate: 'Manage Retailer & Permission',
		// 		},
		// 		{
		// 			title: 'Manage Pending Retailer Requests',
		// 			root: true,
		// 			icon: 'flaticon2-mail-1',
		// 			bullet: 'dot',
		// 			translate: 'Manage Pending Retailer Requests',
		// 		},
		// 		{
		// 			title: 'Setting',
		// 			root: true,
		// 			icon: 'flaticon2-add',
		// 			bullet: 'dot',
		// 			translate: 'Setting',
		// 		},
		// 	]
		// },
	};

	public get configs(): any {
		return this.defaults;
	}
}
