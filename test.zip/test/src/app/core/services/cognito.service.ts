import { Injectable } from "@angular/core";
import { environment } from "../../../environments/environment";
//import { CognitoUserPool } from "amazon-cognito-identity-js";
// import * as AWS from "aws-sdk/global";
// import * as awsservice from "aws-sdk/lib/service";
// import * as CognitoIdentity from "aws-sdk/clients/cognitoidentity";


/**
 * Created by Vladimir Budilov
 */

export interface CognitoCallback {
    cognitoCallback(message: string, result: any): void;

    handleMFAStep?(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void;
}

export interface LoggedInCallback {
    isLoggedIn(message: string, loggedIn: boolean): void;
}

export interface ChallengeParameters {
    CODE_DELIVERY_DELIVERY_MEDIUM: string;

    CODE_DELIVERY_DESTINATION: string;
}

export interface Callback {
    callback(): void;

    callbackWithParam(result: any): void;
}

@Injectable()
export class CognitoUtil {
 
  
}
