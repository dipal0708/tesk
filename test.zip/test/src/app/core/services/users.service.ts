import { Injectable } from '@angular/core';
import { HttpClient ,HttpHeaders} from '@angular/common/http';
import { Observable, BehaviorSubject, ReplaySubject } from 'rxjs';
import { map, catchError, mergeMap, tap,distinctUntilChanged } from 'rxjs/operators';
import { ApiService } from './api.service';
//import { JwtService } from './jwt.service';
//import { User } from '../models';
import { User } from '../auth';
import { environment } from '../../../environments/environment';
const API_USERS_URL = environment.api_url
@Injectable()
export class UserService { 
	private currentUserSubject = new BehaviorSubject<User>({} as User);
	public currentUser = this.currentUserSubject.asObservable().pipe(distinctUntilChanged());

	private isAuthenticatedSubject = new ReplaySubject<boolean>(1);
	public isAuthenticated = this.isAuthenticatedSubject.asObservable();

	constructor(
		private apiService: ApiService,
		private http: HttpClient,
		//private jwtService: JwtService
	) {
		//this.getAll();
	}

	// Verify JWT in localstorage with server & load user's info.
	// This runs once on application startup.
	populate() {
		// If JWT detected, attempt to get & store user's info
		//if (this.jwtService.getToken()) {
		//	this.apiService.get('/user')
		//		.subscribe(
		//			data => this.setAuth(data.user),
		//			err => this.purgeAuth()
		//		);
		//} else {
			
		//	this.purgeAuth();
		//}
	}
	getUserLogin(user: User): Observable<User> {
		return this.http.post<User>(API_USERS_URL + 'awsCognito/login',user);
	}

	getUserDetail(user: User): Observable<any> {	 
		return this.getUserLogin(user).pipe(
			map((result: any) => {
				if (result.data.length <= 0) {
					return "Invalid usernmae or password.";
				}				
				return result;
			}),
			catchError((err: any) => {
				console.log(err.error.msg.message);
				return err.error.msg;
			})
		);
	}
	socialRegister(user):Observable<any> {
		return this.http.post<any>(environment.api_url +'users/socialRegister',user);
	};
	
	// registerSubmit(user: User):Observable<any> {
	// 	const httpHeaders = new HttpHeaders();
	// 	httpHeaders.set('Content-Type', 'application/json');
	// 	user.roles = "1";		
	// 	return this.http.post<User>(API_USERS_URL + 'awsCognito/register', user, { headers: httpHeaders })
	// 		.pipe(
	// 		map((res: User) => {				
	// 				return res;
	// 			}),
	// 			catchError(err => {
	// 				console.log(err.error.msg.message);
	// 				return err.error.msg;
	// 			})
	// 		);
	// }

	setAuth(user: User) {
		// Save JWT sent from server in localstorage
		//this.jwtService.saveToken(user.token);
		// Set current user data into observable
		this.currentUserSubject.next(user);
		// Set isAuthenticated to true
		this.isAuthenticatedSubject.next(true);
	}

	purgeAuth() {
		// Remove JWT from localstorage
		//this.jwtService.destroyToken();
		// Set current user to an empty object
		this.currentUserSubject.next({} as User);
		// Set auth status to false
		this.isAuthenticatedSubject.next(false);
	}

	attemptAuth(type, credentials): Observable<User> {
		const route = (type === 'login') ? '/login' : '';
		return this.apiService.post('/users' + route, { user: credentials })
			.pipe(map(
				data => {
					this.setAuth(data.user);
					return data;
				}
			));
	}

	getCurrentUser(): User {
		return this.currentUserSubject.value;
	}

	// Update the user on the server (email, pass, etc)
	update(user): Observable<User> {
		return this.apiService
			.put('/user', { user })
			.pipe(map(data => {
				// Update the currentUser observable
				this.currentUserSubject.next(data.user);
				return data.user;
			}));
	}
	// Update the user on the server (email, pass, etc)
	// add(user): Observable<User> {
		 
	// 	return this.apiService
	// 		.post('users/add', { user })
	// 		.pipe(map(data => {
	// 			// Update the currentUser observable
	// 			this.currentUserSubject.next(data.user);
	// 			return data.user;
	// 		}));
	// }
	// add(user) {
	// 	return this.http.post(environment.api_url +'users/add',  user );
	// }

	postAdduser(user) {
		// return this.http.post('http://localhost:3000/users/userInsert',  user );
		return this.http.post(environment.api_url +'users/add',  user );
		
	}

	getAll(): Observable<any> {
		return this.apiService.get('users')
			.pipe(map(data => data.tags));
	}
	getCountry(): Observable<any> {	
		return this.http.get<any>(environment.api_url +'users/country');
	 
		// return this.apiService.get('users/country')
		// 	.pipe(map(data => data));

	}
	getloginUser(user) {
		return this.apiService.get('/users/edit/')
			.pipe(map(data => data.tags));
	};
	//-------------------------------------Email Api call
	postEmailtemplate(user):Observable<any> {
		return this.http.post<any>(environment.api_url +'users/emailTemplatesave',user);
			// .pipe(map(data => data.tags));
	};
	getallEmailTemplate(id):Observable<any> {
		return this.http.get<any>(environment.api_url +'users/emailTemplategetall?'+ id);
			// .pipe(map(data => data.tags));
	};
	getemailtemplatebyId(id):Observable<any>{
		return this.http.get<any>(environment.api_url +'users/emailTemplateedit?'+ id);
	}
	deleteEmailTemplate(id):Observable<any>{
		return this.http.get<any>(environment.api_url +'users/emailTemplatedelete?'+ id);
	}
	updateEmailtemplate(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'users/emailTemplateupdate',user);
	}
//-------------------------------------Dashboard Start 

getDiamondDashboard(user):Observable<any>{
	return this.http.post<any>(environment.api_url +'diamond/getDiamondDashboard',  user);
}
//-------------------------------------Dashboard End
	
	//-------------------------------------Companies and users Api call
	getAllcompanies(id):Observable<any>{
		
		return this.http.get<any>(environment.api_url +'users/getcompanyall?'+id);	
	}
	getcompaniesOnly(id):Observable<any>{
		
		return this.http.get<any>(environment.api_url +'users/getcompanysonly?'+id);	
	}
	
	getAllusers():Observable<any>{
		return this.http.get<any>(environment.api_url +'users/getusersall');
	}
	getcompanybyId(id):Observable<any>{
		return this.http.get<any>(environment.api_url +'users/companyedit?'+ id);
	}
	updateCompanydetails(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'users/companyDetailupdate',user);
	}
	updateuserDisable(id):Observable<any>{
		return this.http.get<any>(environment.api_url +'users/userdisable?'+ id);
	}
	updateuserEnable(id):Observable<any>{
		return this.http.get<any>(environment.api_url +'users/userenable?'+ id);
	}
	addnewCompany(user):Observable<any>{
		
		return this.http.post<any>(environment.api_url +'users/addnewcompany',  user);
	}
	updatecompanyDisable(id):Observable<any>{
		return this.http.get<any>(environment.api_url +'users/compaydisable?'+ id);
	}
	updatecompanyEnable(id):Observable<any>{
		return this.http.get<any>(environment.api_url +'users/compayenable?'+ id);
	}
	updateuserPassword(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'users/updateuserpassword',  user);
	}
	// -------------------------------------
	getuserByemail(id):Observable<any>{
		return this.http.get<any>(environment.api_url +'users/getuserbyEmail?'+  id);
	}
//----------------Insert FTP
insertFtp(user){
	return this.http.post<any>(environment.api_url +'users/ftpUpload',user);
}
insertFtpserver(user){
	return this.http.post<any>('http://payments.gemfind.net/createFTPuser.asmx',user);
}

getuploadeddatabyusername(id):Observable<any>{
	return this.http.get<any>(environment.api_url +'users/getftpdatabyid?'+ id);
}
addnewdiamond(user):Observable<any>{
	return this.http.post<any>(environment.api_url +'diamond/addnewDiamond',  user);
}
// ------------------------------------- Diamond Search
	getAlldiamond():Observable<any>{
		return this.http.get<any>(environment.api_url +'diamond/getAlldiamond');
	}
	deletediamond(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/deletediamondbyid',  user);
	}
	getalldropdownItems():Observable<any>{
		return this.http.get<any>(environment.api_url +'diamond/getalldropdownValue');
	}
	sendDiamond(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/sendDiamondEmail',  user);
	}
	getfiltredDiamond(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/getfiltredDiamond',  user);
	}
	getsearchValues(user){
		
		return this.http.post<any>(environment.api_url +'diamond/getsearchValue',  user);
	}
	getDiamondUploadHistory(){
		return this.http.get<any>(environment.api_url +'diamondUploadfiles/getHistory');
	}
	
	getAlldiamondemo(sort, paginator,objFilter,type):Observable<any>{
		
		const Data = {
			skip: (sort * paginator),
			take: paginator,
			filter:objFilter,
			diamondType:type
		   }

		return this.http.post<any>(environment.api_url +'diamond/getAlldiamonddemo',Data);
	}
	getAlldiamondalluser(sort, paginator,objFilter,type):Observable<any>{
		
		const Data = {
			skip: (sort * paginator),
			take: paginator,
			filter:objFilter,
			diamondType:type
		   }

		return this.http.post<any>(environment.api_url +'diamond/getAlldiamondAlluser',Data);
	}


	getTotalDiamonds(objFilter):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/getTotalDiamonds',objFilter);
	}

	//--------Diamond Mapping ------//
	getDiamondmapping(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/getDiamondmappingData',user);
	}
	DealerUploadedDiamondColumns(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/addDealerUploadedDiamondColumns',  user);
	}
	getDealerUploadDiamondColumn(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/getDealerUploadDiamondColumn',user);
	}
	getDealerMappedColumn(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/getDealerDiamondmappingData',user);
	}
	savemappedData(user):Observable<any>{
		
		return this.http.post<any>(environment.api_url +'diamond/savemappedData',  user);
	}
	removeMapping(obj):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/removeMapping',obj);
	}

	//-----------Connected Retailers-------------// 
	
	getConnectedRetailer(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/ConnectedRetailer',user);
	}
	getRetailerPendingRequest(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/RetailerPendingRequest',user);
	}
	approveRetailerds(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/AcceptRetailerRequeset',user);
	}
	rejectRetailerds(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/RejectRetailerRequeset',user);
	}
	changeRetailerAccess(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/ChangeRetailerDiamondAccess',user);
	}

	getFileUploadHistoryData(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/getfileData',user);
	}
	diamondDownload(user){
		return this.http.post<any>(environment.api_url +'diamond/diamondDownload',user);
	}
	getAllDiamondExport(user){
		debugger
		return this.http.post<any>(environment.api_url +'diamond/getAllDiamondExport',user);
	}
	getAllRetailer(user){
		debugger
		return this.http.post<any>(environment.api_url +'diamond/getAllRetailer',user);
	}
	inviteretailerEmail(user){
		return this.http.post<any>(environment.api_url +'diamond/inviteretailerEmail',user);
	}
	//--------------------------------------Diamond Conversation--------------------------------
	getconversation(user){
		return this.http.post<any>(environment.api_url +'diamond/getconversation',user);
	}
	deleteconversation(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/deleteconversation',  user);
	}
	getconversationDetail(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/getconversationDetail',  user);
	}
	insertConversation(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/insertConversation',  user);
	}
	//-----------------------------------Group Discount----------------------------------
	insertRetailerGroupDiscount(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/insertRetailerGroupDiscount',  user);
	}
	getAllRetailerGroupDiscount(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'diamond/getAllRetailerGroupDiscount',  user);
	}
	
	//--------------------------------------end---------------
	//-------------------------------------Jewelry --------------------------------------------------------------------------------------------------
	//--------------------------Jewelry Mapping -------------------------------------------------------------------------
		DealerUploadedJewelryColumns(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'jewelry/addDealerUploadedJewelryColumns',  user);
	}
	getDealerUploadJewelryColumn(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'jewelry/getDealerUploadJewelryColumn',user);
	}
	getJewelrymapping(user):Observable<any>{
		return this.http.post<any>(environment.api_url +'jewelry/getJewelrymapping',user);
	}
	savemappedJewelryData(user):Observable<any>{
		
		return this.http.post<any>(environment.api_url +'jewelry/savemappedjewelryData',  user);
	}
	removeJewelryMapping(obj):Observable<any>{
		return this.http.post<any>(environment.api_url +'jewelry/removeJewelryMapping',obj);
	}
	addJewelryManageCollection(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/addJewelleryManageCollection',obj);
	}
	getAllJewelleryManageCollection(obj){
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/getAllJewelleryManageCollection',obj);
	}
	// insertFtp(user){
	// 	return this.http.post<any>(environment.api_url +'users/ftpUpload',user);}
	getupdateJewelleryManageCollection(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/getupdateJewelleryManageCollection',obj);
	}
	updateJewelleryManageCollection(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/updateJewelleryManageCollection',obj);
	}
	deleteJewelleryManageCollection(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/deleteJewelleryManageCollection',obj);
	}
	addJewelryProduct(obj,formData):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/addJewelryProduct',obj,formData);
	}
	allJewelryProduct(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/allJewelryProduct',obj);
	}
	uploadRetailerList(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/uploadRetailerList',obj);
	}
	getAllRetailerList(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/getAllRetailerList',obj);
	}
	getAllRetailerListForUpdate(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/getAllRetailerListForUpdate',obj);
	}
	updateRetailerList(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/updateRetailerList',obj);
	}
	deleteRetailerLocator(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/deleteRetailerLocator',obj);
	}
	allJewelleryMetalType(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/allJewelleryMetalType',obj);
	}
	allJewelleryMetalColor(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/allJewelleryMetalColor',obj);
	}
	allJewelleryCategory(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/allJewelleryCategory',obj);
	}
	allJewelleryCollection(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/allJewelleryCellaction',obj);
	}
	addGroupList(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/addGroupList',obj);
	}
	allGroupList(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/allGroupList',obj);
	}
	getPerticularDiscountListForUpdate(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/getPerticularDiscountListForUpdate',obj);
	}
	updateDiscountList(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/updateDiscountList',obj);
	}
	DeleteDiscountList(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/DeleteDiscountList',obj);
	}
	addRingBuilder(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'jewelry/addRingBuilder',obj);
	}
	UploadFile(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'api/upload',obj);
	}
	uploadProfile(obj):Observable<any>{
		debugger;
		return this.http.post<any>(environment.api_url+'api/uploadProfile',obj);
	}
}