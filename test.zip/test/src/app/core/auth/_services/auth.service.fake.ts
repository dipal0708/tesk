// Angular
import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// RxJS
import { Observable, of, forkJoin } from 'rxjs';
import { map, catchError, mergeMap, tap } from 'rxjs/operators';
// Lodash
import { filter, some, find, each } from 'lodash';
// Environment
import { environment } from '../../../../environments/environment';
// CRUD
import { QueryParamsModel, QueryResultsModel, HttpUtilsService } from '../../_base/crud';
// Models
import { User } from '../_models/user.model'; 
import { Permission } from '../_models/permission.model';
import { Role } from '../_models/role.model';
import { CognitoCallback, CognitoUtil, LoggedInCallback } from '../../services/cognito.service';
//import { AuthenticationDetails, CognitoUserAttribute, CognitoUser, CognitoUserSession } from 'amazon-cognito-identity-js';
import { DynamoDBService } from '../../services/ddb.service';


const API_USERS_URL = environment.api_url // 'api/users' //'http://localhost:3000/users/add';
const API_PERMISSION_URL = 'api/permissions';
const API_ROLES_URL = 'api/roles';

@Injectable()
export class AuthService {
	constructor(private http: HttpClient, public ddb: DynamoDBService,
		private httpUtils: HttpUtilsService, @Inject(CognitoUtil) public cognitoUtil: CognitoUtil) { }

	
	// getUserDetail(user: User): Observable<any> {	 
	// 	return this.getUserLogin(user).pipe(
	// 		map((result: any) => {
	// 			if (result.data.length <= 0) {
	// 				return "Invalid usernmae or password.";
	// 			}				
	// 			return result;
	// 		}),
	// 		catchError((err: any) => {
	// 			console.log(err.error.msg.message);
	// 			return err.error.msg;
	// 		})
	// 	);
	// }
	 

	// private onLoginError = (callback: CognitoCallback, err) => {
	// 	callback.cognitoCallback(err.message, null);
	// }
	register(user: User, callback: CognitoCallback): Observable<any> { //
		user.roles = "1"; // Manager
		//user.accesstoken = 'access-token-' + Math.random();
		//user.refreshtoken = 'access-token-' + Math.random();
		//user.pic = './assets/media/users/default.jpg';

		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');
		return null;
		// end ///////////

	}
	registerSubmit(user: User):Observable<any> {
		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');
		user.roles = "1";		
		return this.http.post<User>(API_USERS_URL + 'awsCognito/register', user, { headers: httpHeaders })
			.pipe(
			map((res: User) => {		
					return res;
				}),
				catchError(err => {
					console.log(err.error.msg.message);
					return err.error.msg;
				})
			);
	}

	getUserDetailbyEmail(email: string): Observable<any> {
		return this.http.get(API_USERS_URL+'users/edit' + `/${email}`);
	}
	
	changePassword(user: any) {
		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');
		
		return this.http.post<User>(API_USERS_URL + 'awsCognito/changePassword', user, { headers: httpHeaders })
			.pipe(
			map((res: User) => {				
					return res;
				}),
				catchError(err => {
					console.log(err);
					return err;
				})
			);
	}
	

	updateProfile(user: User, result: any) {
		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');
		user.roles = "1";
		return this.http.post<User>(API_USERS_URL + 'users/edit', user, { headers: httpHeaders })
			.pipe(
				map((res: User) => {
					return res;
				}),
				catchError(err => {
					console.log(err);
					return err;
				})
			);
	}

	requestPassword(email: string) {
		debugger
		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');		 	
		return this.http.post<User>(API_USERS_URL + 'awsCognito/forgotPass/'+email, { headers: httpHeaders })
			.pipe(
			map((res: User) => {				
					return res;
				}),
				catchError(err => {
					
					console.log(err.error.msg.message);
					return err.error.msg;
				})
			);
	}

	confirmNewPassword(email: string, verificationCode: string, password: string) {
		let userData = {
			email: email,
			verificationCode:verificationCode,
			newPassword:password 
		};
		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');		 	
		return this.http.post<User>(API_USERS_URL + 'awsCognito/confirmPassword',userData, { headers: httpHeaders })
			.pipe(
			map((res: User) => {				
					return res;
				}),
				catchError(err => {
					console.log(err.error.msg.message);
					return err.error.msg;
				})
			);
	}

	getUserByToken(): Observable<User> {
		const userToken = localStorage.getItem(environment.authTokenKey);
		if (!userToken) {
			return of(null);
		}
        
		return this.getAllUsers().pipe(
			map((result: any) => {
				if (result.data.length <= 0) {
					return null;
				}
				const user = find(result.data, function (item: User) {
					return (item.accesstoken === userToken.toString());
				});
				if (!user) {
					return null;
				}
				localStorage.setItem('userDetail', JSON.stringify(user));
				localStorage.setItem('language', user.language);
				user.password = undefined;
				return user;
			})
		);
	}

	confirmRegistration(user:User, confirmationCode: string): Observable<any> {

		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');
		user.roles = "1";		
		return this.http.post<User>(API_USERS_URL + 'awsCognito/confirmRegister/'+confirmationCode, user, { headers: httpHeaders })
			.pipe(
			map((res: User) => {				
					return res;
				}),
				catchError(err => {
					console.log(err.error.msg.message);
					return err.error.msg;
				})
			);
		
	}

	resendCode(username: string): Observable<any> {
		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');
		return this.http.post<User>(API_USERS_URL + 'awsCognito/resendConfirmCode/'+username, { headers: httpHeaders })
			.pipe(
			map((res: User) => {				
					return res;
				}),
				catchError(err => {
					console.log(err.error.msg.message);
					return err.error.msg;
				})
			);
	}
	
	// logout() {
	// 	console.log("UserLoginService: Logging out");
	// 	this.ddb.writeLogEntry("logout");
	// 	this.cognitoUtil.getCurrentUser().signOut();

	// }

	// isAuthenticated(callback: LoggedInCallback) {
	// 	if (callback == null)
	// 		throw ("UserLoginService: Callback in isAuthenticated() cannot be null");

	// 	let cognitoUser = this.cognitoUtil.getCurrentUser();

	// 	if (cognitoUser != null) {
	// 		cognitoUser.getSession(function (err, session) {
	// 			if (err) {
	// 				console.log("UserLoginService: Couldn't get the session: " + err, err.stack);
	// 				callback.isLoggedIn(err, false);
	// 			}
	// 			else {
	// 				console.log("UserLoginService: Session is " + session.isValid());
	// 				callback.isLoggedIn(err, session.isValid());
	// 			}
	// 		});
	// 	} else {
	// 		console.log("UserLoginService: can't retrieve the current user");
	// 		callback.isLoggedIn("Can't retrieve the CurrentUser", false);
	// 	}
	// }
	// Users

	// CREATE =>  POST: add a new user to the server
	createUser(user: User): Observable<User> {
		const httpHeaders = new HttpHeaders();
		// Note: Add headers if needed (tokens/bearer)
		httpHeaders.set('Content-Type', 'application/json');
		return this.http.post<User>(API_USERS_URL, user, { headers: httpHeaders });
	}

	// READ
	getAllUsers(): Observable<User[]> {
		return this.http.get<User[]>(API_USERS_URL + 'users');
	}
	// Login
	// getUserLogin(user: User): Observable<User> {
	// 	return this.http.post<User>(API_USERS_URL + 'awsCognito/login',user);
	// }
	
	getUserById(userId: number): Observable<User> {
		if (!userId) {
			return of(null);
		}

		return this.http.get<User>(API_USERS_URL + `/${userId}`);
	}

	// DELETE => delete the user from the server
	deleteUser(userId: number) {
		const url = `${API_USERS_URL}/${userId}`;
		return this.http.delete(url);
	}

	// UPDATE => PUT: update the user on the server
	updateUser(_user: User): Observable<any> {
		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');
		return this.http.put(API_USERS_URL, _user, { headers: httpHeaders }).pipe(
			catchError(err => {
				return of(null);
			})
		);
	}

	// Method from server should return QueryResultsModel(items: any[], totalsCount: number)
	// items => filtered/sorted result
	findUsers(queryParams: QueryParamsModel): Observable<QueryResultsModel> {
		// This code imitates server calls
		
		return this.getAllUsers().pipe(
			mergeMap((response: User[]) => {
				const result = this.httpUtils.baseFilter(response, queryParams, []);
				return of(result);
			})
		);
	}

	// Permissions
	getAllPermissions(): Observable<Permission[]> {
		return this.http.get<Permission[]>(API_PERMISSION_URL);
	}

	getRolePermissions(roleId: number): Observable<Permission[]> {
		const allRolesRequest = this.http.get<Permission[]>(API_PERMISSION_URL);
		const roleRequest = roleId ? this.getRoleById(roleId) : of(null);
		return forkJoin(allRolesRequest, roleRequest).pipe(
			map(res => {
				const _allPermissions: Permission[] = res[0];
				const _role: Role = res[1];
				if (!_allPermissions || _allPermissions.length === 0) {
					return [];
				}

				const _rolePermission = _role ? _role.permissions : [];
				const result: Permission[] = this.getRolePermissionsTree(_allPermissions, _rolePermission);
				return result;
			})
		);
	}

	private getRolePermissionsTree(_allPermission: Permission[] = [], _rolePermissionIds: number[] = []): Permission[] {
		const result: Permission[] = [];
		const _root: Permission[] = filter(_allPermission, (item: Permission) => !item.parentId);
		each(_root, (_rootItem: Permission) => {
			_rootItem._children = [];
			_rootItem._children = this.collectChildrenPermission(_allPermission, _rootItem.id, _rolePermissionIds);
			_rootItem.isSelected = (some(_rolePermissionIds, (id: number) => id === _rootItem.id));
			result.push(_rootItem);
		});
		return result;
	}

	private collectChildrenPermission(_allPermission: Permission[] = [],
		_parentId: number, _rolePermissionIds: number[] = []): Permission[] {
		const result: Permission[] = [];
		const _children: Permission[] = filter(_allPermission, (item: Permission) => item.parentId === _parentId);
		if (_children.length === 0) {
			return result;
		}

		each(_children, (_childItem: Permission) => {
			_childItem._children = [];
			_childItem._children = this.collectChildrenPermission(_allPermission, _childItem.id, _rolePermissionIds);
			_childItem.isSelected = (some(_rolePermissionIds, (id: number) => id === _childItem.id));
			result.push(_childItem);
		});
		return result;
	}

	// Roles
	getAllRoles(): Observable<Role[]> {
		return this.http.get<Role[]>(API_ROLES_URL);
	}

	getRoleById(roleId: number): Observable<Role> {
		return this.http.get<Role>(API_ROLES_URL + `/${roleId}`);
	}

	// CREATE =>  POST: add a new role to the server
	createRole(role: Role): Observable<Role> {
		// Note: Add headers if needed (tokens/bearer)
		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');
		return this.http.post<Role>(API_ROLES_URL, role, { headers: httpHeaders });
	}

	// UPDATE => PUT: update the role on the server
	updateRole(role: Role): Observable<any> {
		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Content-Type', 'application/json');
		return this.http.put(API_ROLES_URL, role, { headers: httpHeaders });
	}

	// DELETE => delete the role from the server
	deleteRole(roleId: number): Observable<Role> {
		const url = `${API_ROLES_URL}/${roleId}`;
		return this.http.delete<Role>(url);
	}

	findRoles(queryParams: QueryParamsModel): Observable<QueryResultsModel> {
		// This code imitates server calls
		return this.http.get<Role[]>(API_ROLES_URL).pipe(
			mergeMap(res => {
				const result = this.httpUtils.baseFilter(res, queryParams, []);
				return of(result);
			})
		);
	}

	// Check Role Before deletion
	isRoleAssignedToUsers(roleId: number): Observable<boolean> {
		
		return this.getAllUsers().pipe(
			map((users: User[]) => {
				//if (some(users, (user: User) => some(user.roles, (_roleId: number) => _roleId === roleId))) {
					return true;
				//}

				//return false;
			})
		);
	}

	private handleError<T>(operation = 'operation', result?: any) {
		return (error: any): Observable<any> => {
			// TODO: send the error to remote logging infrastructure
			console.error(error); // log to console instead

			// Let the app keep running by returning an empty result.
			return of(result);
		};
	}
}
