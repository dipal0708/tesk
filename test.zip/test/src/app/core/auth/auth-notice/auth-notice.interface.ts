export interface AuthNotice {
	type?: string;
	message: string;
}
