// Angular
import { Injectable } from '@angular/core';
// RxJS
import { BehaviorSubject } from 'rxjs';
// Object path
import * as objectPath from 'object-path';
// Services
import { MenuConfigService } from './menu-config.service';

@Injectable()
export class MenuAsideService {
	// Public properties
	classes: string;
	menuList$: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);

	/**
	 * Service Constructor
	 *
	 * @param menuConfigService: MenuConfigService
	 * @param store: Store<AppState>
	 */
	constructor(
		private menuConfigService: MenuConfigService
	) {
		this.loadMenu();
	}

	/**
	 * Load menu
	 */
	loadMenu() {
		// get menu list
		const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'DashboardMenu.items');
		this.menuList$.next(menuItems);
	}
	menuChange(value){
		debugger
		if(value == 'diamondCatalog'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'DiamondMenu.items');
			this.menuList$.next(menuItems);
		}
		if(value == 'landingPage'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'DiamondMenu.items');
			this.menuList$.next(menuItems);
		}
		if(value == 'Admin'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'aside.items');
			this.menuList$.next(menuItems);
		}
		if(value == 'diamondDashboard'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'DashboardMenu.items');
			this.menuList$.next(menuItems);
			this.loadMenu();
		}
		if(value == 'diamondSearch'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'SearchMenu.items');
			this.menuList$.next(menuItems);
		}
		if(value == 'diamondRetailers'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'DiamonRetailerMenu.items');
			this.menuList$.next(menuItems);
		}
		if(value == 'diamondReports'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'ReportsMenu.items');
			this.menuList$.next(menuItems);
		}
		if(value == 'diamondMarketing'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'MarketingMenu.items');
			this.menuList$.next(menuItems);
		}
		if(value == 'diamondPO'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'POsMenu.items');
			this.menuList$.next(menuItems);
		}
		//----------------------Jewelry

		if(value == 'jewelryDashboard'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'DashboardMenu.items');
			this.menuList$.next(menuItems);
		}
		// if(value == 'Catalog'){
		// 	const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'DiamondMenu.items');
		// 	this.menuList$.next(menuItems);
		// }
		if(value == 'jewelryCatalog'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'JewelryCatalogsMenu.items');
			this.menuList$.next(menuItems);
		}
		if(value == 'jewelryRetailers'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'JewelryRetailersMenu.items');
			this.menuList$.next(menuItems);
		}

		if(value == 'jewelryPO'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'JewelryPOMenu.items');
			this.menuList$.next(menuItems);
		}
		if(value == 'jewelryReports'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'JewelryReportsMenu.items');
			this.menuList$.next(menuItems);
		}
		if(value == 'jewelryMarketing'){
			const menuItems: any[] = objectPath.get(this.menuConfigService.getMenus(), 'JewelryMarketingMenu.items');
			this.menuList$.next(menuItems);
		}
	}

}
