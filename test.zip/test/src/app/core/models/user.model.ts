import { BaseModel } from "../_base/crud";
//import { Address, SocialNetworks } from "../auth";
// import { int } from "aws-sdk/clients/datapipeline";
// import { GUID } from "aws-sdk/clients/es";
//import { BaseModel } from '../../_base/crud';
//import { Address } from 'address.model';
//import { SocialNetworks } from 'social-networks.model';
import { v4 as uuid } from 'uuid';

export class User extends BaseModel {
    //  id: number;   // new commented
    // username: string;
    // password: string;
    // email: string;
    // accessToken: string;
    // accesstoken: string;
    // refreshToken: string;
    // roles: number[];
    // pic: string;
    // fullname: string;
    // occupation: string;
	// companyName: string;
	// phone: string;
    // address: Address;
    // socialNetworks: SocialNetworks;
	// created_date: string;
	// createdDate: Date;
    // pk_id: int;
     
    pk_id :uuid;
    accesstoken: string;
    account_type: string;
    address: string;
    city : string;
    company_name : string;
    contact_no: string;
    country :uuid;
    created_date :string;
    currency : string;
    email : string;
    is_deleted:boolean;
    is_emailverify:boolean;
    is_enable:boolean;
    language: string;
    firstname: string;
    lastname:string
    password: string;
    refreshtoken: string;
	roles: string;//number[];
    state: string;
    updated_date: string;
    user_name: string;
    zip_code: string;

    

    // clear(): void {
    //     this.id = undefined;
    //     this.username = '';
    //     this.password = '';
    //     this.email = '';
    //     this.roles = [];
    //     this.fullname = '';
    //     this.accessToken = 'access-token-' + Math.random();
    //     this.refreshToken = 'access-token-' + Math.random();
    //     this.pic = './assets/media/users/default.jpg';
    //     this.occupation = '';
    //     this.companyName = '';
    //     this.phone = '';
    //     this.address = new Address();
    //     this.address.clear();
    //     this.socialNetworks = new SocialNetworks();
    //     this.socialNetworks.clear();
    // }
}
